#RS|pensummi_istandwjesus|48|2021.03.09 22:14:32|2826|1|2|8|4|18|41|16|8|2|40|29|1|2|30|39|8|1|2|69|3|81|253|1|37|1707|414|2|6|1

DROP TABLE IF EXISTS aemailtempl;
CREATE TABLE `aemailtempl` (
  `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `tag_descr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`emailtempl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

