#RS|pensummi_istandwjesus|48|2021.03.09 22:20:43|2826|1|2|8|4|18|41|16|8|2|40|29|1|2|30|39|8|1|2|69|3|81|253|1|37|1707|414|2|6|1

DROP TABLE IF EXISTS aemailtempl;
CREATE TABLE `aemailtempl` (
  `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `tag_descr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`emailtempl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `aemailtempl` VALUES(1, 'Welcome to [SiteTitle]', '&lt;p&gt;Dear [FirstName] [LastName],&lt;/p&gt;\r\n&lt;p&gt;Some message with tags.&lt;/p&gt;\r\n&lt;p&gt;Regards, [SiteTitle]&lt;/p&gt;', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteUrl]\');\">SiteUrl</a>] - Url of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Referral Link<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ID]\');\">ID</a>] - Member&#039;s ID<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s First Name<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s Last Name<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s Username<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s Email<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorID]\');\">SponsorID</a>] - Sponsor&#039;s ID<br>\r\n', 1);


DROP TABLE IF EXISTS aptools;
CREATE TABLE `aptools` (
  `aptool_id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`aptool_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS autoresponders;
CREATE TABLE `autoresponders` (
  `email_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `z_day` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_free` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`email_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `autoresponders` VALUES(1, 'test', 'test', 1, 0, 1);
INSERT INTO `autoresponders` VALUES(2, 'test', 'test', 2, 0, 0);


DROP TABLE IF EXISTS cash;
CREATE TABLE `cash` (
  `cash_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `from_id` int(11) NOT NULL DEFAULT 0,
  `to_id` int(11) NOT NULL DEFAULT 0,
  `type_cash` varchar(150) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `descr` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `cash_date` int(11) NOT NULL DEFAULT 0,
  `payment_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`cash_id`),
  KEY `transfer_date_idx` (`cash_date`),
  KEY `user_id_idx` (`to_id`),
  KEY `amount_idx` (`amount`),
  KEY `from_id_idx` (`from_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `cash` VALUES(15, '10000.00', 1, 13, '1', 'For completed matrix', 1615294825, 0);
INSERT INTO `cash` VALUES(14, '10000.00', 1, 16, '1', 'For completed matrix', 1615285004, 0);
INSERT INTO `cash` VALUES(13, '10000.00', 1, 9, '2', 'For completed matrix', 1615223767, 0);
INSERT INTO `cash` VALUES(12, '10000.00', 1, 12, '1', 'For completed matrix', 1615223765, 0);
INSERT INTO `cash` VALUES(11, '10000.00', 1, 11, '1', 'For completed matrix', 1615223733, 0);
INSERT INTO `cash` VALUES(10, '10000.00', 1, 10, '1', 'For completed matrix', 1615223705, 0);
INSERT INTO `cash` VALUES(9, '10000.00', 1, 9, '1', 'For completed matrix', 1615223675, 0);
INSERT INTO `cash` VALUES(16, '10000.00', 1, 26, '1', 'For completed matrix', 1615298763, 0);


DROP TABLE IF EXISTS cash_out;
CREATE TABLE `cash_out` (
  `cash_out_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `processor` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `account_id` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `transfer_date` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`cash_out_id`),
  KEY `transfer_date_idx` (`transfer_date`),
  KEY `member_id_idx` (`member_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS categories;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `m_level` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS currency;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(8) DEFAULT NULL,
  `name` varchar(8) DEFAULT '',
  `active` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `currency` VALUES(1, '$', 'USD', 1);
INSERT INTO `currency` VALUES(2, '€', 'EUR', 1);
INSERT INTO `currency` VALUES(3, 'Mex$', 'MXN', 1);
INSERT INTO `currency` VALUES(4, '₦', 'NGN', 1);


DROP TABLE IF EXISTS emailtempl;
CREATE TABLE `emailtempl` (
  `emailtempl_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `subject` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `tag_descr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`emailtempl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `emailtempl` VALUES(1, 'Sponsor notification about new sign up', 'From [SiteTitle]: New referrer signup up', 'Dear [SponsorFName] [SponsorLName], \r\n\r\nYou referral activated account. Their email is [Email], name is [FirstName] [LastName]. Contact them and make sure they are able to verify their email address.\r\nIf they don&#039;t do this within 24 hours they will be removed.\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorFName]\');\">SponsorFName</a>] - Sponsor&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorLName]\');\">SponsorLName</a>] - Sponsor&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorUsername]\');\">SponsorUsername</a>] - Sponsor&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorEmail]\');\">SponsorEmail</a>] - Sponsor&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(2, 'Welcome email sent to member after successful registration with activation link', 'Activate your new account in [SiteTitle]', 'Welcome and thank you for signing up to be a Member of [SiteTitle].\r\n\r\nYour login is: [Username]\r\nYour password is: [Password]\r\n\r\nTo activate your account (active within 24 hours) follow this Activation Membership link:\r\n[ActivationLink]\r\n\r\nWe look forward to helping you grow your business.\r\n\r\nWith best regards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ActivationLink]\');\">ActivationLink</a>] - Member&#039;s activation link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(3, 'Sponsor notification about a new activated referral', 'From [SiteTitle]: New personal referral is verified', 'Dear [SponsorFName] [SponsorLName], \r\n\r\nYour new enrollee has just become verified.\r\nTheir email address is [Email], name is [FirstName] [LastName].\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorFName]\');\">SponsorFName</a>] - Sponsor&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorLName]\');\">SponsorLName</a>] - Sponsor&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorUsername]\');\">SponsorUsername</a>] - Sponsor&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SponsorEmail]\');\">SponsorEmail</a>] - Sponsor&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(4, 'Welcome email sent to member after successful registration', 'Welcome to [SiteTitle]', 'Welcome and thank you for signing up to be a Member of [SiteTitle].\r\n\r\nYour login is: [Username]\r\nYour password is: [Password]\r\n\r\nWe look forward to helping you grow your business.\r\n\r\nWith best regards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Member&#039;s Referral Link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(5, 'Forgot password email content with new access details', 'From [SiteTitle]: Your new access details', 'Dear [FirstName] [LastName], \r\n\r\nYou received this email because you have requested to remind you login details for [SiteTitle].\r\n\r\nYour login is: [Username]\r\n\r\nYour password is: [Password]\r\n\r\nYour referral link is: [RefLink]\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Password]\');\">Password</a>] - Member&#039;s password<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Member&#039;s Referral Link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(6, 'Pin code email after unsuccessfull log in attempt from wrong IP address', 'From [SiteTitle]: Changing Security Data', 'Dear [FirstName] [LastName], \r\n\r\nYou have tried to enter  [SiteTitle] from another IP address.\r\n\r\nTo change your current IP address click the link below end enter this pin-code: [PinCode]\r\n\r\n\r\n[CheckLink]\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[PinCode]\');\">PinCode</a>] - Member&#039;s pin code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[CheckLink]\');\">CheckLink</a>] - Member&#039;s check link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(7, 'Guest notification about a new ticket registration at the public support center', 'From [SiteTitle]: Your new ticket has been successfully registered', 'Dear [FirstName] [LastName], \r\n\r\nYour ticket was successfully sent to support center of [SiteTitle]. It will be soon answered.\r\n\r\n\r\nSubject of ticket: [TicketSubject]\r\n\r\nPlease use this direct link to view ticket status: \r\n\r\n[TicketLink] \r\n\r\n\r\nAlso you can view your ticket status using another way and following details:\r\n\r\nURL: [TicketShortLink] \r\n\r\nE-mail: [Email] \r\n\r\nTicket code: [TicketCode] \r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketSubject]\');\">TicketSubject</a>] - Subject of the ticket<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketCode]\');\">TicketCode</a>] - Ticket code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketLink]\');\">TicketLink</a>] - Full ticket link<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketShortLink]\');\">TicketShortLink</a>] - Short ticket link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(8, 'Guest notification about answer from the public support center', 'From [SiteTitle]: New answer from public support center', 'Dear [FirstName] [LastName], \r\n\r\nYou have just received an answer on your ticket.\r\n\r\nPlease use this direct link to view ticket status: \r\n\r\n[TicketLink] \r\n\r\n\r\nAlso you can view your ticket status using another way and following details:\r\n\r\nURL: [TicketShortLink] \r\n\r\nE-mail: [Email] \r\n\r\nTicket code: [TicketCode]\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Email]\');\">Email</a>] - Member&#039;s email<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketSubject]\');\">TicketSubject</a>] - Subject of the ticket<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketCode]\');\">TicketCode</a>] - Ticket code<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketLink]\');\">TicketLink</a>] - Full ticket link<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[TicketShortLink]\');\">TicketShortLink</a>] - Short ticket link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(9, 'Email template for members contact page', '[SiteTitle]: A message from [SenderFirstName] [SenderLastName] ([SenderID])!', 'Hello [FirstName] [LastName], \r\n\r\nSome message\r\n\r\n\r\n\r\n\r\nRegards,\r\n[SenderFirstName] [SenderLastName]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[ID]\');\">ID</a>] - Member&#039;s ID<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderFirstName]\');\">SenderFirstName</a>] - Sender&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderLastName]\');\">SenderLastName</a>] - Sender&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderID]\');\">SenderID</a>] - Sender&#039;s ID<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(10, 'Email template for members Tell Friend page', 'From [SiteTitle]: Hi [FirstName] [LastName]!', 'Hello [FirstName] [LastName], \r\n\r\nI just had to tell you about this great site I just found.\r\n\r\nCheck it out for yourself at [RefLink]\r\n\r\n\r\n\r\nRegards,\r\n[SenderFirstName] [SenderLastName]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderFirstName]\');\">SenderFirstName</a>] - Sender&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SenderLastName]\');\">SenderLastName</a>] - Sender&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefLink]\');\">RefLink</a>] - Sender&#039;s Referral Link<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(11, 'Successfull payment notification', 'From [SiteTitle]: Successful payment', 'Hello [FirstName] [LastName], \r\n\r\nYou have made a successful [Processor] payment.\r\n\r\nAmount: $[Amount]\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Processor]\');\">Processor</a>] - Payment Processor<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(12, 'Getting commissions / forced matrix mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYour [SiteTitle] membership earned you $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(13, 'Matrix completion and getting commissions / cycling matrix mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYou just completed [Matrix] matrix on [SiteTitle] and earned $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Matrix]\');\">Matrix</a>] - Title of completed matrix<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(14, 'Matrix completion and getting commissions by sponsor/ cycling mode', 'From [SiteTitle]: Your membership earned commissions', 'Congratulations [FirstName] [LastName], \r\n\r\nYour referral #[RefID] just completed [Matrix] matrix on [SiteTitle] and earned you $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Matrix]\');\">Matrix</a>] - Title of completed matrix<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[RefID]\');\">RefID</a>] - Referral ID<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(15, 'Sponsor bonus notification for personally enrolled', 'From [SiteTitle]: You earned sponsor bonus', 'Congratulations [FirstName] [LastName], \r\n\r\nYou earned [SiteTitle] sponsor bonus : $[Amount].\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(16, 'Successfull withdrawal request completion notification', 'From [SiteTitle]: your withdrawal request is completed', 'Hello [FirstName] [LastName], \r\n\r\nYour withdrawal request was successfully completed.\r\n\r\n$[Amount] was paid to your account.\r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Amount]\');\">Amount</a>] - Amount<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(17, 'End of active period notification/ forced mode', 'From [SiteTitle]: active period expired', 'Hello [FirstName] [LastName], \r\n\r\nYour Account has expired. \r\n\r\nYou should log in to your member area now to make a payment, ensuring that you retain active status in the pay plan and do not lose any benefits. \r\n\r\n\r\n\r\nRegards,\r\n[SiteTitle]', '[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[SiteTitle]\');\">SiteTitle</a>] - Title of the site<br />\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[FirstName]\');\">FirstName</a>] - Member&#039;s first name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[LastName]\');\">LastName</a>] - Member&#039;s last name<br>\r\n\r\n[<a href=\"javascript:void(0);\" title=\"click to paste\" onClick=\"insertText (\'[Username]\');\">Username</a>] - Member&#039;s username<br>\r\n', 1);
INSERT INTO `emailtempl` VALUES(18, 'Pre Launch notification', '[SiteTitle] is launched', 'Hello [FirstName] [LastName],\r\n\r\nWe are glad to inform you that starting from now you can Upgrade your account in <a href=\'[SiteUrl]\'>[SiteTitle]</a>.\r\n\r\nPlease login using your credentials. \r\n\r\nWith best regards,\r\n[SiteTitle] Team\r\n', '', 1);


DROP TABLE IF EXISTS faq;
CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `answer` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS fees;
CREATE TABLE `fees` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_order_index` int(11) NOT NULL DEFAULT 0,
  `plevel` int(3) NOT NULL DEFAULT 0,
  `fee_member` decimal(12,2) NOT NULL DEFAULT 0.00,
  `fee_sponsor` decimal(12,2) NOT NULL DEFAULT 0.00,
  `from_order_index` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`fee_id`),
  KEY `to_order_index_idx` (`to_order_index`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS lands;
CREATE TABLE `lands` (
  `land_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `photo` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `z_date` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`land_id`),
  KEY `z_date_idx` (`z_date`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS logs;
CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_date` int(11) NOT NULL DEFAULT 0,
  `ip_addr` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `descr` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `z_date_idx` (`z_date`)
) ENGINE=MyISAM AUTO_INCREMENT=42 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `logs` VALUES(1, 1614804747, '197.210.70.55', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(2, 1614804765, '197.210.70.55', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(3, 1614804791, '197.210.71.96', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(4, 1614886627, '197.210.76.155', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(5, 1614939036, '197.210.70.140', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(6, 1614939056, '197.210.70.183', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(7, 1614939436, '197.210.70.75', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(8, 1614939810, '197.210.71.192', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(9, 1614961879, '197.210.70.197', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(10, 1614979315, '197.210.76.14', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(11, 1615018152, '105.112.228.136', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(12, 1615033370, '197.210.52.55', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(13, 1615047875, '197.210.71.14', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(14, 1615048061, '197.210.70.56', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(15, 1615049615, '197.210.70.56', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(16, 1615049976, '105.112.228.253', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(17, 1615055294, '197.210.71.14', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(18, 1615055926, '197.210.71.153', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(19, 1615059184, '197.210.70.1', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(20, 1615062837, '197.210.71.165', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(21, 1615125597, '197.210.71.63', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(22, 1615199073, '105.112.115.236', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(23, 1615209277, '197.210.77.77', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(24, 1615215245, '105.112.115.236', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(25, 1615218435, '105.112.115.236', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(26, 1615221365, '197.210.53.212', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(27, 1615221840, '197.210.53.212', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(28, 1615222563, '197.210.77.61', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(29, 1615225095, '197.210.70.135', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(30, 1615237669, '197.210.70.141', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(31, 1615276333, '197.210.52.32', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(32, 1615277275, '197.210.52.32', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(33, 1615282332, '197.210.52.109', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(34, 1615286625, '105.112.124.252', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(35, 1615293667, '105.112.124.252', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(36, 1615298702, '197.210.52.180', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(37, 1615303532, '197.210.53.30', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(38, 1615307803, '197.210.53.30', 'Incorrect login attempt. Password or Username do not match.');
INSERT INTO `logs` VALUES(39, 1615307817, '197.210.53.30', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(40, 1615323635, '105.112.115.120', 'Logged in succesfully.');
INSERT INTO `logs` VALUES(41, 1615325556, '105.112.115.120', 'Logged in succesfully.');


DROP TABLE IF EXISTS matrices_completed;
CREATE TABLE `matrices_completed` (
  `matrix_id` int(11) NOT NULL AUTO_INCREMENT,
  `place_id` int(11) DEFAULT 0,
  `z_date` int(11) DEFAULT 0,
  PRIMARY KEY (`matrix_id`),
  KEY `place_id_idx` (`place_id`),
  KEY `z_date_idx` (`z_date`)
) ENGINE=MyISAM AUTO_INCREMENT=17 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `matrices_completed` VALUES(1, 2, 1614940873);
INSERT INTO `matrices_completed` VALUES(2, 9, 1615057929);
INSERT INTO `matrices_completed` VALUES(3, 10, 1615063926);
INSERT INTO `matrices_completed` VALUES(4, 11, 1615066032);
INSERT INTO `matrices_completed` VALUES(5, 12, 1615067279);
INSERT INTO `matrices_completed` VALUES(6, 13, 1615067281);
INSERT INTO `matrices_completed` VALUES(7, 1, 1615207566);
INSERT INTO `matrices_completed` VALUES(8, 27, 1615213434);
INSERT INTO `matrices_completed` VALUES(9, 36, 1615223675);
INSERT INTO `matrices_completed` VALUES(10, 37, 1615223705);
INSERT INTO `matrices_completed` VALUES(11, 38, 1615223733);
INSERT INTO `matrices_completed` VALUES(12, 39, 1615223765);
INSERT INTO `matrices_completed` VALUES(13, 40, 1615223767);
INSERT INTO `matrices_completed` VALUES(14, 45, 1615285004);
INSERT INTO `matrices_completed` VALUES(15, 41, 1615294825);
INSERT INTO `matrices_completed` VALUES(16, 57, 1615298763);


DROP TABLE IF EXISTS matrix;
CREATE TABLE `matrix` (
  `matrix_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_level` int(11) DEFAULT 0,
  `host_id` int(11) DEFAULT 0,
  `host_matrix` int(11) DEFAULT 0,
  `referrer_id` int(11) DEFAULT 0,
  `referrer_matrix` int(11) DEFAULT 0,
  `member_id` int(11) DEFAULT 0,
  `member_matrix` int(11) DEFAULT 0,
  `z_date` int(11) DEFAULT 0,
  `is_completed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`matrix_id`),
  KEY `host_id_idx` (`host_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `referrer_id_idx` (`referrer_id`),
  KEY `m_level_idx` (`m_level`),
  KEY `host_matrix_idx` (`host_matrix`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `matrix` VALUES(1, 0, 22, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(2, 2, 23, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(3, 1, 24, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(4, 1, 25, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(5, 1, 26, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(6, 1, 34, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(7, 1, 43, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `matrix` VALUES(8, 0, 52, 1, 0, 0, 0, 0, 0, 0);


DROP TABLE IF EXISTS matrixes;
CREATE TABLE `matrixes` (
  `matrix_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `width` int(3) DEFAULT 0,
  `depth` int(3) DEFAULT 0,
  `entrance_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_mode` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`matrix_id`),
  KEY `title_idx` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `matrixes` VALUES(1, 'Forced Matrix', 2, 1, '10.00', 1, 1);
INSERT INTO `matrixes` VALUES(2, 'Cycling Matrix', 2, 2, '10050.00', 0, 0);


DROP TABLE IF EXISTS members;
CREATE TABLE `members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `replica` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_replica` tinyint(1) NOT NULL DEFAULT 0,
  `is_a_replica` tinyint(1) NOT NULL DEFAULT 0,
  `enroller_id` int(11) NOT NULL DEFAULT 0,
  `passwd` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `email` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `first_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `street` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `city` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `state` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `country` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `postal` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `phone` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT 0,
  `last_access` int(11) NOT NULL DEFAULT 0,
  `m_level` int(3) NOT NULL DEFAULT 0,
  `processor` int(11) NOT NULL DEFAULT 0,
  `account_id` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `account_name` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `bank_address` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `bank_name` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `quant_pay` int(5) NOT NULL DEFAULT 0,
  `ip_check` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `pin_code` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_dead` tinyint(1) NOT NULL DEFAULT 0,
  `date_active` int(11) DEFAULT 0,
  `b1` int(11) DEFAULT 0,
  `b3` int(11) DEFAULT 0,
  `b5` int(11) DEFAULT 0,
  `prelaunch_norif` int(1) DEFAULT 0,
  `alert_data` text /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `username_idx` (`username`),
  KEY `reg_date_idx` (`reg_date`)
) ENGINE=MyISAM AUTO_INCREMENT=54 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `members` VALUES(1, 'admin', '', 0, 0, 0, '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', 'Admin', 'Admin', '', '', '', '', '', '', 1614766348, 0, 1, 0, '', '', '', '', 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(9, 'Mekanems', '', 0, 0, 1, '6c359c586d656ea74e5804afad6148c4', 'p5holyland@gmail.com', 'Michael', 'Ekanem', '', '', '', '', '', '08155444440', 1615048686, 1615048717, 3, 0, '0019553679', 'Michael Ekanem', '', 'First Bank', 0, 0, '197.210.70.56', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(10, 'Glorious', '', 0, 0, 9, '6c359c586d656ea74e5804afad6148c4', 'Gloiaw@gmail.com', 'Gloria', 'Michael', '', '', '', '', '', '08065684330', 1615056130, 1615056166, 2, 0, '0739410176', 'Gloria teju Michael', '', 'Access', 0, 0, '197.210.71.153', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(11, 'Angelima', '', 0, 0, 9, '6c359c586d656ea74e5804afad6148c4', 'angel4@yahoo.com', 'Angel', 'Ima', '', '', '', '', '', '0897765543', 1615057249, 1615057294, 2, 0, '0012725608', 'Angel I&#039;ma favour Michael', '', 'Access', 0, 0, '197.210.70.1', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(12, 'Vanny', '', 0, 0, 9, '6c359c586d656ea74e5804afad6148c4', 'Vany3@yahoo.com', 'Vanessa', 'Princess', '', '', '', '', '', '08077666665', 1615057819, 1615057842, 2, 0, '0000965269', 'Vannesa Michael', '', 'Stannic ibtc', 0, 0, '197.210.71.153', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(13, 'Smart', '', 0, 0, 9, '6c359c586d656ea74e5804afad6148c4', 'Smart13@yahoo.com', 'Smart', 'Mona', '', '', '', '', '', '09088877665', 1615058271, 1615058290, 2, 0, '0000966077', 'Smart Mona Michael', '', 'Stanbic ibtc', 0, 0, '197.210.71.68', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(14, 'Mekanems12', '', 0, 0, 10, '6c359c586d656ea74e5804afad6148c4', 'Mekus2@yahoo.com', 'Mekanem', 'Samuel', '', '', '', '', '', '069775432', 1615063201, 1615063230, 1, 0, '2032642456', 'Project 5 network', '', 'First Bank', 0, 0, '197.210.71.165', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(15, 'Pensummit', '', 0, 0, 10, '6c359c586d656ea74e5804afad6148c4', 'Pen33@gmail.com', 'Pen', 'Summit', '', '', '', '', '', '08066644443', 1615063745, 1615063804, 1, 0, '0426115176', 'Project 5 network', '', 'Gtbank', 0, 0, '197.210.71.165', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(16, 'Welfarezone', '', 0, 0, 11, '6c359c586d656ea74e5804afad6148c4', 'Welfare23@gmail.com', 'Christian', 'Welfare', '', '', '', '', '', '063325647', 1615064801, 1615064827, 2, 0, '0019553679', 'Michael Ekanem', '', 'Gtbank', 0, 0, '197.210.53.172', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(17, 'Holyland', '', 0, 0, 11, '6c359c586d656ea74e5804afad6148c4', 'Holy64@yahoo.com', 'Holyland', 'Tours', '', '', '', '', '', '089766543', 1615065317, 1615065362, 1, 0, '2032642456', 'Project 5 network', '', 'First Bank', 0, 0, '197.210.53.172', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(18, 'Ekwere', '', 0, 0, 11, '6c359c586d656ea74e5804afad6148c4', 'Umoh3@yahoo.com', 'Ekwere', 'Umoh', '', '', '', '', '', '0907776535', 1615065900, 1615065948, 1, 0, '0019553679', 'Michael Ekanem', '', 'Gtbank', 0, 0, '197.210.77.40', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(19, 'Penhome', '', 0, 0, 12, '6c359c586d656ea74e5804afad6148c4', 'Pen54@gmail.com', 'Pen', 'Home', '', '', '', '', '', '038776553', 1615066256, 1615066281, 1, 0, '0426115176', 'Project 5 network', '', 'Gtbank', 0, 0, '197.210.76.242', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(20, 'Smartkids', '', 0, 0, 12, '6c359c586d656ea74e5804afad6148c4', 'Otto22@yahoo.com', 'Oto', 'Obong', '', '', '', '', '', '066579487', 1615066578, 1615066620, 1, 0, '0426115176', 'Project 5 network', '', 'Gtbank', 0, 0, '197.210.77.92', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(21, 'Pentravels', '', 0, 0, 12, '6c359c586d656ea74e5804afad6148c4', 'Pen18@yahoo.com', 'Pen', 'Travels', '', '', '', '', '', '0987765448', 1615067153, 1615067176, 1, 0, '2032642456', 'Project 5 network', '', 'First Bank', 0, 0, '197.210.77.40', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(22, 'Nitro4Christ', '', 0, 0, 13, 'ec8b6288783d7759744aa689a7948670', 'imerobin15@gmail.com', 'Ime', 'Umiom', '', '', '', '', '', '08066883729', 1615206434, 1615300372, 1, 0, '2085021237', 'Ime Robin Umiom', '', 'Zenith bank', 0, 0, '197.210.8.235', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(23, 'AM4JESUS', '', 0, 0, 13, '21d8485f74b7a8993d81f4b66dbb03b8', 'aayobamidelelawal@gmail.com', 'Lawal', 'Ayobamidele', '', '', '', '', '', '08034581962', 1615207242, 1615305136, 1, 0, '0149376517', 'Ayobamidele Lawal', '', 'GTBank', 0, 0, '41.190.14.22', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(24, 'Hsquare', '', 0, 0, 13, 'e67c10a4c8fbfc0c400e047bb9a056a1', 'amonind@yahoo.com', 'Amonia', 'Ubogu', '', '', '', '', '', '08105579225', 1615209120, 1615209174, 1, 0, '2058837047', 'Amonia ubogu', '', 'UBA', 0, 0, '197.210.77.88', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(25, 'Aaronplc', '', 0, 0, 14, '42bc978dc2d8f9ca83551484b092714f', 'aaron2naron@gmail.com', 'Aaron', 'Nwali', '', '', '', '', '', '08034170345', 1615211879, 1615212210, 1, 0, '0060517632', 'Nwali Friday Aaron', '', 'Access Bank', 0, 0, '105.112.114.95', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(26, 'Ahunna', '', 0, 0, 14, 'fdd9e8101931da260f216ca00f0f830d', 'hunnynnia@yahoo.com', 'Ahunna', 'Enyinnia', '', '', '', '', '', '07068252289', 1615212025, 1615298821, 2, 0, '2017933212', '2017933212', '', 'ENYINNIA Ahunna', 0, 0, '197.210.76.184', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(27, 'Ugonnia', '', 0, 0, 26, '629d42d75a9a30eff8af971eb7db2326', 'enyinniaahunna2016@gmail.com', 'Ugonnia', 'Enyinnia', '', '', '', '', '', '07068252289', 1615214430, 1615214486, 1, 0, '2017933212', 'First Bank', '', 'ENYINNIA Ahunna', 0, 0, '197.210.76.107', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(31, 'justyce', '', 0, 0, 9, '0b282035e137b497601c8922efb25272', 'justicechinemelum@gmail.com', 'justice', 'Clement', '', '', '', '', '', '07062487290', 1615219276, 1615293486, 0, 0, '0045989639', 'justice clement', '', 'GTBANK', 0, 0, '105.112.124.252', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(32, 'nonyecee', '', 0, 0, 16, '3eb328b9d057516a5bb6f85d8da72cfc', 'nonyecee@gmail.com', 'Okechi', 'Costiancia Chinyere', '', '', '', '', '', '08038819711', 1615282815, 1615286357, 1, 0, '303391498', 'Okechi costiancia chinyere', '', 'First Bank', 0, 0, '197.210.71.40', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(33, 'Pamdak', '', 0, 0, 16, '6706864efed41f45d95ca45082f1a802', 'pamdakpd@gmail.com', 'PAMELA SHEYIL', 'DAKAR', '', '', '', '', '', '08034114258', 1615284165, 1615284703, 1, 0, '0218066640', 'PAMELA SHEYIL DAKAR', '', 'GTBANK', 0, 0, '102.89.3.230', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(34, 'Dabying', '', 0, 0, 16, 'ce138173c154affab127547e0d65e2c7', 'yingialaiboroma@gmail.com', 'yingiala', 'iboroma', '', '', '', '', '', '08064414001', 1615284215, 1615284251, 1, 0, '2017450337', 'Yingiala Iboroma', '', 'UBA', 0, 0, '169.159.107.76', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(37, 'Maryrose05', '', 0, 0, 32, '3eb328b9d057516a5bb6f85d8da72cfc', 'okemaryrose7@gmail.com', 'Okechi', 'Maryrose', '', '', '', '', '', '07013899966', 1615287246, 1615287634, 1, 0, '3033914098', 'Okechi costiancia chinyere', '', 'First Bank', 0, 0, '197.210.71.40', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(35, 'Grace20', '', 0, 0, 32, '3eb328b9d057516a5bb6f85d8da72cfc', 'tianciaokechi@gmail.com', 'Okechi', 'Grace', '', '', '', '', '', '09069660006', 1615285163, 0, 0, 0, '3033914098', 'Okechi costiancia chinyere', '', 'First Bank', 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(36, 'Gideon13', '', 0, 0, 32, '3eb328b9d057516a5bb6f85d8da72cfc', 'okechinonye263@gmail.com', 'Okechi', 'Gideon', '', '', '', '', '', '08168685025', 1615286342, 0, 0, 0, '3033914098', 'Okechi costiancia chinyere', '', 'First Bank', 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(39, 'Nimma', '', 0, 0, 17, '07743fd3f0c9130bbba5597ebd26d956', 'designden34@gmail.com', 'RoseAkale', 'Dangana', '', '', '', '', '', '+2348069641303', 1615291612, 1615291686, 1, 0, '2176155029', 'RoseAkale Dangana', '', 'Zenith', 0, 0, '197.210.71.214', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(43, 'Gwendee', '', 0, 0, 17, 'bcafc9e794660417b675127862b803a8', 'Iyefuochemeh@gmail.com', 'Grace', 'Ochemeh', '', '', '', '', '', '08138837447', 1615293932, 1615293995, 1, 0, '0044284037', 'Grace ochemeh', '', 'Access bank', 0, 0, '197.210.76.131', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(41, 'Favour', '', 0, 0, 17, '29da81cad8a7dd54be51328e818329f1', 'nddesignet2021@gmail.com', 'Favour ndidi', 'Okorafor', '', '', '', '', '', '08069114702', 1615292309, 1615292875, 1, 0, '1018719413', 'Favour Ndidi okorafor', '', 'Polaris bank', 0, 0, '105.112.112.11', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(44, 'Lumtice', '', 0, 0, 17, 'f0a7766c9d882b2737c8d8892a70560e', 'justicechinemelum2@gmail.com', 'Justice', 'Clement', '', '', '', '', '', '0000', 1615294218, 1615294231, 0, 0, '00000', 'Justice', '', 'Gtbank', 0, 0, '105.112.117.89', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(45, 'Chizzy', '', 0, 0, 26, '7c8f06bc08b584f84901a1ddbf9412e7', 'chizzienyinnia@gmail.com', 'Enyinnia', 'Chiziterem', '', '', '', '', '', '07068252289', 1615297841, 1615298306, 1, 0, '2017933212', 'First Bank', '', 'ENYINNIA Ahunna', 0, 0, '197.210.52.17', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(46, 'Kelly', '', 0, 0, 26, 'df2f85f97a34753ba66b9091b7bcf559', 'kellyenyinnia@yahoo.com', 'Enyinnia', 'Kelechi', '', '', '', '', '', '07068252289', 1615298225, 1615298257, 1, 0, '2017933121', 'ENYINNIA Ahunna', '', 'First Bank', 0, 0, '197.210.52.17', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(47, 'Nkechi', '', 0, 0, 18, 'c276ffe8c344a16d1f0d3f3116430519', 'joejosh14@gmail.com', 'Nkechi', 'Ikoro', '', '', '', '', '', '08037865960', 1615300078, 1615303314, 1, 0, '0039273897', '0039273897', '', 'Access Bank', 0, 0, '197.210.44.21', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(48, 'Ebehi4', '', 0, 0, 23, '90cea5e79a20ca5b50ce76c6b7c63dc8', 'euniceayobamidele@gmail.com', 'Eunice', 'Ayobamidele', '', '', '', '', '', '08054445818', 1615300392, 1615302563, 1, 0, '0766900875', 'Eunice A Ayobamidele', '', 'Access', 0, 0, '41.190.14.22', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(49, 'Anyim', '', 0, 0, 47, 'c276ffe8c344a16d1f0d3f3116430519', 'ancikoro022@gmail.com', 'Anyim', 'Ikoro', '', '', '', '', '', '08037865960', 1615301286, 1615303811, 0, 0, '0039273897', 'Ikoro Nkechi', '', 'Access Bank', 0, 0, '197.210.44.21', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(50, 'Christyzest', '', 0, 0, 41, '1b78a8f3c82a80a83370e8c1228d5cd7', 'christyzest143@yahoo.com', 'James', 'Christiana', '', '', '', '', '', '08117449904', 1615301418, 1615301560, 0, 0, '2089397712', 'James Christiana', '', 'Uba', 0, 0, '129.205.113.59', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(51, 'nkanc4324', '', 0, 0, 47, 'c276ffe8c344a16d1f0d3f3116430519', 'goldbaby12@gmail.com', 'Gold', 'Ikoro', '', '', '', '', '', '080355328', 1615305584, 0, 0, 0, '0039273897', '0039273897', '', 'Access Bank', 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(52, 'Enobong', '', 0, 0, 22, 'e10adc3949ba59abbe56e057f20f883e', 'enobongrobin@yahoo.com', 'Enobong', 'Robin', '', '', '', '', '', '07068069610', 1615310586, 0, 0, 0, '0124726481', 'Enobong Robin', '', 'Guarantee Trust Bank', 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, NULL);
INSERT INTO `members` VALUES(53, 'lumtice3', '', 0, 0, 1, 'f0a7766c9d882b2737c8d8892a70560e', 'lumticeonline@gmail.com', 'justice', 'Clement', '', '', '', '', '', '07062487290', 1615324646, 1615324662, 0, 0, '0040404', 'Justice Clement', '', 'GTBANK', 0, 0, '105.112.115.120', '', 1, 0, 0, 0, 0, 0, 0, NULL);


DROP TABLE IF EXISTS messages;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txid` varchar(64) DEFAULT NULL,
  `member_id` int(11) DEFAULT 0,
  `name_member_id` int(11) DEFAULT 0,
  `to_member_id` int(11) DEFAULT 0,
  `subject` varchar(512) DEFAULT '',
  `body` text DEFAULT NULL,
  `date` int(11) DEFAULT 0,
  `attach` varchar(1024) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `messages` VALUES(63, '2ae67f3b83cac9772b8f90ec83090d9b', 1, 3, 3, 'My message', '', 1484636813, NULL, 0, 0);
INSERT INTO `messages` VALUES(55, '702641fc024fb873c69e6c4ef465f37f', 1, 2, 2, 'RE: 1&amp;gt;2', '', 1484393922, NULL, 0, 0);
INSERT INTO `messages` VALUES(56, '226786203465ecfa01815f44508bf620', 2, 1, 2, 'RE: 1&amp;gt;2', '', 1484393922, NULL, 1, 0);
INSERT INTO `messages` VALUES(61, 'dbac849aee88d6d73722aca3e628a5e0', 1, 2, 2, '1&amp;gt;2', '', 1484394819, '34351071.jpg', 1, 0);
INSERT INTO `messages` VALUES(62, '86a2fe69475e04648680e657a9b90230', 2, 1, 2, '1&amp;gt;2', '', 1484394819, '34351071.jpg', 0, 0);
INSERT INTO `messages` VALUES(58, '161b4820f922a8e6d24b60aa6beade52', 1, 2, 1, 'RE: 1&amp;gt;2', '', 1484394226, NULL, 1, 0);
INSERT INTO `messages` VALUES(53, '557547181d19b91977a666dd7dc66ece', 1, 2, 2, '1&amp;gt;2', '', 1484393874, NULL, 1, 0);
INSERT INTO `messages` VALUES(54, '0024c94a13756ba0d009676f718b1c95', 2, 1, 2, '1&amp;gt;2', '', 1484393874, NULL, 1, 0);
INSERT INTO `messages` VALUES(60, 'd2a8890edd87d09153813cb3dfede0f6', 1, 2, 1, 'RE: RE: 1&amp;gt;2', '', 1484394237, NULL, 1, 0);
INSERT INTO `messages` VALUES(93, '309fda9c60b55fa77413a7b2cebccd49', 1, 3, 3, 'RE: hi Attach', 'Glad to hear you', 1484739922, '34351071.jpg', 0, 0);
INSERT INTO `messages` VALUES(92, 'ee52c6c5f0632bce6871b5101680edcd', 3, 1, 3, 'RE: hi', 'Very nice picture', 1484739880, NULL, 1, 0);
INSERT INTO `messages` VALUES(66, '20d003dd105af52a3663b6e1074b3fd0', 1, 3, 1, 'RE: My message', 'cool', 1484636887, NULL, 1, 0);
INSERT INTO `messages` VALUES(68, 'e158a0c11918988030fd922d176db73b', 1, 3, 1, 'RE: My message', '', 1484733819, NULL, 1, 0);
INSERT INTO `messages` VALUES(91, '771866731bcc6272b50c9ef146643492', 1, 3, 3, 'RE: hi', 'Very nice picture', 1484739880, NULL, 0, 0);
INSERT INTO `messages` VALUES(70, '0b21805b1430fd673b40885d4451378c', 1, 3, 1, 'RE: My message', '', 1484733852, NULL, 1, 0);
INSERT INTO `messages` VALUES(90, 'ad6b204b25effcc5861dc68844820f78', 1, 3, 1, 'hi', 'Glad to hear you', 1484739762, 'test.jpg', 1, 0);
INSERT INTO `messages` VALUES(72, '7efe24f0528ab1bfe00ad786b370a486', 2, 3, 2, 'hi', 'ge', 1484734300, NULL, 1, 0);
INSERT INTO `messages` VALUES(73, '88e71544bda053f7ee04dfed8b8f4be0', 2, 3, 3, 'RE: hi', 'hi there', 1484734332, NULL, 1, 0);
INSERT INTO `messages` VALUES(89, '2d753264a84106a023d6ea04cdb507f4', 3, 1, 1, 'hi', 'Glad to hear you', 1484739762, 'test.jpg', 0, 0);
INSERT INTO `messages` VALUES(76, '46afefb7c81d8b17bbd8e9899dcec645', 2, 3, 2, 'RE: RE: hi', 'gfg', 1484734364, NULL, 0, 0);
INSERT INTO `messages` VALUES(88, '96381b1697c37a8fbc22ce740ef5ed80', 3, 1, 3, 'RE: Hi admin', 'Hi test1!\r\n\r\n\r\nhere is the text', 1484739732, NULL, 1, 0);
INSERT INTO `messages` VALUES(78, 'e3fe578f8090f3d8c19ca89d31278fd5', 2, 3, 2, 'RE: RE: RE: hi', 'gfg', 1484734375, 'Customer-support-girl-wearing-headsets.jpg', 1, 0);
INSERT INTO `messages` VALUES(79, 'd3523b72cea372b0f714b08d330c1129', 2, 3, 3, 'RE: RE: RE: RE: hi', 'cool', 1484734425, NULL, 1, 0);
INSERT INTO `messages` VALUES(87, 'b91c06674dec97604360c56a518d7c32', 1, 3, 3, 'RE: Hi admin', 'Hi test1!\r\n\r\n\r\nhere is the text', 1484739732, NULL, 0, 0);
INSERT INTO `messages` VALUES(81, '6b4c6bd48cac3a0b3084a997ba4c6f04', 2, 3, 3, 'RE: RE: RE: RE: hi', 'gfg', 1484734445, NULL, 0, 0);
INSERT INTO `messages` VALUES(86, '7ecec086abcf18ca40b0de83d975cdd3', 1, 3, 1, 'Hi admin', 'here is the text', 1484739706, NULL, 1, 0);
INSERT INTO `messages` VALUES(84, '4cec0832e9c93a2dcae15f05395de8c1', 2, 3, 2, 'RE: RE: RE: RE: RE: hi', 'gfg', 1484734473, NULL, 0, 0);
INSERT INTO `messages` VALUES(85, 'ec3fd10387bb3384833872accf616547', 3, 1, 1, 'Hi admin', 'here is the text', 1484739706, NULL, 0, 0);
INSERT INTO `messages` VALUES(94, 'b913cd81c94887855edad883075459a3', 3, 1, 3, 'RE: hi Attach', 'Glad to hear you', 1484739922, '34351071.jpg', 1, 0);


DROP TABLE IF EXISTS news;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_date` int(11) NOT NULL DEFAULT 0,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `article` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `photo` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `destination` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`news_id`),
  KEY `news_date_idx` (`news_date`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS online_stats;
CREATE TABLE `online_stats` (
  `online_stat_id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `member_id` int(11) NOT NULL DEFAULT 0,
  `z_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`online_stat_id`),
  KEY `session_id_idx` (`session_id`),
  KEY `member_id_idx` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=231 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `online_stats` VALUES(230, '2023nlko3hgn0abho77ni69595', 0, 1615326055);


DROP TABLE IF EXISTS pages;
CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index` int(5) NOT NULL DEFAULT 0,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `menu_title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `content` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `in_menu` tinyint(1) NOT NULL DEFAULT 0,
  `is_member` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `level1` tinyint(1) NOT NULL DEFAULT 0,
  `level2` tinyint(1) NOT NULL DEFAULT 0,
  `level3` tinyint(1) NOT NULL DEFAULT 0,
  `level4` tinyint(1) NOT NULL DEFAULT 0,
  `level5` tinyint(1) NOT NULL DEFAULT 0,
  `level6` tinyint(1) NOT NULL DEFAULT 0,
  `level7` tinyint(1) NOT NULL DEFAULT 0,
  `level8` tinyint(1) NOT NULL DEFAULT 0,
  `level9` tinyint(1) NOT NULL DEFAULT 0,
  `level10` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`page_id`),
  KEY `order_index_idx` (`order_index`)
) ENGINE=MyISAM AUTO_INCREMENT=10 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `pages` VALUES(1, 1, 'Start Page', 'Home', '', '', '', 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `pages` VALUES(2, 1, 'Terms and Conditions', 'Terms and Conditions', 'Coming Soon...', '', '', 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);


DROP TABLE IF EXISTS payins;
CREATE TABLE `payins` (
  `payins_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `transaction_id` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `processor` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `z_date` int(11) NOT NULL DEFAULT 0,
  `product_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`payins_id`),
  KEY `transaction_id_idx` (`transaction_id`),
  KEY `member_id_idx` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `payins` VALUES(44, 32, '381393431', '10050.00', '12', 'Member payment', 1615283090, 0);
INSERT INTO `payins` VALUES(43, 26, '1615223994', '10050.00', '-1', 'Member payment', 1615223994, 0);
INSERT INTO `payins` VALUES(42, 25, '380903167', '10050.00', '12', 'Member payment', 1615223965, 0);
INSERT INTO `payins` VALUES(41, 24, '1615223935', '10050.00', '-1', 'Member payment', 1615223935, 0);
INSERT INTO `payins` VALUES(40, 23, '380873620', '10050.00', '12', 'Member payment', 1615223894, 0);
INSERT INTO `payins` VALUES(39, 21, '1615223763', '10050.00', '-1', 'Member payment', 1615223763, 0);
INSERT INTO `payins` VALUES(38, 20, '1615223753', '10050.00', '-1', 'Member payment', 1615223753, 0);
INSERT INTO `payins` VALUES(37, 19, '1615223743', '10050.00', '-1', 'Member payment', 1615223743, 0);
INSERT INTO `payins` VALUES(36, 18, '1615223731', '10050.00', '-1', 'Member payment', 1615223731, 0);
INSERT INTO `payins` VALUES(35, 17, '1615223720', '10050.00', '-1', 'Member payment', 1615223720, 0);
INSERT INTO `payins` VALUES(34, 16, '1615223712', '10050.00', '-1', 'Member payment', 1615223712, 0);
INSERT INTO `payins` VALUES(33, 15, '1615223703', '10050.00', '-1', 'Member payment', 1615223703, 0);
INSERT INTO `payins` VALUES(32, 14, '1615223696', '10050.00', '-1', 'Member payment', 1615223696, 0);
INSERT INTO `payins` VALUES(31, 13, '1615223685', '10050.00', '-1', 'Member payment', 1615223685, 0);
INSERT INTO `payins` VALUES(30, 12, '1615223673', '10050.00', '-1', 'Member payment', 1615223673, 0);
INSERT INTO `payins` VALUES(29, 11, '1615223666', '10050.00', '-1', 'Member payment', 1615223666, 0);
INSERT INTO `payins` VALUES(28, 10, '379808091', '10000.00', '12', 'Member payment', 1615223523, 0);
INSERT INTO `payins` VALUES(27, 9, '379755332', '10000.00', '12', 'Member payment', 1615223447, 0);
INSERT INTO `payins` VALUES(45, 34, '1615284772', '10050.00', '-1', 'Member payment', 1615284772, 0);
INSERT INTO `payins` VALUES(46, 33, '1615285002', '10050.00', '-1', 'Member payment', 1615285002, 0);
INSERT INTO `payins` VALUES(47, 37, '381433083', '10050.00', '12', 'Member payment', 1615287753, 0);
INSERT INTO `payins` VALUES(48, 27, '1615290810', '10050.00', '-1', 'Member payment', 1615290810, 0);
INSERT INTO `payins` VALUES(49, 39, '381463253', '10050.00', '12', 'Member payment', 1615291948, 0);
INSERT INTO `payins` VALUES(50, 41, '381468912', '10050.00', '12', 'Member payment', 1615293019, 0);
INSERT INTO `payins` VALUES(51, 43, '1615294823', '10050.00', '-1', 'Member payment', 1615294823, 0);
INSERT INTO `payins` VALUES(52, 22, '381505052', '10050.00', '12', 'Member payment', 1615298628, 0);
INSERT INTO `payins` VALUES(53, 45, '1615298748', '10050.00', '-1', 'Member payment', 1615298748, 0);
INSERT INTO `payins` VALUES(54, 46, '1615298761', '10050.00', '-1', 'Member payment', 1615298761, 0);
INSERT INTO `payins` VALUES(55, 47, '381519883', '10050.00', '12', 'Member payment', 1615300434, 0);
INSERT INTO `payins` VALUES(56, 48, '381535352', '10050.00', '12', 'Member payment', 1615302687, 0);


DROP TABLE IF EXISTS payins_log;
CREATE TABLE `payins_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` text /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `processor` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `z_date` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS places;
CREATE TABLE `places` (
  `place_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT 0,
  `referrer_place_id` int(11) DEFAULT 0,
  `m_level` int(11) DEFAULT 0,
  `reentry` int(5) NOT NULL DEFAULT 0,
  `z_date` int(11) DEFAULT 0,
  PRIMARY KEY (`place_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `referrer_place_id_idx` (`referrer_place_id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `places` VALUES(1, 1, 0, 1, 1, 1614766348);
INSERT INTO `places` VALUES(69, 45, 57, 1, 1, 1615298750);
INSERT INTO `places` VALUES(68, 22, 54, 1, 1, 1615298630);
INSERT INTO `places` VALUES(67, 13, 44, 2, 1, 1615294827);
INSERT INTO `places` VALUES(66, 43, 41, 1, 1, 1615294825);
INSERT INTO `places` VALUES(65, 41, 46, 1, 1, 1615293021);
INSERT INTO `places` VALUES(64, 39, 46, 1, 1, 1615291950);
INSERT INTO `places` VALUES(63, 27, 57, 1, 1, 1615290812);
INSERT INTO `places` VALUES(62, 37, 58, 1, 1, 1615287755);
INSERT INTO `places` VALUES(61, 16, 48, 2, 1, 1615285006);
INSERT INTO `places` VALUES(60, 33, 45, 1, 1, 1615285004);
INSERT INTO `places` VALUES(59, 34, 45, 1, 1, 1615284774);
INSERT INTO `places` VALUES(58, 32, 45, 1, 1, 1615283092);
INSERT INTO `places` VALUES(57, 26, 42, 1, 1, 1615223996);
INSERT INTO `places` VALUES(56, 25, 42, 1, 1, 1615223967);
INSERT INTO `places` VALUES(55, 24, 41, 1, 1, 1615223937);
INSERT INTO `places` VALUES(54, 23, 41, 1, 1, 1615223896);
INSERT INTO `places` VALUES(53, 9, 0, 3, 1, 1615223769);
INSERT INTO `places` VALUES(52, 12, 40, 2, 1, 1615223767);
INSERT INTO `places` VALUES(51, 21, 39, 1, 1, 1615223765);
INSERT INTO `places` VALUES(50, 20, 39, 1, 1, 1615223755);
INSERT INTO `places` VALUES(49, 19, 39, 1, 1, 1615223745);
INSERT INTO `places` VALUES(48, 11, 40, 2, 1, 1615223735);
INSERT INTO `places` VALUES(47, 18, 38, 1, 1, 1615223733);
INSERT INTO `places` VALUES(46, 17, 38, 1, 1, 1615223722);
INSERT INTO `places` VALUES(45, 16, 38, 1, 1, 1615223714);
INSERT INTO `places` VALUES(44, 10, 40, 2, 1, 1615223707);
INSERT INTO `places` VALUES(43, 15, 37, 1, 1, 1615223705);
INSERT INTO `places` VALUES(42, 14, 37, 1, 1, 1615223698);
INSERT INTO `places` VALUES(41, 13, 37, 1, 1, 1615223687);
INSERT INTO `places` VALUES(40, 9, 0, 2, 1, 1615223677);
INSERT INTO `places` VALUES(39, 12, 36, 1, 1, 1615223675);
INSERT INTO `places` VALUES(38, 11, 36, 1, 1, 1615223668);
INSERT INTO `places` VALUES(37, 10, 36, 1, 1, 1615223525);
INSERT INTO `places` VALUES(36, 9, 0, 1, 1, 1615223449);
INSERT INTO `places` VALUES(70, 46, 57, 1, 1, 1615298763);
INSERT INTO `places` VALUES(71, 26, 44, 2, 1, 1615298765);
INSERT INTO `places` VALUES(72, 47, 47, 1, 1, 1615300436);
INSERT INTO `places` VALUES(73, 48, 54, 1, 1, 1615302689);


DROP TABLE IF EXISTS processors;
CREATE TABLE `processors` (
  `processor_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `name` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `account_id` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `routine_url` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `extra_field` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`processor_id`),
  KEY `code_idx` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=14 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `processors` VALUES(3, 'alertpay', 'Payza', '', 'https://secure.payza.com/checkout', '', '0.00', 0);
INSERT INTO `processors` VALUES(5, 'solidtrustpay', 'Solid Trust Pay', '', 'https://solidtrustpay.com/handle.php', '', '0.00', 0);
INSERT INTO `processors` VALUES(8, 'paypal', 'PayPal', '', 'https://www.paypal.com/cgi-bin/webscr', '', '0.00', 0);
INSERT INTO `processors` VALUES(9, 'perfectmoney', 'PerfectMoney', '', 'https://perfectmoney.is/api/step1.asp', '', '0.00', 0);
INSERT INTO `processors` VALUES(10, 'egopay', 'EgoPay', '', 'https://www.egopay.com/payments/pay/form', '', '0.00', 0);
INSERT INTO `processors` VALUES(7, 'okpay', 'OkPay', '', 'https://www.okpay.com/process.html', '', '0.00', 0);
INSERT INTO `processors` VALUES(12, 'flutterwave', 'Debit Cards, Bank, USSD', 'FLWPUBK-d9176c2d4032bc693d285009a68cb9cc-X', 'https://checkout.flutterwave.com/v3/hosted/pay', '', '0.00', 1);
INSERT INTO `processors` VALUES(13, 'bank', 'Bank', '', '#', '', '0.00', 0);


DROP TABLE IF EXISTS products;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `file` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `photo` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`),
  KEY `price_idx` (`price`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS ptools;
CREATE TABLE `ptools` (
  `ptool_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `link` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `photo` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ptool_id`),
  KEY `title_idx` (`title`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS pub_ticket_messages;
CREATE TABLE `pub_ticket_messages` (
  `pub_ticket_message_id` int(11) NOT NULL AUTO_INCREMENT,
  `pub_ticket_id` int(11) NOT NULL DEFAULT 0,
  `support_message` tinyint(1) NOT NULL DEFAULT 0,
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `date_post` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`pub_ticket_message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS pub_tickets;
CREATE TABLE `pub_tickets` (
  `pub_ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `email` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `ticket_code` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `subject` varchar(150) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `date_create` int(11) NOT NULL DEFAULT 0,
  `last_update` int(11) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`pub_ticket_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS replicas;
CREATE TABLE `replicas` (
  `replica_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index` int(11) NOT NULL DEFAULT 0,
  `member_id` int(5) NOT NULL DEFAULT 0,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `menu_title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `content` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`replica_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `order_index_idx` (`order_index`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `replicas` VALUES(6, 1, 1, 'test', 'PDF', '&lt;p&gt;&amp;nbsp;кен&lt;/p&gt;', 1);


DROP TABLE IF EXISTS selected;
CREATE TABLE `selected` (
  `selected_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`selected_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `selected` VALUES(2, 1);
INSERT INTO `selected` VALUES(3, 31);


DROP TABLE IF EXISTS settings;
CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyname` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `value` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `key1` (`keyname`)
) ENGINE=MyISAM AUTO_INCREMENT=72 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `settings` VALUES(1, 'AdminUsername', 'admin');
INSERT INTO `settings` VALUES(2, 'AdminPassword', '21232f297a57a5a743894a0e4a801fc3');
INSERT INTO `settings` VALUES(3, 'AdminAltPassword', '21232f297a57a5a743894a0e4a801fc3');
INSERT INTO `settings` VALUES(4, 'SiteTitle', 'I STAND WITH JESUS');
INSERT INTO `settings` VALUES(5, 'SiteUrl', 'http://ng.istandwithjesus.org/');
INSERT INTO `settings` VALUES(6, 'PathSite', '/home/pensummi/public_html/ng/');
INSERT INTO `settings` VALUES(7, 'ContactEmail', 'support@istandwithjesus.org');
INSERT INTO `settings` VALUES(8, 'UseSMTPAutorisation', '1');
INSERT INTO `settings` VALUES(9, 'SMTPServer', 'mail.istandwithjesus.org');
INSERT INTO `settings` VALUES(10, 'SMTPDomain', 'mail.istandwithjesus.org');
INSERT INTO `settings` VALUES(11, 'SMTPUserName', 'support@istandwithjesus.org');
INSERT INTO `settings` VALUES(12, 'SMTPPassword', 'W8xn%X[a9VTw');
INSERT INTO `settings` VALUES(13, 'SecurityMode', '');
INSERT INTO `settings` VALUES(14, 'IPAddress', '');
INSERT INTO `settings` VALUES(15, 'pin_code', '');
INSERT INTO `settings` VALUES(16, 'PaymentMode', '1');
INSERT INTO `settings` VALUES(17, 'PaymentModeDate', '1613135472');
INSERT INTO `settings` VALUES(18, 'payPeriod', '7');
INSERT INTO `settings` VALUES(19, 'monthPeriod', '999');
INSERT INTO `settings` VALUES(20, 'LastCronjobStart', '1615020689');
INSERT INTO `settings` VALUES(21, 'MinCashOut', '1000.00');
INSERT INTO `settings` VALUES(22, 'warnPeriod', '5');
INSERT INTO `settings` VALUES(23, 'matrix_mode', '3');
INSERT INTO `settings` VALUES(24, 'fee', '0.00');
INSERT INTO `settings` VALUES(25, 'PhotoBigMaxWidth', '400');
INSERT INTO `settings` VALUES(26, 'PhotoBigMaxHeight', '400');
INSERT INTO `settings` VALUES(27, 'PhotoSmallMaxWidth', '120');
INSERT INTO `settings` VALUES(28, 'PhotoSmallMaxHeight', '120');
INSERT INTO `settings` VALUES(29, 'cycling', '1');
INSERT INTO `settings` VALUES(30, 'sponsor_amount', '0.00');
INSERT INTO `settings` VALUES(31, 'sponsor_quant', '1');
INSERT INTO `settings` VALUES(32, 'product', 'Cashout');
INSERT INTO `settings` VALUES(33, 'subjectMail', 'Welcome to [SiteTitle]');
INSERT INTO `settings` VALUES(34, 'messageMail', 'Dear [FirstName] [LastName], \r\n\r\nSome message with tags.\r\n\r\nRegards,\r\n[SiteTitle]');
INSERT INTO `settings` VALUES(35, 'is_replica', '0');
INSERT INTO `settings` VALUES(36, 'quant_replica', '0');
INSERT INTO `settings` VALUES(37, 'SerialCode', 'POU0-QQ96-LNK0-LNK0');
INSERT INTO `settings` VALUES(38, 'StartDate', '1613127531');
INSERT INTO `settings` VALUES(39, 'AdminMessage', '');
INSERT INTO `settings` VALUES(40, 'useBanners', '0');
INSERT INTO `settings` VALUES(41, 'useBalance', '0');
INSERT INTO `settings` VALUES(42, 'useSecureMembers', '0');
INSERT INTO `settings` VALUES(43, 'useFoneMailing', '0');
INSERT INTO `settings` VALUES(44, 'useAutoresponder', '1');
INSERT INTO `settings` VALUES(45, 'useEshop', '0');
INSERT INTO `settings` VALUES(46, 'useValidation', '1');
INSERT INTO `settings` VALUES(47, 'quant_textadds', '0');
INSERT INTO `settings` VALUES(48, 'quant_textadds_show', '0');
INSERT INTO `settings` VALUES(49, 'quant_textadds_show_m', '0');
INSERT INTO `settings` VALUES(50, 'number_turing', '0');
INSERT INTO `settings` VALUES(51, 'payp_fromcash', '0');
INSERT INTO `settings` VALUES(52, 'is_pif', '0');
INSERT INTO `settings` VALUES(53, 'is_pif_cash', '0');
INSERT INTO `settings` VALUES(54, 'is_random', '0');
INSERT INTO `settings` VALUES(55, 'currency', '4');
INSERT INTO `settings` VALUES(56, 'ReferrerUrl', 'username');
INSERT INTO `settings` VALUES(57, 'FooterContent', 'Copyright © 2016. Powered by <a href=\"http://lumtice.net/\">Lumtice Digital Systems</a>');
INSERT INTO `settings` VALUES(58, 'LicenseNumber', 'ngU1RBTkRBUkQ=');
INSERT INTO `settings` VALUES(59, 'access', 'YYTo1Mjp7czo1OiJsYW5kcyI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJMYW5kaW5nIHBhZ2VzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoic3RhdCI7YTo0OntzOjU6InRpdGxlIjtzOjk6IkRhc2hib2FyZCI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjExOiJtZW1iX21hdHJpeCI7YTo0OntzOjU6InRpdGxlIjtzOjEyOiJPdmVyYWxsIFRyZWUiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToidXNlcl9hZG1pbnMiO2E6NTp7czo1OiJ0aXRsZSI7czoxNDoiQWRtaW5pc3RyYXRvcnMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTtzOjY6ImFjY2VzcyI7aToxO31zOjY6Im1hbnVhbCI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJNYW51YWwgUGF5bWVudHMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo1OiJwYWdlcyI7YTo1OntzOjU6InRpdGxlIjtzOjEyOiJQdWJsaWMgUGFnZXMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTtzOjY6ImFjY2VzcyI7aToxO31zOjc6Im1fcGFnZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMjoiTWVtYmVyIFBhZ2VzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoibmV3cyI7YTo0OntzOjU6InRpdGxlIjtzOjQ6Ik5ld3MiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo3OiJhcHRvb2xzIjthOjQ6e3M6NToidGl0bGUiO3M6MTM6IkFkbWluIGJhbm5lcnMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxNToiYXV0b3Jlc3BvbmRlcnNmIjthOjQ6e3M6NToidGl0bGUiO3M6MzA6IkluYWN0aXZlIE1lbWJlcnMgQXV0b3Jlc3BvbmRlciI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjE0OiJhdXRvcmVzcG9uZGVycyI7YTo0OntzOjU6InRpdGxlIjtzOjI5OiJBY3RpdmUgTWVtYmVycyBBdXRvcmVzcG9uZGVyICI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjEwOiJhdGVtcGxhdGVzIjthOjQ6e3M6NToidGl0bGUiO3M6MjM6Ik1hc3MgTWFpbGluZyBUZW1wbGF0ZXMgIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoibWFpbGluZyI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJTZW5kIE1hc3MgRW1haWwiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJiYWNrdXAiO2E6NDp7czo1OiJ0aXRsZSI7czo3OiJCYWNrdXBzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTM6InVzZVZhbGlkYXRpb24iO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJpc19waWYiO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToiaXNfcGlmX2Nhc2giO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czozOiJmYXEiO2E6NDp7czo1OiJ0aXRsZSI7czozOiJGQVEiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJwdG9vbHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNToiTWVtYmVycyBCYW5uZXJzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTA6ImlzX3JlcGxpY2EiO2E6NDp7czo1OiJ0aXRsZSI7czoxNjoiUmVwbGljYXRlZCBTaXRlcyI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjEzOiJxdWFudF9yZXBsaWNhIjthOjQ6e3M6NToidGl0bGUiO3M6MDoiIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoidGlja2V0cyI7YTo0OntzOjU6InRpdGxlIjtzOjE5OiJTdXBwb3J0IGZvciBtZW1iZXJzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MDtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTE6InB1Yl90aWNrZXRzIjthOjQ6e3M6NToidGl0bGUiO3M6MjA6IlN1cHBvcnQgZm9yIHZpc2l0b3JzIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTA6ImNhdGVnb3JpZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNzoiRXNob3AgQ2F0ZWdvcmllcyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo4OiJwcm9kdWN0cyI7YTo0OntzOjU6InRpdGxlIjtzOjE1OiJFc2hvcCBQcm9kdWN0cyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo5OiJzaG9wX2ZlZXMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMToiRXNob3AgRmVlcyAiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoidHVyaW5nX251bWJlciI7YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJGUkVFIjtpOjA7czo3OiJTVEFSVEVSIjtpOjA7czo4OiJTVEFOREFSRCI7aToxO31zOjg6ImN1cnJlbmN5IjthOjQ6e3M6NToidGl0bGUiO3M6MDoiIjtzOjQ6IkZSRUUiO2k6MDtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTM6InBheXBfZnJvbWNhc2giO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMToidHJlZV9tYXRyaXgiO2E6NDp7czo1OiJ0aXRsZSI7czowOiIiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxNzoidGVtcGxhdGVfZWxlbWVudHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxNzoiVGVtcGxhdGUgRWxlbWVudHMiO3M6NDoiRlJFRSI7aTowO3M6NzoiU1RBUlRFUiI7aTowO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo1OiJsb2dpbiI7YTo0OntzOjU6InRpdGxlIjtzOjEwOiJMb2dpbiBmb3JtIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoibWVtYmVycyI7YTo0OntzOjU6InRpdGxlIjtzOjExOiJNZW1iZXIgbGlzdCI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjEyOiJhZG1pbmRldGFpbHMiO2E6NDp7czo1OiJ0aXRsZSI7czoxMjoiYWRtaW5kZXRhaWxzIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6ODoic2V0dGluZ3MiO2E6NDp7czo1OiJ0aXRsZSI7czo4OiJzZXR0aW5ncyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6Im1hdHJpeGVzIjthOjQ6e3M6NToidGl0bGUiO3M6ODoibWF0cml4ZXMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo2OiJsZXZlbHMiO2E6NDp7czo1OiJ0aXRsZSI7czo2OiJsZXZlbHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoibGV2ZWxzX2ZvcmNlZCI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJsZXZlbHNfZm9yY2VkIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NjoiYWRtaW5zIjthOjQ6e3M6NToidGl0bGUiO3M6NjoiYWRtaW5zIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NzoicGF5bWVudCI7YTo0OntzOjU6InRpdGxlIjtzOjc6InBheW1lbnQiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo0OiJjYXNoIjthOjQ6e3M6NToidGl0bGUiO3M6NDoiY2FzaCI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6ImNhc2hfb3V0IjthOjQ6e3M6NToidGl0bGUiO3M6ODoiY2FzaF9vdXQiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMDoicHJvY2Vzc29ycyI7YTo0OntzOjU6InRpdGxlIjtzOjEwOiJwcm9jZXNzb3JzIjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6NDoidGFkcyI7YTo0OntzOjU6InRpdGxlIjtzOjQ6InRhZHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo5OiJ0ZW1wbGF0ZXMiO2E6NDp7czo1OiJ0aXRsZSI7czo5OiJ0ZW1wbGF0ZXMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo0OiJmZWVzIjthOjQ6e3M6NToidGl0bGUiO3M6NDoiZmVlcyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjg6Im1fbGV2ZWxzIjthOjQ6e3M6NToidGl0bGUiO3M6ODoibV9sZXZlbHMiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czoxMzoiZm9yY2VkX21hdHJpeCI7YTo0OntzOjU6InRpdGxlIjtzOjEzOiJmb3JjZWRfbWF0cml4IjtzOjQ6IkZSRUUiO2k6MTtzOjc6IlNUQVJURVIiO2k6MTtzOjg6IlNUQU5EQVJEIjtpOjE7fXM6MTI6InJlcGxpY2Ffc2l0ZSI7YTo0OntzOjU6InRpdGxlIjtzOjEyOiJyZXBsaWNhX3NpdGUiO3M6NDoiRlJFRSI7aToxO3M6NzoiU1RBUlRFUiI7aToxO3M6ODoiU1RBTkRBUkQiO2k6MTt9czo3OiJzaG9wZmVlIjthOjQ6e3M6NToidGl0bGUiO3M6Nzoic2hvcGZlZSI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjE0OiJ1cGxvYWRfbWVtYmVycyI7YTo0OntzOjU6InRpdGxlIjtzOjE0OiJ1cGxvYWRfbWVtYmVycyI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO31zOjY6InNsaWRlciI7YTo0OntzOjU6InRpdGxlIjtzOjY6InNsaWRlciI7czo0OiJGUkVFIjtpOjE7czo3OiJTVEFSVEVSIjtpOjE7czo4OiJTVEFOREFSRCI7aToxO319');
INSERT INTO `settings` VALUES(60, 'Commissions_Value', '1');
INSERT INTO `settings` VALUES(61, 'PRE_LAUNCH', '0');
INSERT INTO `settings` VALUES(62, 'PRE_LAUNCH_DATE', '0');
INSERT INTO `settings` VALUES(63, 'matching_bonus', '0');
INSERT INTO `settings` VALUES(64, 'matching_bonus_value', '0');
INSERT INTO `settings` VALUES(65, 'time_after_launch', '36');
INSERT INTO `settings` VALUES(66, 'Carousel_autoplayTimeout', '3000');
INSERT INTO `settings` VALUES(67, 'SPONSOR_VALUE', '2');
INSERT INTO `settings` VALUES(70, 'WITHDRAWAL_VALUE', '2');
INSERT INTO `settings` VALUES(71, 'currency_rate', '0.00014613');


DROP TABLE IF EXISTS shop_fees;
CREATE TABLE `shop_fees` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_order_index` int(11) NOT NULL DEFAULT 0,
  `plevel` int(3) NOT NULL DEFAULT 0,
  `fee_member` decimal(12,2) NOT NULL DEFAULT 0.00,
  `fee_sponsor` decimal(12,2) NOT NULL DEFAULT 0.00,
  `from_order_index` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`fee_id`),
  KEY `to_order_index_idx` (`to_order_index`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS slider;
CREATE TABLE `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `image` varchar(64) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `slider` VALUES(6, '', '0r4i1rsax4t4u1ttqjd1.png');
INSERT INTO `slider` VALUES(7, '', 'cq345v2pzhkxqi2b42iw.png');
INSERT INTO `slider` VALUES(8, '', '1lcwaw0djokgzoiknrxg.png');


DROP TABLE IF EXISTS sn_messages;
CREATE TABLE `sn_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subj` varchar(256) NOT NULL,
  `mess` text NOT NULL,
  `date` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `sn_messages` VALUES(5, '13245 2345 2345', '2345 2345 2345', 1337226509);
INSERT INTO `sn_messages` VALUES(6, '3465', '&lt;br&gt;3563 456 34563456 3456 3456', 1337231899);
INSERT INTO `sn_messages` VALUES(7, 'Re: 3465', '568&lt;br&gt;', 1337241214);
INSERT INTO `sn_messages` VALUES(20, 'Re: Re: 3465', 'sdfg sdfg&lt;div&gt;s&lt;/div&gt;&lt;div&gt;&lt;b&gt;sdfgsdfg&lt;i&gt;sdfgsdfgsdfg&lt;/i&gt;&lt;/b&gt;&lt;/div&gt;', 1337310463);
INSERT INTO `sn_messages` VALUES(9, 'Re: 3465', '2345', 1337241586);
INSERT INTO `sn_messages` VALUES(10, 'Re: 3465', 'rtyurtyu', 1337241614);
INSERT INTO `sn_messages` VALUES(11, 'Re: 3465', 'ghjkghjkghjkghjkghjkuio', 1337241760);
INSERT INTO `sn_messages` VALUES(12, 'Re: 3465', 'С‹РІР°Рї С‹РІ&lt;strong&gt;С‹РІР°РїС‹РІР°Рї&lt;/strong&gt;', 1337242022);
INSERT INTO `sn_messages` VALUES(13, 'Re: 3465', '&lt;p&gt;asd&lt;strong&gt;asdasd&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&lt;br&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;dd&lt;em&gt;dd&lt;/em&gt;&lt;br&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&lt;em&gt;&lt;br&gt;&lt;/em&gt;&lt;/strong&gt;&lt;/p&gt;', 1337242392);
INSERT INTO `sn_messages` VALUES(14, 'Re: 3465', '&lt;p&gt;sdfg&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;sdfgsdf&lt;/strong&gt;&lt;/p&gt;', 1337242418);
INSERT INTO `sn_messages` VALUES(16, 'Re: 3465', '&lt;p&gt;hi &lt;/p&gt;&lt;p&gt;&lt;strong&gt;!!ept&lt;/strong&gt;&lt;br&gt;&lt;/p&gt;', 1337244713);
INSERT INTO `sn_messages` VALUES(17, 'Re: 13245 2345 2345', '&lt;br&gt;tyuityui', 1337244967);
INSERT INTO `sn_messages` VALUES(21, 'Re: Re: 3465', 'dfhdfgh', 1337310545);
INSERT INTO `sn_messages` VALUES(22, 'tyuityui', 'tyui,tyuityutyui &amp;nbsp;ui', 1337311399);
INSERT INTO `sn_messages` VALUES(23, '45674567', '456 4567 4567 4567 4567', 1337311474);
INSERT INTO `sn_messages` VALUES(24, 'tyuityui', 'tyui,tyuityutyui &amp;nbsp;ui', 1337311760);
INSERT INTO `sn_messages` VALUES(25, 'Hi!', '&lt;p&gt;Hello!&lt;/p&gt;&lt;p&gt;How are you?&lt;/p&gt;', 1337312357);
INSERT INTO `sn_messages` VALUES(26, 'Re: Hi!', 'Hi Alex. Great! Please answer this message asap', 1337321801);
INSERT INTO `sn_messages` VALUES(27, 'Re: Re: Hi!', 'hello&lt;br&gt;', 1337321962);
INSERT INTO `sn_messages` VALUES(28, 'Re: Re: Hi!', 'I read your message.&lt;br&gt;', 1337322089);
INSERT INTO `sn_messages` VALUES(29, '222', '22222qwe rqwer&amp;nbsp;', 1337322601);
INSERT INTO `sn_messages` VALUES(30, 'I do it', 'it&#039;s ready', 1337322679);
INSERT INTO `sn_messages` VALUES(31, 'Re: I do it', '&lt;ul&gt;&lt;ul&gt;&lt;li&gt;&lt;u&gt;&lt;b&gt;ah@et&#039;&lt;/b&gt;&lt;/u&gt;&lt;/li&gt;&lt;/ul&gt;&lt;ol&gt;&lt;ol&gt;&lt;li&gt;&lt;b&gt;&lt;u&gt;1&lt;i&gt;&amp;nbsp;ggg&lt;/i&gt;&lt;/u&gt;&lt;/b&gt;&lt;/li&gt;&lt;/ol&gt;&lt;li&gt;&lt;b&gt;&lt;u&gt;&lt;br&gt;&lt;/u&gt;&lt;/b&gt;&lt;/li&gt;&lt;/ol&gt;&lt;/ul&gt;', 1337326023);
INSERT INTO `sn_messages` VALUES(32, 'Re: 222', 'rtyurtyu&lt;br&gt;', 1337341143);
INSERT INTO `sn_messages` VALUES(33, 'Re: 222', 'rtyurtyuuuu&lt;br&gt;', 1337341155);
INSERT INTO `sn_messages` VALUES(34, 'Counter is ready', 'You can see it.', 1337341742);
INSERT INTO `sn_messages` VALUES(35, 'Test Message', 'Testing one, two, three.', 1337341962);
INSERT INTO `sn_messages` VALUES(36, 'Re: Test Message', 'Roger', 1337342036);
INSERT INTO `sn_messages` VALUES(37, 'asdffff', 'asdf', 1338184196);
INSERT INTO `sn_messages` VALUES(42, '', '&lt;br&gt;', 1339238821);
INSERT INTO `sn_messages` VALUES(39, '785678', '65785&lt;br&gt;', 1338200571);
INSERT INTO `sn_messages` VALUES(40, 'Wow', '&lt;b style=\"color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; \"&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pharetra ullamcorper eros, id viverra nulla consequat sit amet. Mauris malesuada magna quis sem dapibus ut iaculis ipsum pretium. Cras id augue non elit pulvinar auctor. Proin aliquet cursus pharetra. Proin ullamcorper dolor vel leo luctus gravida euismod neque blandit. Aliquam dolor sapien, tincidunt eu imperdiet nec, viverra ut sapien. Aliquam ornare eros lobortis dolor blandit nec placerat leo dictum. Sed eu nibh tellus, et venenatis justo.&lt;/b&gt;', 1338879831);
INSERT INTO `sn_messages` VALUES(41, 'Wow', 'Superb', 1338881761);
INSERT INTO `sn_messages` VALUES(43, '12341234', '1234123&lt;br&gt;', 1340875730);
INSERT INTO `sn_messages` VALUES(44, 'jjjj', 'jjjj', 1340875739);
INSERT INTO `sn_messages` VALUES(45, '', '&lt;br&gt;', 1344941692);
INSERT INTO `sn_messages` VALUES(46, 'test', 'hello!', 1349437588);
INSERT INTO `sn_messages` VALUES(47, 'Subject', 'hello', 1349441558);
INSERT INTO `sn_messages` VALUES(48, '12', '12', 1349441689);
INSERT INTO `sn_messages` VALUES(49, 'regs', 'sdfgsdfg', 1350033139);
INSERT INTO `sn_messages` VALUES(50, 'xdfb', 'dfbsxf', 1350033207);
INSERT INTO `sn_messages` VALUES(51, 'q12341', '12qwerqwev rfwef qwe fq', 1350033338);
INSERT INTO `sn_messages` VALUES(52, 'test', 'xfgsdfgsdfgs', 1351162018);
INSERT INTO `sn_messages` VALUES(53, '11111', '11111111111', 1351164691);
INSERT INTO `sn_messages` VALUES(54, 'mess 1', 'mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1 mess 1', 1351233383);
INSERT INTO `sn_messages` VALUES(55, 'Re: mess 1', '', 1351235710);
INSERT INTO `sn_messages` VALUES(56, 'Re: mess 1', '', 1354525981);
INSERT INTO `sn_messages` VALUES(57, 'Re: Sent test4', '', 1354526046);
INSERT INTO `sn_messages` VALUES(58, 'Re: mess 1', '', 1354526146);
INSERT INTO `sn_messages` VALUES(59, 'Re: Re: mess 1', '111111111', 1354526450);
INSERT INTO `sn_messages` VALUES(60, 'Re: LikedВ В  one video-upload', '22222222', 1354526491);
INSERT INTO `sn_messages` VALUES(61, 'test tes tes', 'nvchrd6tfi876tfc iuy ygooy yugou g', 1354546965);
INSERT INTO `sn_messages` VALUES(62, '111111111', '2222222222222', 1354630305);
INSERT INTO `sn_messages` VALUES(63, '1111111', '2222222222fdddddddddd', 1354630565);
INSERT INTO `sn_messages` VALUES(64, '111111111', 'qqqqqqqqqqqqqqqqqqqqqqqq', 1356615168);
INSERT INTO `sn_messages` VALUES(65, 'Re: 111111111', '222222222222222', 1356615219);
INSERT INTO `sn_messages` VALUES(66, 'sdf', 'vgc', 1356615824);
INSERT INTO `sn_messages` VALUES(67, 'sdsd', 'sxdcssssssssss', 1356616090);
INSERT INTO `sn_messages` VALUES(68, '12121', 'sdg bsdg sdfgs fdg sd', 1358770558);
INSERT INTO `sn_messages` VALUES(69, '32323232', 'zdcv fg sfgzsfdgzs zsd', 1358770573);
INSERT INTO `sn_messages` VALUES(70, '111111', '11111111111111111111111', 1359462966);
INSERT INTO `sn_messages` VALUES(71, 'wer', 'weawdfsfds gsfd gsrg', 1365151361);
INSERT INTO `sn_messages` VALUES(72, 'wer', 'weawdfsfds gsfd gsrg', 1365151375);
INSERT INTO `sn_messages` VALUES(73, 'wer', 'weawdfsfds gsfd gsrg', 1365151380);
INSERT INTO `sn_messages` VALUES(74, 'wer', 'weawdfsfds gsfd gsrg', 1365151384);
INSERT INTO `sn_messages` VALUES(75, 'wer', 'weawdfsfds gsfd gsrg', 1365151721);
INSERT INTO `sn_messages` VALUES(76, 'wer', 'weawdfsfds gsfd gsrg', 1365151726);
INSERT INTO `sn_messages` VALUES(77, 'wer', 'weawdfsfds gsfd gsrg', 1365151730);
INSERT INTO `sn_messages` VALUES(78, 'wer', 'weawdfsfds gsfd gsrg', 1365151734);
INSERT INTO `sn_messages` VALUES(79, 'wer', 'weawdfsfds gsfd gsrg', 1365151738);
INSERT INTO `sn_messages` VALUES(80, 'Message from Chat', 'test message from chat', 1365156329);
INSERT INTO `sn_messages` VALUES(81, 'Message from Chat', 'jhgf', 1365497664);
INSERT INTO `sn_messages` VALUES(82, 'Message from Chat', 'jhgf', 1365497669);
INSERT INTO `sn_messages` VALUES(83, 'Message from Chat', 'jhgf', 1365497672);
INSERT INTO `sn_messages` VALUES(84, 'Message from Chat', 'jhgf', 1365497697);
INSERT INTO `sn_messages` VALUES(85, 'Message from Chat', 'jhgf', 1365497699);
INSERT INTO `sn_messages` VALUES(86, 'Message from Chat', 'jhgf', 1365497700);
INSERT INTO `sn_messages` VALUES(87, 'Message from Chat', 'jhgf', 1365497700);
INSERT INTO `sn_messages` VALUES(88, 'Message from Chat', 'sdfghjmk,', 1365503856);
INSERT INTO `sn_messages` VALUES(89, 'Message from Chat', ',mnhb', 1365503916);
INSERT INTO `sn_messages` VALUES(90, 'Message from Chat', ',mnhb', 1365503918);


DROP TABLE IF EXISTS sn_messages_mem;
CREATE TABLE `sn_messages_mem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mess_id` int(11) NOT NULL DEFAULT 0,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `from_member_id` int(11) NOT NULL DEFAULT 0,
  `to_member_id` int(11) NOT NULL DEFAULT 0,
  `read_mark` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=275 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `sn_messages_mem` VALUES(14, 5, 1, 2, 1, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(13, 5, 1606, 1606, 15, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(12, 5, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(11, 5, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(10, 5, 1607, 1606, 1607, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(9, 5, 1606, 1606, 1607, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(15, 6, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(41, 21, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(40, 20, 1606, 1650, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(39, 20, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(19, 9, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(20, 9, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(21, 10, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(22, 10, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(23, 11, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(24, 11, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(25, 12, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(26, 12, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(27, 13, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(28, 13, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(29, 14, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(30, 14, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(31, 16, 1606, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(32, 16, 1650, 1606, 1650, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(33, 17, 1650, 1650, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(34, 17, 1606, 1650, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(42, 21, 1606, 1650, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(43, 22, 1606, 1606, 1650, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(44, 22, 1650, 1606, 1650, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(45, 23, 1606, 1606, 1611, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(46, 23, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(47, 24, 1606, 1606, 1611, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(48, 24, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(49, 25, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(58, 29, 1606, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(51, 26, 512, 512, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(52, 26, 1606, 512, 1606, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(53, 27, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(57, 29, 1611, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(55, 28, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(56, 28, 512, 1606, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(59, 30, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(60, 30, 512, 1606, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(61, 31, 512, 512, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(62, 31, 1606, 512, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(63, 32, 1606, 1606, 1611, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(64, 32, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(65, 33, 1606, 1606, 1611, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(66, 33, 1611, 1606, 1611, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(67, 34, 1606, 1606, 512, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(68, 34, 512, 1606, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(69, 35, 2614, 2614, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(70, 35, 512, 2614, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(71, 36, 512, 512, 2614, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(72, 36, 2614, 512, 2614, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(73, 37, 1611, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(74, 37, 1606, 1611, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(83, 42, 1606, 1606, 2606, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(84, 42, 2606, 1606, 2606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(77, 39, 1606, 1606, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(78, 39, 1606, 1606, 1606, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(79, 40, 512, 512, 512, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(80, 40, 512, 512, 512, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(81, 41, 1, 1, 512, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(82, 41, 512, 1, 512, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(85, 43, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(86, 43, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(87, 44, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(88, 44, 1606, 1606, 1606, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(89, 47, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(90, 47, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(117, 61, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(92, 48, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(93, 49, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(94, 49, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(95, 50, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(96, 50, 2674, 2674, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(97, 51, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(98, 51, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(99, 52, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(100, 52, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(101, 53, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(102, 53, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(103, 54, 2676, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(104, 54, 2674, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(105, 55, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(106, 55, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(107, 56, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(108, 56, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(109, 57, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(110, 57, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(111, 58, 2674, 2674, 2676, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(112, 58, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(113, 59, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(114, 59, 2674, 2676, 2674, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(115, 60, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(116, 60, 2674, 2676, 2674, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(118, 61, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(119, 62, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(120, 62, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(121, 62, 2674, 2674, 2641, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(122, 62, 2641, 2674, 2641, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(123, 63, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(124, 63, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(125, 64, 2674, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(126, 64, 2676, 2674, 2676, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(127, 65, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(128, 65, 2674, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(129, 68, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(130, 68, 2674, 2676, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(131, 69, 2676, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(132, 69, 2674, 2676, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(133, 70, 2674, 2674, 1, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(134, 70, 1, 2674, 1, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(135, 73, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(136, 73, 2700, 2703, 2700, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(137, 74, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(138, 74, 2700, 2703, 2700, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(139, 0, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(140, 0, 2700, 2703, 2700, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(141, 0, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(142, 0, 2700, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(143, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(144, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(145, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(146, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(147, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(148, 0, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(149, 75, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(150, 75, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(151, 76, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(152, 76, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(153, 77, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(154, 77, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(155, 78, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(156, 78, 2700, 2703, 2700, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(157, 79, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(158, 79, 2700, 2703, 2700, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(159, 80, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(160, 80, 2700, 2703, 2700, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(161, 81, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(162, 81, 2674, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(163, 82, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(164, 82, 2674, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(165, 83, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(166, 83, 2674, 2700, 2674, 1, 0);
INSERT INTO `sn_messages_mem` VALUES(167, 84, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(168, 84, 2674, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(169, 85, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(170, 85, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(171, 86, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(172, 86, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(173, 87, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(174, 87, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(175, 88, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(176, 88, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(177, 89, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(178, 89, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(179, 90, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(180, 90, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(181, 91, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(182, 91, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(183, 92, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(184, 92, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(185, 93, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(186, 93, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(187, 94, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(188, 94, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(189, 95, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(190, 95, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(191, 96, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(192, 96, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(193, 97, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(194, 97, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(195, 98, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(196, 98, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(197, 99, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(198, 99, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(199, 100, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(200, 100, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(201, 101, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(202, 101, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(203, 102, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(204, 102, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(205, 103, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(206, 103, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(207, 104, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(208, 104, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(209, 105, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(210, 105, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(211, 106, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(212, 106, 2700, 2700, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(213, 107, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(214, 107, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(215, 108, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(216, 108, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(217, 109, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(218, 109, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(219, 110, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(220, 110, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(221, 111, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(222, 111, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(223, 112, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(224, 112, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(225, 113, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(226, 113, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(227, 114, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(228, 114, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(229, 115, 2700, 2700, 2674, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(230, 115, 2674, 2700, 2674, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(231, 116, 2690, 2690, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(232, 116, 2700, 2690, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(233, 117, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(234, 117, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(235, 71, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(236, 71, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(237, 72, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(238, 72, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(239, 73, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(240, 73, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(241, 74, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(242, 74, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(243, 75, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(244, 75, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(245, 76, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(246, 76, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(247, 77, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(248, 77, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(249, 78, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(250, 78, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(251, 79, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(252, 79, 2703, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(253, 80, 2703, 2700, 2703, 1, 1);
INSERT INTO `sn_messages_mem` VALUES(255, 81, 2674, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(256, 81, 2682, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(257, 82, 2674, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(258, 82, 2682, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(259, 83, 2674, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(260, 83, 2682, 2674, 2682, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(261, 84, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(262, 84, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(263, 85, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(264, 85, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(265, 86, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(266, 86, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(267, 87, 2674, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(268, 87, 2681, 2674, 2681, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(269, 88, 2700, 2700, 2703, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(270, 88, 2703, 2700, 2703, 0, 1);
INSERT INTO `sn_messages_mem` VALUES(271, 89, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(272, 89, 2700, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(273, 90, 2703, 2703, 2700, 0, 0);
INSERT INTO `sn_messages_mem` VALUES(274, 90, 2700, 2703, 2700, 0, 0);


DROP TABLE IF EXISTS sponsor_bonus;
CREATE TABLE `sponsor_bonus` (
  `sponsor_bonus_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `sponsored_id` int(11) NOT NULL DEFAULT 0,
  `is_bonus` tinyint(1) NOT NULL DEFAULT 0,
  `z_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sponsor_bonus_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `sponsored_id_idx` (`sponsored_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS stat_counter;
CREATE TABLE `stat_counter` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page` bigint(20) DEFAULT 0,
  `un_ip` bigint(20) DEFAULT 0,
  `un_browser` bigint(20) DEFAULT 0,
  `date` date DEFAULT '0000-00-00',
  KEY `id` (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS stat_log;
CREATE TABLE `stat_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT '0000-00-00',
  `time` time DEFAULT '00:00:00',
  `ip` varchar(16) DEFAULT '',
  `proxy` varchar(16) DEFAULT '',
  `page` varchar(1024) DEFAULT '',
  `referer` varchar(1024) DEFAULT '',
  `language` varchar(8) DEFAULT '',
  `agent` varchar(255) DEFAULT '',
  `un_browser` int(1) DEFAULT 0,
  `un_ip` int(1) DEFAULT 0,
  `session` bigint(20) DEFAULT 0,
  `screen` varchar(255) DEFAULT '',
  `get` text DEFAULT NULL,
  `post` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS stats_countries;
CREATE TABLE `stats_countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  PRIMARY KEY (`country_id`),
  KEY `referral_idx` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_countries` VALUES(1, 'Undefined');


DROP TABLE IF EXISTS stats_referrals;
CREATE TABLE `stats_referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  PRIMARY KEY (`referral_id`),
  KEY `referral_idx` (`referral`)
) ENGINE=MyISAM AUTO_INCREMENT=38 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_referrals` VALUES(1, 'No referrer');
INSERT INTO `stats_referrals` VALUES(2, 'http://swan20.com.runmlm.com/');
INSERT INTO `stats_referrals` VALUES(3, 'http://swan20.com.runmlm.com/activation.php');
INSERT INTO `stats_referrals` VALUES(4, 'http://swan20.com.runmlm.com/news.php');
INSERT INTO `stats_referrals` VALUES(5, 'http://swan20.com.runmlm.com/faq.php');
INSERT INTO `stats_referrals` VALUES(6, 'http://swan20.com.runmlm.com/ticket.php');
INSERT INTO `stats_referrals` VALUES(7, 'http://swan20.com.runmlm.com/login.php');
INSERT INTO `stats_referrals` VALUES(8, 'http://swan20.com.runmlm.com/signup.php');
INSERT INTO `stats_referrals` VALUES(9, 'http://ng.istandwithjesus.org/member/payments.php');
INSERT INTO `stats_referrals` VALUES(10, 'http://ng.istandwithjesus.org/admin/members.php');
INSERT INTO `stats_referrals` VALUES(11, 'android-app://com.google.android.googlequicksearch');
INSERT INTO `stats_referrals` VALUES(12, 'http://org.all-url.info/org/istandwithjesus.org/');
INSERT INTO `stats_referrals` VALUES(13, 'http://ng.istandwithjesus.org/signup.php');
INSERT INTO `stats_referrals` VALUES(14, 'android-app://com.google.android.googlequicksearch');
INSERT INTO `stats_referrals` VALUES(15, 'android-app://com.google.android.googlequicksearch');
INSERT INTO `stats_referrals` VALUES(16, 'http://istandwithjesus.org/');
INSERT INTO `stats_referrals` VALUES(17, 'https://ng.istandwithjesus.org/');
INSERT INTO `stats_referrals` VALUES(18, 'http://istandwithjesus.org');
INSERT INTO `stats_referrals` VALUES(19, 'https://www.google.com/');
INSERT INTO `stats_referrals` VALUES(20, 'https://ng.istandwithjesus.org/login.php');
INSERT INTO `stats_referrals` VALUES(21, 'https://www.google.com/url');
INSERT INTO `stats_referrals` VALUES(22, 'android-app://com.google.android.googlequicksearch');
INSERT INTO `stats_referrals` VALUES(23, 'http://www.istandwithjesus.org/');
INSERT INTO `stats_referrals` VALUES(24, 'https://istandwithjesus.org/');
INSERT INTO `stats_referrals` VALUES(25, 'https://ng.istandwithjesus.org/signup.php');
INSERT INTO `stats_referrals` VALUES(26, 'https://ng.istandwithjesus.org/member/matrix.php');
INSERT INTO `stats_referrals` VALUES(27, 'https://ng.istandwithjesus.org/member/myaccount.ph');
INSERT INTO `stats_referrals` VALUES(28, 'http://ng.istandwithjesus.org/');
INSERT INTO `stats_referrals` VALUES(29, 'http://ng.istandwithjesus.org/login.php');
INSERT INTO `stats_referrals` VALUES(30, 'https://ng.istandwithjesus.org/member/myaccount.ph');
INSERT INTO `stats_referrals` VALUES(31, 'https://ng.istandwithjesus.org/index.php');
INSERT INTO `stats_referrals` VALUES(32, 'https://ng.istandwithjesus.org/admin/members.php');
INSERT INTO `stats_referrals` VALUES(33, 'https://ng.istandwithjesus.org/member/payments.php');
INSERT INTO `stats_referrals` VALUES(34, 'https://ng.istandwithjesus.org/member/myaccount.ph');
INSERT INTO `stats_referrals` VALUES(35, 'http://www.ng.istandwithjesus.org');
INSERT INTO `stats_referrals` VALUES(36, 'https://ng.istandwithjesus.org/member/myaccount.ph');
INSERT INTO `stats_referrals` VALUES(37, 'https://ng.istandwithjesus.org/member/payment.php');


DROP TABLE IF EXISTS stats_views;
CREATE TABLE `stats_views` (
  `view_id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_id` int(11) NOT NULL DEFAULT 0,
  `page` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `thetime` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`view_id`),
  KEY `ipaddress_idx` (`visitor_id`),
  KEY `country_idx` (`page`),
  KEY `city_idx` (`thetime`)
) ENGINE=MyISAM AUTO_INCREMENT=1708 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_views` VALUES(1, 1, '/index.php', 1607507974);
INSERT INTO `stats_views` VALUES(2, 2, '/index.php', 1607508853);
INSERT INTO `stats_views` VALUES(3, 3, '/index.php', 1607508863);
INSERT INTO `stats_views` VALUES(4, 4, '/index.php', 1607509012);
INSERT INTO `stats_views` VALUES(5, 5, '/index.php', 1607509040);
INSERT INTO `stats_views` VALUES(6, 6, '/thank_you.php', 1607509041);
INSERT INTO `stats_views` VALUES(7, 7, '/activation.php', 1607509066);
INSERT INTO `stats_views` VALUES(8, 8, '/activation.php', 1607509071);
INSERT INTO `stats_views` VALUES(9, 9, '/activation.php', 1607509085);
INSERT INTO `stats_views` VALUES(10, 10, '/activation.php', 1607509086);
INSERT INTO `stats_views` VALUES(11, 11, '/activation.php', 1607509113);
INSERT INTO `stats_views` VALUES(12, 12, '/activation.php', 1607509123);
INSERT INTO `stats_views` VALUES(13, 13, '/activation.php', 1607509124);
INSERT INTO `stats_views` VALUES(14, 14, '/activation.php', 1607509128);
INSERT INTO `stats_views` VALUES(15, 15, '/index.php', 1607509369);
INSERT INTO `stats_views` VALUES(16, 16, '/index.php', 1607509385);
INSERT INTO `stats_views` VALUES(17, 17, '/activation.php', 1607509574);
INSERT INTO `stats_views` VALUES(18, 18, '/index.php', 1607509657);
INSERT INTO `stats_views` VALUES(19, 19, '/index.php', 1607532652);
INSERT INTO `stats_views` VALUES(20, 20, '/index.php', 1607533287);
INSERT INTO `stats_views` VALUES(21, 21, '/index.php', 1607533337);
INSERT INTO `stats_views` VALUES(22, 22, '/index.php', 1607533452);
INSERT INTO `stats_views` VALUES(23, 23, '/index.php', 1607533456);
INSERT INTO `stats_views` VALUES(24, 24, '/index.php', 1607533490);
INSERT INTO `stats_views` VALUES(25, 25, '/index.php', 1607533506);
INSERT INTO `stats_views` VALUES(26, 26, '/index.php', 1607533518);
INSERT INTO `stats_views` VALUES(27, 27, '/news.php', 1607533566);
INSERT INTO `stats_views` VALUES(28, 28, '/faq.php', 1607533569);
INSERT INTO `stats_views` VALUES(29, 29, '/ticket.php', 1607533581);
INSERT INTO `stats_views` VALUES(30, 30, '/ticket.php', 1607533852);
INSERT INTO `stats_views` VALUES(31, 31, '/ticket.php', 1607533867);
INSERT INTO `stats_views` VALUES(32, 32, '/ticket.php', 1607533901);
INSERT INTO `stats_views` VALUES(33, 33, '/ticket.php', 1607533963);
INSERT INTO `stats_views` VALUES(34, 34, '/ticket.php', 1607533984);
INSERT INTO `stats_views` VALUES(35, 35, '/index.php', 1607533991);
INSERT INTO `stats_views` VALUES(36, 36, '/index.php', 1607534009);
INSERT INTO `stats_views` VALUES(37, 37, '/login.php', 1607534011);
INSERT INTO `stats_views` VALUES(38, 38, '/signup.php', 1607534014);
INSERT INTO `stats_views` VALUES(39, 39, '/signup.php', 1607534691);
INSERT INTO `stats_views` VALUES(40, 40, '/signup.php', 1607534920);
INSERT INTO `stats_views` VALUES(41, 41, '/signup.php', 1607534942);
INSERT INTO `stats_views` VALUES(42, 42, '/signup.php', 1607535105);
INSERT INTO `stats_views` VALUES(43, 43, '/thank_you.php', 1607535107);
INSERT INTO `stats_views` VALUES(44, 44, '/thank_you.php', 1607535209);
INSERT INTO `stats_views` VALUES(45, 45, '/signup.php', 1607535213);
INSERT INTO `stats_views` VALUES(46, 46, '/signup.php', 1607535233);
INSERT INTO `stats_views` VALUES(47, 47, '/signup.php', 1607535257);
INSERT INTO `stats_views` VALUES(48, 48, '/index.php', 1613129223);
INSERT INTO `stats_views` VALUES(49, 48, '/index.php', 1613129442);
INSERT INTO `stats_views` VALUES(50, 48, '/index.php', 1613129484);
INSERT INTO `stats_views` VALUES(51, 48, '/index.php', 1613129539);
INSERT INTO `stats_views` VALUES(52, 48, '/index.php', 1613129549);
INSERT INTO `stats_views` VALUES(53, 48, '/index.php', 1613129836);
INSERT INTO `stats_views` VALUES(54, 48, '/index.php', 1613129902);
INSERT INTO `stats_views` VALUES(55, 48, '/index.php', 1613130071);
INSERT INTO `stats_views` VALUES(56, 48, '/index.php', 1613130101);
INSERT INTO `stats_views` VALUES(57, 48, '/index.php', 1613130121);
INSERT INTO `stats_views` VALUES(58, 48, '/index.php', 1613130145);
INSERT INTO `stats_views` VALUES(59, 48, '/index.php', 1613130170);
INSERT INTO `stats_views` VALUES(60, 48, '/index.php', 1613131135);
INSERT INTO `stats_views` VALUES(61, 48, '/index.php', 1613133836);
INSERT INTO `stats_views` VALUES(62, 48, '/index.php', 1613133840);
INSERT INTO `stats_views` VALUES(63, 48, '/index.php', 1613133842);
INSERT INTO `stats_views` VALUES(64, 48, '/index.php', 1613134320);
INSERT INTO `stats_views` VALUES(65, 48, '/index.php', 1613134325);
INSERT INTO `stats_views` VALUES(66, 48, '/index.php', 1613134797);
INSERT INTO `stats_views` VALUES(67, 48, '/index.php', 1613135096);
INSERT INTO `stats_views` VALUES(68, 48, '/index.php', 1613135125);
INSERT INTO `stats_views` VALUES(69, 48, '/thank_you.php', 1613135130);
INSERT INTO `stats_views` VALUES(70, 48, '/index.php', 1613135204);
INSERT INTO `stats_views` VALUES(71, 48, '/index.php', 1613135292);
INSERT INTO `stats_views` VALUES(72, 48, '/thank_you.php', 1613135310);
INSERT INTO `stats_views` VALUES(73, 48, '/thank_you.php', 1613135313);
INSERT INTO `stats_views` VALUES(74, 48, '/index.php', 1613135334);
INSERT INTO `stats_views` VALUES(75, 48, '/index.php', 1613135489);
INSERT INTO `stats_views` VALUES(76, 48, '/index.php', 1613135492);
INSERT INTO `stats_views` VALUES(77, 48, '/index.php', 1613135498);
INSERT INTO `stats_views` VALUES(78, 48, '/index.php', 1613135528);
INSERT INTO `stats_views` VALUES(79, 48, '/index.php', 1613135531);
INSERT INTO `stats_views` VALUES(80, 48, '/index.php', 1613135534);
INSERT INTO `stats_views` VALUES(81, 48, '/index.php', 1613135563);
INSERT INTO `stats_views` VALUES(82, 48, '/index.php', 1613135596);
INSERT INTO `stats_views` VALUES(83, 48, '/index.php', 1613135729);
INSERT INTO `stats_views` VALUES(84, 48, '/thank_you.php', 1613135729);
INSERT INTO `stats_views` VALUES(85, 48, '/index.php', 1613135732);
INSERT INTO `stats_views` VALUES(86, 49, '/index.php', 1613140970);
INSERT INTO `stats_views` VALUES(87, 49, '/index.php', 1613141107);
INSERT INTO `stats_views` VALUES(88, 50, '/index.php', 1613142587);
INSERT INTO `stats_views` VALUES(89, 51, '/index.php', 1613170193);
INSERT INTO `stats_views` VALUES(90, 52, '/index.php', 1613216111);
INSERT INTO `stats_views` VALUES(91, 52, '/index.php', 1613216233);
INSERT INTO `stats_views` VALUES(92, 52, '/index.php', 1613216652);
INSERT INTO `stats_views` VALUES(93, 52, '/index.php', 1613216732);
INSERT INTO `stats_views` VALUES(94, 52, '/login.php', 1613216750);
INSERT INTO `stats_views` VALUES(95, 52, '/signup.php', 1613216762);
INSERT INTO `stats_views` VALUES(96, 52, '/index.php', 1613216918);
INSERT INTO `stats_views` VALUES(97, 52, '/index.php', 1613217193);
INSERT INTO `stats_views` VALUES(98, 52, '/index.php', 1613217195);
INSERT INTO `stats_views` VALUES(99, 52, '/index.php', 1613217303);
INSERT INTO `stats_views` VALUES(100, 52, '/index.php', 1613217702);
INSERT INTO `stats_views` VALUES(101, 52, '/index.php', 1613217712);
INSERT INTO `stats_views` VALUES(102, 52, '/index.php', 1613217887);
INSERT INTO `stats_views` VALUES(103, 52, '/index.php', 1613217921);
INSERT INTO `stats_views` VALUES(104, 52, '/index.php', 1613218024);
INSERT INTO `stats_views` VALUES(105, 52, '/index.php', 1613218143);
INSERT INTO `stats_views` VALUES(106, 52, '/index.php', 1613218296);
INSERT INTO `stats_views` VALUES(107, 52, '/index.php', 1613218317);
INSERT INTO `stats_views` VALUES(108, 52, '/index.php', 1613218500);
INSERT INTO `stats_views` VALUES(109, 52, '/index.php', 1613218653);
INSERT INTO `stats_views` VALUES(110, 52, '/signup.php', 1613218672);
INSERT INTO `stats_views` VALUES(111, 52, '/signup.php', 1613218688);
INSERT INTO `stats_views` VALUES(112, 52, '/signup.php', 1613218691);
INSERT INTO `stats_views` VALUES(113, 52, '/index.php', 1613218718);
INSERT INTO `stats_views` VALUES(114, 52, '/index.php', 1613218736);
INSERT INTO `stats_views` VALUES(115, 52, '/index.php', 1613218812);
INSERT INTO `stats_views` VALUES(116, 52, '/index.php', 1613219054);
INSERT INTO `stats_views` VALUES(117, 52, '/index.php', 1613219241);
INSERT INTO `stats_views` VALUES(118, 52, '/index.php', 1613219305);
INSERT INTO `stats_views` VALUES(119, 52, '/login.php', 1613219571);
INSERT INTO `stats_views` VALUES(120, 52, '/forgot_password.php', 1613219582);
INSERT INTO `stats_views` VALUES(121, 52, '/forgot_password.php', 1613219588);
INSERT INTO `stats_views` VALUES(122, 52, '/forgot_password.php', 1613219589);
INSERT INTO `stats_views` VALUES(123, 52, '/forgot_password.php', 1613219592);
INSERT INTO `stats_views` VALUES(124, 52, '/login.php', 1613219593);
INSERT INTO `stats_views` VALUES(125, 52, '/index.php', 1613219595);
INSERT INTO `stats_views` VALUES(126, 53, '/index.php', 1613222606);
INSERT INTO `stats_views` VALUES(127, 53, '/index.php', 1613222658);
INSERT INTO `stats_views` VALUES(128, 54, '/index.php', 1613223793);
INSERT INTO `stats_views` VALUES(129, 55, '/index.php', 1613224589);
INSERT INTO `stats_views` VALUES(130, 56, '/index.php', 1613226948);
INSERT INTO `stats_views` VALUES(131, 57, '/index.php', 1613239437);
INSERT INTO `stats_views` VALUES(132, 58, '/index.php', 1613248792);
INSERT INTO `stats_views` VALUES(133, 59, '/index.php', 1613258652);
INSERT INTO `stats_views` VALUES(134, 60, '/index.php', 1613259764);
INSERT INTO `stats_views` VALUES(135, 61, '/index.php', 1613264504);
INSERT INTO `stats_views` VALUES(136, 62, '/index.php', 1613286283);
INSERT INTO `stats_views` VALUES(137, 63, '/index.php', 1613292005);
INSERT INTO `stats_views` VALUES(138, 64, '/index.php', 1613296267);
INSERT INTO `stats_views` VALUES(139, 64, '/index.php', 1613296267);
INSERT INTO `stats_views` VALUES(140, 64, '/index.php', 1613296267);
INSERT INTO `stats_views` VALUES(141, 64, '/index.php', 1613296267);
INSERT INTO `stats_views` VALUES(142, 64, '/login.php', 1613296321);
INSERT INTO `stats_views` VALUES(143, 64, '/index.php', 1613296334);
INSERT INTO `stats_views` VALUES(144, 64, '/login.php', 1613296339);
INSERT INTO `stats_views` VALUES(145, 64, '/index.php', 1613296344);
INSERT INTO `stats_views` VALUES(146, 65, '/index.php', 1613317633);
INSERT INTO `stats_views` VALUES(147, 66, '/index.php', 1613322116);
INSERT INTO `stats_views` VALUES(148, 66, '/index.php', 1613322116);
INSERT INTO `stats_views` VALUES(149, 66, '/index.php', 1613322124);
INSERT INTO `stats_views` VALUES(150, 66, '/index.php', 1613325833);
INSERT INTO `stats_views` VALUES(151, 66, '/index.php', 1613325834);
INSERT INTO `stats_views` VALUES(152, 66, '/index.php', 1613325884);
INSERT INTO `stats_views` VALUES(153, 67, '/index.php', 1613332934);
INSERT INTO `stats_views` VALUES(154, 67, '/index.php', 1613335109);
INSERT INTO `stats_views` VALUES(155, 67, '/index.php', 1613335109);
INSERT INTO `stats_views` VALUES(156, 67, '/index.php', 1613335115);
INSERT INTO `stats_views` VALUES(157, 68, '/index.php', 1613348382);
INSERT INTO `stats_views` VALUES(158, 69, '/index.php', 1613352580);
INSERT INTO `stats_views` VALUES(159, 69, '/index.php', 1613352584);
INSERT INTO `stats_views` VALUES(160, 70, '/index.php', 1613358450);
INSERT INTO `stats_views` VALUES(161, 71, '/index.php', 1613379896);
INSERT INTO `stats_views` VALUES(162, 71, '/index.php', 1613380341);
INSERT INTO `stats_views` VALUES(163, 72, '/index.php', 1613386020);
INSERT INTO `stats_views` VALUES(164, 72, '/login.php', 1613386025);
INSERT INTO `stats_views` VALUES(165, 72, '/index.php', 1613386036);
INSERT INTO `stats_views` VALUES(166, 72, '/signup.php', 1613386049);
INSERT INTO `stats_views` VALUES(167, 72, '/index.php', 1613386927);
INSERT INTO `stats_views` VALUES(168, 72, '/index.php', 1613386930);
INSERT INTO `stats_views` VALUES(169, 72, '/signup.php', 1613386938);
INSERT INTO `stats_views` VALUES(170, 72, '/index.php', 1613386944);
INSERT INTO `stats_views` VALUES(171, 72, '/index.php', 1613387041);
INSERT INTO `stats_views` VALUES(172, 72, '/index.php', 1613387050);
INSERT INTO `stats_views` VALUES(173, 72, '/signup.php', 1613387055);
INSERT INTO `stats_views` VALUES(174, 72, '/index.php', 1613387165);
INSERT INTO `stats_views` VALUES(175, 72, '/index.php', 1613387168);
INSERT INTO `stats_views` VALUES(176, 72, '/index.php', 1613387285);
INSERT INTO `stats_views` VALUES(177, 72, '/index.php', 1613387292);
INSERT INTO `stats_views` VALUES(178, 72, '/index.php', 1613387294);
INSERT INTO `stats_views` VALUES(179, 72, '/index.php', 1613387316);
INSERT INTO `stats_views` VALUES(180, 72, '/index.php', 1613387491);
INSERT INTO `stats_views` VALUES(181, 72, '/index.php', 1613387568);
INSERT INTO `stats_views` VALUES(182, 72, '/index.php', 1613387571);
INSERT INTO `stats_views` VALUES(183, 72, '/index.php', 1613387659);
INSERT INTO `stats_views` VALUES(184, 72, '/signup.php', 1613387687);
INSERT INTO `stats_views` VALUES(185, 72, '/signup.php', 1613387704);
INSERT INTO `stats_views` VALUES(186, 72, '/thank_you.php', 1613387706);
INSERT INTO `stats_views` VALUES(187, 72, '/index.php', 1613387799);
INSERT INTO `stats_views` VALUES(188, 72, '/signup.php', 1613387803);
INSERT INTO `stats_views` VALUES(189, 72, '/index.php', 1613387807);
INSERT INTO `stats_views` VALUES(190, 72, '/index.php', 1613387863);
INSERT INTO `stats_views` VALUES(191, 72, '/signup.php', 1613387868);
INSERT INTO `stats_views` VALUES(192, 72, '/index.php', 1613387884);
INSERT INTO `stats_views` VALUES(193, 72, '/signup.php', 1613387901);
INSERT INTO `stats_views` VALUES(194, 72, '/signup.php', 1613387909);
INSERT INTO `stats_views` VALUES(195, 72, '/signup.php', 1613388205);
INSERT INTO `stats_views` VALUES(196, 72, '/signup.php', 1613388262);
INSERT INTO `stats_views` VALUES(197, 72, '/signup.php', 1613388339);
INSERT INTO `stats_views` VALUES(198, 72, '/index.php', 1613388350);
INSERT INTO `stats_views` VALUES(199, 72, '/index.php', 1613388356);
INSERT INTO `stats_views` VALUES(200, 72, '/index.php', 1613388379);
INSERT INTO `stats_views` VALUES(201, 72, '/signup.php', 1613388388);
INSERT INTO `stats_views` VALUES(202, 72, '/signup.php', 1613388435);
INSERT INTO `stats_views` VALUES(203, 72, '/signup.php', 1613388496);
INSERT INTO `stats_views` VALUES(204, 72, '/signup.php', 1613388592);
INSERT INTO `stats_views` VALUES(205, 72, '/signup.php', 1613388652);
INSERT INTO `stats_views` VALUES(206, 72, '/signup.php', 1613388681);
INSERT INTO `stats_views` VALUES(207, 72, '/signup.php', 1613388685);
INSERT INTO `stats_views` VALUES(208, 72, '/signup.php', 1613388798);
INSERT INTO `stats_views` VALUES(209, 72, '/signup.php', 1613388800);
INSERT INTO `stats_views` VALUES(210, 72, '/signup.php', 1613388877);
INSERT INTO `stats_views` VALUES(211, 72, '/signup.php', 1613388879);
INSERT INTO `stats_views` VALUES(212, 72, '/signup.php', 1613388915);
INSERT INTO `stats_views` VALUES(213, 72, '/signup.php', 1613388930);
INSERT INTO `stats_views` VALUES(214, 72, '/signup.php', 1613389019);
INSERT INTO `stats_views` VALUES(215, 72, '/signup.php', 1613389045);
INSERT INTO `stats_views` VALUES(216, 72, '/signup.php', 1613389056);
INSERT INTO `stats_views` VALUES(217, 72, '/signup.php', 1613389091);
INSERT INTO `stats_views` VALUES(218, 72, '/signup.php', 1613389351);
INSERT INTO `stats_views` VALUES(219, 72, '/index.php', 1613389363);
INSERT INTO `stats_views` VALUES(220, 72, '/index.php', 1613389371);
INSERT INTO `stats_views` VALUES(221, 72, '/signup.php', 1613389376);
INSERT INTO `stats_views` VALUES(222, 72, '/index.php', 1613389382);
INSERT INTO `stats_views` VALUES(223, 72, '/index.php', 1613389386);
INSERT INTO `stats_views` VALUES(224, 72, '/signup.php', 1613389391);
INSERT INTO `stats_views` VALUES(225, 72, '/index.php', 1613389395);
INSERT INTO `stats_views` VALUES(226, 73, '/index.php', 1613404944);
INSERT INTO `stats_views` VALUES(227, 74, '/index.php', 1613418282);
INSERT INTO `stats_views` VALUES(228, 75, '/thank_you.php', 1613431113);
INSERT INTO `stats_views` VALUES(229, 75, '/index.php', 1613431113);
INSERT INTO `stats_views` VALUES(230, 75, '/index.php', 1613431121);
INSERT INTO `stats_views` VALUES(231, 75, '/index.php', 1613431494);
INSERT INTO `stats_views` VALUES(232, 76, '/index.php', 1613432596);
INSERT INTO `stats_views` VALUES(233, 77, '/index.php', 1613434148);
INSERT INTO `stats_views` VALUES(234, 78, '/index.php', 1613441306);
INSERT INTO `stats_views` VALUES(235, 79, '/index.php', 1613456729);
INSERT INTO `stats_views` VALUES(236, 80, '/index.php', 1613464493);
INSERT INTO `stats_views` VALUES(237, 81, '/index.php', 1613468237);
INSERT INTO `stats_views` VALUES(238, 82, '/index.php', 1613478953);
INSERT INTO `stats_views` VALUES(239, 82, '/thank_you.php', 1613478953);
INSERT INTO `stats_views` VALUES(240, 82, '/index.php', 1613478957);
INSERT INTO `stats_views` VALUES(241, 82, '/index.php', 1613478958);
INSERT INTO `stats_views` VALUES(242, 83, '/index.php', 1613484902);
INSERT INTO `stats_views` VALUES(243, 84, '/index.php', 1613487432);
INSERT INTO `stats_views` VALUES(244, 84, '/index.php', 1613487647);
INSERT INTO `stats_views` VALUES(245, 84, '/index.php', 1613487647);
INSERT INTO `stats_views` VALUES(246, 85, '/index.php', 1613495728);
INSERT INTO `stats_views` VALUES(247, 86, '/index.php', 1613518750);
INSERT INTO `stats_views` VALUES(248, 87, '/index.php', 1613546961);
INSERT INTO `stats_views` VALUES(249, 87, '/index.php', 1613546968);
INSERT INTO `stats_views` VALUES(250, 87, '/login.php', 1613546969);
INSERT INTO `stats_views` VALUES(251, 87, '/faq.php', 1613546971);
INSERT INTO `stats_views` VALUES(252, 87, '/ticket.php', 1613546972);
INSERT INTO `stats_views` VALUES(253, 87, '/index.php', 1613546977);
INSERT INTO `stats_views` VALUES(254, 87, '/index.php', 1613546979);
INSERT INTO `stats_views` VALUES(255, 87, '/news.php', 1613546981);
INSERT INTO `stats_views` VALUES(256, 87, '/signup.php', 1613546982);
INSERT INTO `stats_views` VALUES(257, 87, '/content.php', 1613546984);
INSERT INTO `stats_views` VALUES(258, 87, '/forgot_password.php', 1613546985);
INSERT INTO `stats_views` VALUES(259, 87, '/index.php', 1613546987);
INSERT INTO `stats_views` VALUES(260, 88, '/index.php', 1613547292);
INSERT INTO `stats_views` VALUES(261, 89, '/index.php', 1613559429);
INSERT INTO `stats_views` VALUES(262, 90, '/index.php', 1613564584);
INSERT INTO `stats_views` VALUES(263, 91, '/index.php', 1613566365);
INSERT INTO `stats_views` VALUES(264, 92, '/signup.php', 1613566409);
INSERT INTO `stats_views` VALUES(265, 90, '/index.php', 1613566701);
INSERT INTO `stats_views` VALUES(266, 90, '/login.php', 1613566876);
INSERT INTO `stats_views` VALUES(267, 93, '/index.php', 1613566895);
INSERT INTO `stats_views` VALUES(268, 90, '/index.php', 1613567257);
INSERT INTO `stats_views` VALUES(269, 91, '/signup.php', 1613567274);
INSERT INTO `stats_views` VALUES(270, 94, '/index.php', 1613569763);
INSERT INTO `stats_views` VALUES(271, 95, '/index.php', 1613587139);
INSERT INTO `stats_views` VALUES(272, 96, '/index.php', 1613598505);
INSERT INTO `stats_views` VALUES(273, 97, '/index.php', 1613613693);
INSERT INTO `stats_views` VALUES(274, 98, '/index.php', 1613625983);
INSERT INTO `stats_views` VALUES(275, 99, '/index.php', 1613638121);
INSERT INTO `stats_views` VALUES(276, 100, '/index.php', 1613645329);
INSERT INTO `stats_views` VALUES(277, 100, '/signup.php', 1613645369);
INSERT INTO `stats_views` VALUES(278, 100, '/signup.php', 1613645376);
INSERT INTO `stats_views` VALUES(279, 100, '/thank_you.php', 1613645378);
INSERT INTO `stats_views` VALUES(280, 100, '/thank_you.php', 1613645467);
INSERT INTO `stats_views` VALUES(281, 100, '/thank_you.php', 1613645696);
INSERT INTO `stats_views` VALUES(282, 100, '/thank_you.php', 1613645698);
INSERT INTO `stats_views` VALUES(283, 100, '/thank_you.php', 1613645736);
INSERT INTO `stats_views` VALUES(284, 100, '/signup.php', 1613645737);
INSERT INTO `stats_views` VALUES(285, 100, '/index.php', 1613645737);
INSERT INTO `stats_views` VALUES(286, 100, '/signup.php', 1613645739);
INSERT INTO `stats_views` VALUES(287, 100, '/signup.php', 1613645742);
INSERT INTO `stats_views` VALUES(288, 100, '/thank_you.php', 1613645742);
INSERT INTO `stats_views` VALUES(289, 100, '/thank_you.php', 1613646218);
INSERT INTO `stats_views` VALUES(290, 100, '/thank_you.php', 1613646221);
INSERT INTO `stats_views` VALUES(291, 101, '/login.php', 1613659602);
INSERT INTO `stats_views` VALUES(292, 102, '/signup.php', 1613678510);
INSERT INTO `stats_views` VALUES(293, 103, '/index.php', 1613681381);
INSERT INTO `stats_views` VALUES(294, 104, '/index.php', 1613713653);
INSERT INTO `stats_views` VALUES(295, 105, '/index.php', 1613723552);
INSERT INTO `stats_views` VALUES(296, 106, '/index.php', 1613733177);
INSERT INTO `stats_views` VALUES(297, 107, '/index.php', 1613736058);
INSERT INTO `stats_views` VALUES(298, 107, '/index.php', 1613736108);
INSERT INTO `stats_views` VALUES(299, 107, '/signup.php', 1613736113);
INSERT INTO `stats_views` VALUES(300, 107, '/signup.php', 1613736127);
INSERT INTO `stats_views` VALUES(301, 107, '/thank_you.php', 1613736132);
INSERT INTO `stats_views` VALUES(302, 107, '/thank_you.php', 1613736358);
INSERT INTO `stats_views` VALUES(303, 107, '/signup.php', 1613736673);
INSERT INTO `stats_views` VALUES(304, 107, '/signup.php', 1613736681);
INSERT INTO `stats_views` VALUES(305, 107, '/activation.php', 1613736685);
INSERT INTO `stats_views` VALUES(306, 107, '/signup.php', 1613737448);
INSERT INTO `stats_views` VALUES(307, 107, '/index.php', 1613737518);
INSERT INTO `stats_views` VALUES(308, 107, '/signup.php', 1613737522);
INSERT INTO `stats_views` VALUES(309, 107, '/signup.php', 1613737566);
INSERT INTO `stats_views` VALUES(310, 107, '/thank_you.php', 1613737568);
INSERT INTO `stats_views` VALUES(311, 107, '/signup.php', 1613737596);
INSERT INTO `stats_views` VALUES(312, 107, '/index.php', 1613737600);
INSERT INTO `stats_views` VALUES(313, 107, '/login.php', 1613737602);
INSERT INTO `stats_views` VALUES(314, 107, '/login.php', 1613737612);
INSERT INTO `stats_views` VALUES(315, 107, '/index.php', 1613737694);
INSERT INTO `stats_views` VALUES(316, 107, '/signup.php', 1613737697);
INSERT INTO `stats_views` VALUES(317, 107, '/signup.php', 1613737724);
INSERT INTO `stats_views` VALUES(318, 107, '/thank_you.php', 1613737726);
INSERT INTO `stats_views` VALUES(319, 107, '/index.php', 1613737732);
INSERT INTO `stats_views` VALUES(320, 107, '/login.php', 1613737735);
INSERT INTO `stats_views` VALUES(321, 107, '/login.php', 1613737749);
INSERT INTO `stats_views` VALUES(322, 107, '/index.php', 1613739321);
INSERT INTO `stats_views` VALUES(323, 107, '/login.php', 1613739323);
INSERT INTO `stats_views` VALUES(324, 107, '/login.php', 1613739389);
INSERT INTO `stats_views` VALUES(325, 107, '/login.php', 1613739438);
INSERT INTO `stats_views` VALUES(326, 107, '/login.php', 1613739465);
INSERT INTO `stats_views` VALUES(327, 107, '/login.php', 1613739474);
INSERT INTO `stats_views` VALUES(328, 108, '/index.php', 1613812736);
INSERT INTO `stats_views` VALUES(329, 109, '/index.php', 1613830778);
INSERT INTO `stats_views` VALUES(330, 110, '/index.php', 1613838036);
INSERT INTO `stats_views` VALUES(331, 111, '/index.php', 1613873126);
INSERT INTO `stats_views` VALUES(332, 112, '/index.php', 1613905540);
INSERT INTO `stats_views` VALUES(333, 112, '/index.php', 1613905578);
INSERT INTO `stats_views` VALUES(334, 113, '/index.php', 1613907537);
INSERT INTO `stats_views` VALUES(335, 114, '/index.php', 1613911931);
INSERT INTO `stats_views` VALUES(336, 114, '/index.php', 1613912385);
INSERT INTO `stats_views` VALUES(337, 114, '/signup.php', 1613912391);
INSERT INTO `stats_views` VALUES(338, 114, '/signup.php', 1613912422);
INSERT INTO `stats_views` VALUES(339, 114, '/thank_you.php', 1613912425);
INSERT INTO `stats_views` VALUES(340, 114, '/index.php', 1613912646);
INSERT INTO `stats_views` VALUES(341, 114, '/index.php', 1613912703);
INSERT INTO `stats_views` VALUES(342, 114, '/signup.php', 1613912709);
INSERT INTO `stats_views` VALUES(343, 114, '/signup.php', 1613912730);
INSERT INTO `stats_views` VALUES(344, 114, '/login.php', 1613912732);
INSERT INTO `stats_views` VALUES(345, 114, '/login.php', 1613912748);
INSERT INTO `stats_views` VALUES(346, 115, '/index.php', 1613920827);
INSERT INTO `stats_views` VALUES(347, 115, '/index.php', 1613921098);
INSERT INTO `stats_views` VALUES(348, 115, '/index.php', 1613921139);
INSERT INTO `stats_views` VALUES(349, 115, '/index.php', 1613921384);
INSERT INTO `stats_views` VALUES(350, 115, '/index.php', 1613921418);
INSERT INTO `stats_views` VALUES(351, 115, '/index.php', 1613921543);
INSERT INTO `stats_views` VALUES(352, 115, '/index.php', 1613921599);
INSERT INTO `stats_views` VALUES(353, 115, '/index.php', 1613921942);
INSERT INTO `stats_views` VALUES(354, 115, '/index.php', 1613922094);
INSERT INTO `stats_views` VALUES(355, 115, '/index.php', 1613922264);
INSERT INTO `stats_views` VALUES(356, 115, '/index.php', 1613922288);
INSERT INTO `stats_views` VALUES(357, 115, '/index.php', 1613922536);
INSERT INTO `stats_views` VALUES(358, 115, '/index.php', 1613922687);
INSERT INTO `stats_views` VALUES(359, 115, '/index.php', 1613922940);
INSERT INTO `stats_views` VALUES(360, 115, '/index.php', 1613923011);
INSERT INTO `stats_views` VALUES(361, 115, '/index.php', 1613923343);
INSERT INTO `stats_views` VALUES(362, 115, '/index.php', 1613923387);
INSERT INTO `stats_views` VALUES(363, 116, '/index.php', 1613931299);
INSERT INTO `stats_views` VALUES(364, 117, '/index.php', 1614032761);
INSERT INTO `stats_views` VALUES(365, 118, '/index.php', 1614041164);
INSERT INTO `stats_views` VALUES(366, 119, '/signup.php', 1614076210);
INSERT INTO `stats_views` VALUES(367, 119, '/index.php', 1614076215);
INSERT INTO `stats_views` VALUES(368, 120, '/login.php', 1614076420);
INSERT INTO `stats_views` VALUES(369, 119, '/index.php', 1614076425);
INSERT INTO `stats_views` VALUES(370, 121, '/login.php', 1614076428);
INSERT INTO `stats_views` VALUES(371, 121, '/index.php', 1614076439);
INSERT INTO `stats_views` VALUES(372, 120, '/login.php', 1614076442);
INSERT INTO `stats_views` VALUES(373, 119, '/index.php', 1614076446);
INSERT INTO `stats_views` VALUES(374, 122, '/index.php', 1614103354);
INSERT INTO `stats_views` VALUES(375, 123, '/index.php', 1614151986);
INSERT INTO `stats_views` VALUES(376, 124, '/index.php', 1614155981);
INSERT INTO `stats_views` VALUES(377, 125, '/index.php', 1614265487);
INSERT INTO `stats_views` VALUES(378, 126, '/index.php', 1614289659);
INSERT INTO `stats_views` VALUES(379, 127, '/index.php', 1614320362);
INSERT INTO `stats_views` VALUES(380, 128, '/index.php', 1614340279);
INSERT INTO `stats_views` VALUES(381, 128, '/index.php', 1614340280);
INSERT INTO `stats_views` VALUES(382, 129, '/index.php', 1614343955);
INSERT INTO `stats_views` VALUES(383, 130, '/index.php', 1614351392);
INSERT INTO `stats_views` VALUES(384, 131, '/index.php', 1614352755);
INSERT INTO `stats_views` VALUES(385, 132, '/index.php', 1614363798);
INSERT INTO `stats_views` VALUES(386, 133, '/index.php', 1614367817);
INSERT INTO `stats_views` VALUES(387, 134, '/index.php', 1614381242);
INSERT INTO `stats_views` VALUES(388, 135, '/index.php', 1614408606);
INSERT INTO `stats_views` VALUES(389, 136, '/index.php', 1614412061);
INSERT INTO `stats_views` VALUES(390, 137, '/index.php', 1614425493);
INSERT INTO `stats_views` VALUES(391, 137, '/index.php', 1614425498);
INSERT INTO `stats_views` VALUES(392, 138, '/index.php', 1614425755);
INSERT INTO `stats_views` VALUES(393, 138, '/index.php', 1614425795);
INSERT INTO `stats_views` VALUES(394, 139, '/index.php', 1614426003);
INSERT INTO `stats_views` VALUES(395, 140, '/index.php', 1614428198);
INSERT INTO `stats_views` VALUES(396, 141, '/index.php', 1614428219);
INSERT INTO `stats_views` VALUES(397, 139, '/index.php', 1614434194);
INSERT INTO `stats_views` VALUES(398, 142, '/index.php', 1614439041);
INSERT INTO `stats_views` VALUES(399, 143, '/index.php', 1614441141);
INSERT INTO `stats_views` VALUES(400, 143, '/login.php', 1614441187);
INSERT INTO `stats_views` VALUES(401, 144, '/index.php', 1614446807);
INSERT INTO `stats_views` VALUES(402, 145, '/index.php', 1614446812);
INSERT INTO `stats_views` VALUES(403, 146, '/index.php', 1614458252);
INSERT INTO `stats_views` VALUES(404, 147, '/index.php', 1614459179);
INSERT INTO `stats_views` VALUES(405, 148, '/index.php', 1614495581);
INSERT INTO `stats_views` VALUES(406, 149, '/index.php', 1614504125);
INSERT INTO `stats_views` VALUES(407, 150, '/index.php', 1614504460);
INSERT INTO `stats_views` VALUES(408, 149, '/index.php', 1614505452);
INSERT INTO `stats_views` VALUES(409, 150, '/index.php', 1614505457);
INSERT INTO `stats_views` VALUES(410, 149, '/index.php', 1614505562);
INSERT INTO `stats_views` VALUES(411, 149, '/index.php', 1614505728);
INSERT INTO `stats_views` VALUES(412, 151, '/index.php', 1614505964);
INSERT INTO `stats_views` VALUES(413, 150, '/index.php', 1614506077);
INSERT INTO `stats_views` VALUES(414, 150, '/index.php', 1614506179);
INSERT INTO `stats_views` VALUES(415, 150, '/index.php', 1614506784);
INSERT INTO `stats_views` VALUES(416, 149, '/index.php', 1614506817);
INSERT INTO `stats_views` VALUES(417, 149, '/index.php', 1614507594);
INSERT INTO `stats_views` VALUES(418, 150, '/index.php', 1614507637);
INSERT INTO `stats_views` VALUES(419, 149, '/index.php', 1614507646);
INSERT INTO `stats_views` VALUES(420, 151, '/index.php', 1614508062);
INSERT INTO `stats_views` VALUES(421, 149, '/index.php', 1614508675);
INSERT INTO `stats_views` VALUES(422, 152, '/index.php', 1614510456);
INSERT INTO `stats_views` VALUES(423, 153, '/index.php', 1614514757);
INSERT INTO `stats_views` VALUES(424, 153, '/signup.php', 1614514784);
INSERT INTO `stats_views` VALUES(425, 153, '/index.php', 1614514788);
INSERT INTO `stats_views` VALUES(426, 154, '/index.php', 1614515244);
INSERT INTO `stats_views` VALUES(427, 155, '/index.php', 1614515328);
INSERT INTO `stats_views` VALUES(428, 156, '/index.php', 1614515641);
INSERT INTO `stats_views` VALUES(429, 157, '/index.php', 1614516518);
INSERT INTO `stats_views` VALUES(430, 157, '/index.php', 1614516766);
INSERT INTO `stats_views` VALUES(431, 158, '/index.php', 1614516821);
INSERT INTO `stats_views` VALUES(432, 153, '/index.php', 1614517552);
INSERT INTO `stats_views` VALUES(433, 158, '/index.php', 1614517872);
INSERT INTO `stats_views` VALUES(434, 158, '/index.php', 1614518077);
INSERT INTO `stats_views` VALUES(435, 153, '/index.php', 1614518724);
INSERT INTO `stats_views` VALUES(436, 159, '/index.php', 1614519790);
INSERT INTO `stats_views` VALUES(437, 158, '/index.php', 1614519847);
INSERT INTO `stats_views` VALUES(438, 159, '/index.php', 1614520094);
INSERT INTO `stats_views` VALUES(439, 158, '/index.php', 1614520153);
INSERT INTO `stats_views` VALUES(440, 157, '/index.php', 1614520165);
INSERT INTO `stats_views` VALUES(441, 159, '/index.php', 1614520304);
INSERT INTO `stats_views` VALUES(442, 157, '/index.php', 1614520334);
INSERT INTO `stats_views` VALUES(443, 159, '/index.php', 1614520487);
INSERT INTO `stats_views` VALUES(444, 158, '/index.php', 1614520673);
INSERT INTO `stats_views` VALUES(445, 157, '/index.php', 1614520758);
INSERT INTO `stats_views` VALUES(446, 157, '/index.php', 1614520821);
INSERT INTO `stats_views` VALUES(447, 158, '/index.php', 1614520879);
INSERT INTO `stats_views` VALUES(448, 159, '/index.php', 1614521036);
INSERT INTO `stats_views` VALUES(449, 159, '/index.php', 1614521216);
INSERT INTO `stats_views` VALUES(450, 159, '/index.php', 1614521246);
INSERT INTO `stats_views` VALUES(451, 157, '/index.php', 1614521453);
INSERT INTO `stats_views` VALUES(452, 159, '/index.php', 1614521578);
INSERT INTO `stats_views` VALUES(453, 160, '/index.php', 1614523336);
INSERT INTO `stats_views` VALUES(454, 161, '/index.php', 1614524385);
INSERT INTO `stats_views` VALUES(455, 158, '/index.php', 1614524658);
INSERT INTO `stats_views` VALUES(456, 162, '/index.php', 1614525160);
INSERT INTO `stats_views` VALUES(457, 163, '/index.php', 1614525163);
INSERT INTO `stats_views` VALUES(458, 161, '/index.php', 1614527818);
INSERT INTO `stats_views` VALUES(459, 161, '/index.php', 1614527818);
INSERT INTO `stats_views` VALUES(460, 164, '/index.php', 1614531561);
INSERT INTO `stats_views` VALUES(461, 165, '/index.php', 1614535898);
INSERT INTO `stats_views` VALUES(462, 166, '/index.php', 1614536406);
INSERT INTO `stats_views` VALUES(463, 167, '/index.php', 1614536440);
INSERT INTO `stats_views` VALUES(464, 166, '/login.php', 1614536452);
INSERT INTO `stats_views` VALUES(465, 166, '/index.php', 1614536455);
INSERT INTO `stats_views` VALUES(466, 166, '/login.php', 1614536458);
INSERT INTO `stats_views` VALUES(467, 165, '/index.php', 1614537189);
INSERT INTO `stats_views` VALUES(468, 168, '/index.php', 1614540553);
INSERT INTO `stats_views` VALUES(469, 168, '/index.php', 1614540554);
INSERT INTO `stats_views` VALUES(470, 169, '/index.php', 1614546695);
INSERT INTO `stats_views` VALUES(471, 170, '/index.php', 1614550567);
INSERT INTO `stats_views` VALUES(472, 171, '/index.php', 1614550985);
INSERT INTO `stats_views` VALUES(473, 172, '/index.php', 1614551122);
INSERT INTO `stats_views` VALUES(474, 171, '/index.php', 1614551169);
INSERT INTO `stats_views` VALUES(475, 171, '/index.php', 1614551210);
INSERT INTO `stats_views` VALUES(476, 173, '/index.php', 1614551763);
INSERT INTO `stats_views` VALUES(477, 173, '/index.php', 1614552752);
INSERT INTO `stats_views` VALUES(478, 171, '/index.php', 1614552847);
INSERT INTO `stats_views` VALUES(479, 171, '/index.php', 1614552968);
INSERT INTO `stats_views` VALUES(480, 173, '/index.php', 1614553119);
INSERT INTO `stats_views` VALUES(481, 172, '/index.php', 1614553140);
INSERT INTO `stats_views` VALUES(482, 171, '/index.php', 1614553364);
INSERT INTO `stats_views` VALUES(483, 172, '/index.php', 1614553563);
INSERT INTO `stats_views` VALUES(484, 172, '/index.php', 1614553646);
INSERT INTO `stats_views` VALUES(485, 172, '/index.php', 1614553763);
INSERT INTO `stats_views` VALUES(486, 172, '/index.php', 1614553929);
INSERT INTO `stats_views` VALUES(487, 172, '/index.php', 1614554084);
INSERT INTO `stats_views` VALUES(488, 171, '/index.php', 1614554156);
INSERT INTO `stats_views` VALUES(489, 172, '/index.php', 1614554398);
INSERT INTO `stats_views` VALUES(490, 173, '/index.php', 1614554519);
INSERT INTO `stats_views` VALUES(491, 173, '/index.php', 1614554551);
INSERT INTO `stats_views` VALUES(492, 171, '/index.php', 1614554774);
INSERT INTO `stats_views` VALUES(493, 171, '/index.php', 1614554927);
INSERT INTO `stats_views` VALUES(494, 171, '/index.php', 1614555061);
INSERT INTO `stats_views` VALUES(495, 173, '/index.php', 1614555373);
INSERT INTO `stats_views` VALUES(496, 172, '/index.php', 1614555733);
INSERT INTO `stats_views` VALUES(497, 173, '/index.php', 1614555785);
INSERT INTO `stats_views` VALUES(498, 173, '/index.php', 1614558095);
INSERT INTO `stats_views` VALUES(499, 172, '/index.php', 1614558156);
INSERT INTO `stats_views` VALUES(500, 174, '/index.php', 1614558825);
INSERT INTO `stats_views` VALUES(501, 172, '/index.php', 1614559533);
INSERT INTO `stats_views` VALUES(502, 171, '/index.php', 1614559613);
INSERT INTO `stats_views` VALUES(503, 174, '/index.php', 1614559850);
INSERT INTO `stats_views` VALUES(504, 172, '/index.php', 1614559957);
INSERT INTO `stats_views` VALUES(505, 175, '/index.php', 1614577605);
INSERT INTO `stats_views` VALUES(506, 175, '/index.php', 1614577605);
INSERT INTO `stats_views` VALUES(507, 176, '/index.php', 1614580679);
INSERT INTO `stats_views` VALUES(508, 177, '/index.php', 1614587011);
INSERT INTO `stats_views` VALUES(509, 178, '/index.php', 1614587016);
INSERT INTO `stats_views` VALUES(510, 179, '/index.php', 1614591553);
INSERT INTO `stats_views` VALUES(511, 180, '/index.php', 1614593404);
INSERT INTO `stats_views` VALUES(512, 181, '/index.php', 1614593658);
INSERT INTO `stats_views` VALUES(513, 182, '/index.php', 1614593907);
INSERT INTO `stats_views` VALUES(514, 182, '/index.php', 1614594111);
INSERT INTO `stats_views` VALUES(515, 183, '/index.php', 1614594513);
INSERT INTO `stats_views` VALUES(516, 184, '/login.php', 1614597548);
INSERT INTO `stats_views` VALUES(517, 184, '/index.php', 1614597561);
INSERT INTO `stats_views` VALUES(518, 183, '/index.php', 1614597927);
INSERT INTO `stats_views` VALUES(519, 185, '/index.php', 1614598291);
INSERT INTO `stats_views` VALUES(520, 186, '/index.php', 1614599996);
INSERT INTO `stats_views` VALUES(521, 187, '/index.php', 1614603928);
INSERT INTO `stats_views` VALUES(522, 188, '/index.php', 1614603958);
INSERT INTO `stats_views` VALUES(523, 188, '/index.php', 1614604263);
INSERT INTO `stats_views` VALUES(524, 188, '/index.php', 1614605306);
INSERT INTO `stats_views` VALUES(525, 188, '/index.php', 1614605318);
INSERT INTO `stats_views` VALUES(526, 189, '/index.php', 1614606939);
INSERT INTO `stats_views` VALUES(527, 190, '/index.php', 1614606940);
INSERT INTO `stats_views` VALUES(528, 191, '/index.php', 1614607054);
INSERT INTO `stats_views` VALUES(529, 192, '/index.php', 1614609933);
INSERT INTO `stats_views` VALUES(530, 193, '/index.php', 1614611391);
INSERT INTO `stats_views` VALUES(531, 194, '/index.php', 1614611829);
INSERT INTO `stats_views` VALUES(532, 195, '/index.php', 1614613891);
INSERT INTO `stats_views` VALUES(533, 196, '/index.php', 1614613906);
INSERT INTO `stats_views` VALUES(534, 197, '/login.php', 1614613975);
INSERT INTO `stats_views` VALUES(535, 196, '/index.php', 1614613997);
INSERT INTO `stats_views` VALUES(536, 198, '/index.php', 1614615606);
INSERT INTO `stats_views` VALUES(537, 199, '/signup.php', 1614615741);
INSERT INTO `stats_views` VALUES(538, 199, '/index.php', 1614615821);
INSERT INTO `stats_views` VALUES(539, 199, '/index.php', 1614615821);
INSERT INTO `stats_views` VALUES(540, 199, '/signup.php', 1614615852);
INSERT INTO `stats_views` VALUES(541, 200, '/index.php', 1614615857);
INSERT INTO `stats_views` VALUES(542, 201, '/index.php', 1614624525);
INSERT INTO `stats_views` VALUES(543, 202, '/index.php', 1614625201);
INSERT INTO `stats_views` VALUES(544, 202, '/index.php', 1614625201);
INSERT INTO `stats_views` VALUES(545, 202, '/index.php', 1614625211);
INSERT INTO `stats_views` VALUES(546, 202, '/login.php', 1614625291);
INSERT INTO `stats_views` VALUES(547, 201, '/index.php', 1614626952);
INSERT INTO `stats_views` VALUES(548, 203, '/index.php', 1614627004);
INSERT INTO `stats_views` VALUES(549, 204, '/index.php', 1614627016);
INSERT INTO `stats_views` VALUES(550, 204, '/index.php', 1614627016);
INSERT INTO `stats_views` VALUES(551, 201, '/index.php', 1614627077);
INSERT INTO `stats_views` VALUES(552, 205, '/index.php', 1614630681);
INSERT INTO `stats_views` VALUES(553, 206, '/index.php', 1614630711);
INSERT INTO `stats_views` VALUES(554, 206, '/index.php', 1614630769);
INSERT INTO `stats_views` VALUES(555, 207, '/index.php', 1614630860);
INSERT INTO `stats_views` VALUES(556, 207, '/signup.php', 1614631233);
INSERT INTO `stats_views` VALUES(557, 205, '/index.php', 1614631238);
INSERT INTO `stats_views` VALUES(558, 206, '/index.php', 1614631546);
INSERT INTO `stats_views` VALUES(559, 208, '/index.php', 1614632615);
INSERT INTO `stats_views` VALUES(560, 208, '/index.php', 1614632666);
INSERT INTO `stats_views` VALUES(561, 208, '/login.php', 1614632704);
INSERT INTO `stats_views` VALUES(562, 209, '/index.php', 1614637663);
INSERT INTO `stats_views` VALUES(563, 210, '/index.php', 1614640180);
INSERT INTO `stats_views` VALUES(564, 211, '/index.php', 1614640182);
INSERT INTO `stats_views` VALUES(565, 212, '/index.php', 1614666990);
INSERT INTO `stats_views` VALUES(566, 213, '/login.php', 1614669400);
INSERT INTO `stats_views` VALUES(567, 213, '/index.php', 1614669406);
INSERT INTO `stats_views` VALUES(568, 213, '/login.php', 1614669444);
INSERT INTO `stats_views` VALUES(569, 214, '/index.php', 1614672338);
INSERT INTO `stats_views` VALUES(570, 213, '/login.php', 1614679227);
INSERT INTO `stats_views` VALUES(571, 213, '/index.php', 1614679236);
INSERT INTO `stats_views` VALUES(572, 215, '/index.php', 1614680231);
INSERT INTO `stats_views` VALUES(573, 216, '/index.php', 1614680358);
INSERT INTO `stats_views` VALUES(574, 216, '/signup.php', 1614680439);
INSERT INTO `stats_views` VALUES(575, 217, '/signup.php', 1614680563);
INSERT INTO `stats_views` VALUES(576, 217, '/login.php', 1614680565);
INSERT INTO `stats_views` VALUES(577, 216, '/login.php', 1614680575);
INSERT INTO `stats_views` VALUES(578, 216, '/login.php', 1614680610);
INSERT INTO `stats_views` VALUES(579, 217, '/login.php', 1614680901);
INSERT INTO `stats_views` VALUES(580, 215, '/index.php', 1614681706);
INSERT INTO `stats_views` VALUES(581, 218, '/index.php', 1614697267);
INSERT INTO `stats_views` VALUES(582, 219, '/index.php', 1614710079);
INSERT INTO `stats_views` VALUES(583, 220, '/index.php', 1614710692);
INSERT INTO `stats_views` VALUES(584, 220, '/index.php', 1614710843);
INSERT INTO `stats_views` VALUES(585, 221, '/index.php', 1614714376);
INSERT INTO `stats_views` VALUES(586, 222, '/index.php', 1614740348);
INSERT INTO `stats_views` VALUES(587, 222, '/index.php', 1614740631);
INSERT INTO `stats_views` VALUES(588, 223, '/index.php', 1614740728);
INSERT INTO `stats_views` VALUES(589, 223, '/index.php', 1614740820);
INSERT INTO `stats_views` VALUES(590, 222, '/index.php', 1614740963);
INSERT INTO `stats_views` VALUES(591, 222, '/index.php', 1614740985);
INSERT INTO `stats_views` VALUES(592, 223, '/index.php', 1614741104);
INSERT INTO `stats_views` VALUES(593, 222, '/index.php', 1614741197);
INSERT INTO `stats_views` VALUES(594, 222, '/index.php', 1614741286);
INSERT INTO `stats_views` VALUES(595, 222, '/login.php', 1614741830);
INSERT INTO `stats_views` VALUES(596, 224, '/index.php', 1614755080);
INSERT INTO `stats_views` VALUES(597, 225, '/index.php', 1614760296);
INSERT INTO `stats_views` VALUES(598, 226, '/index.php', 1614760302);
INSERT INTO `stats_views` VALUES(599, 225, '/index.php', 1614760305);
INSERT INTO `stats_views` VALUES(600, 227, '/index.php', 1614764163);
INSERT INTO `stats_views` VALUES(601, 228, '/index.php', 1614764788);
INSERT INTO `stats_views` VALUES(602, 229, '/index.php', 1614766424);
INSERT INTO `stats_views` VALUES(603, 229, '/index.php', 1614769724);
INSERT INTO `stats_views` VALUES(604, 229, '/signup.php', 1614769729);
INSERT INTO `stats_views` VALUES(605, 229, '/signup.php', 1614769839);
INSERT INTO `stats_views` VALUES(606, 229, '/signup.php', 1614770135);
INSERT INTO `stats_views` VALUES(607, 229, '/signup.php', 1614770181);
INSERT INTO `stats_views` VALUES(608, 229, '/login.php', 1614770184);
INSERT INTO `stats_views` VALUES(609, 229, '/login.php', 1614770200);
INSERT INTO `stats_views` VALUES(610, 229, '/index.php', 1614771028);
INSERT INTO `stats_views` VALUES(611, 229, '/index.php', 1614771660);
INSERT INTO `stats_views` VALUES(612, 230, '/index.php', 1614772440);
INSERT INTO `stats_views` VALUES(613, 231, '/signup.php', 1614772474);
INSERT INTO `stats_views` VALUES(614, 232, '/index.php', 1614773262);
INSERT INTO `stats_views` VALUES(615, 233, '/index.php', 1614778797);
INSERT INTO `stats_views` VALUES(616, 234, '/index.php', 1614793460);
INSERT INTO `stats_views` VALUES(617, 235, '/index.php', 1614793954);
INSERT INTO `stats_views` VALUES(618, 234, '/index.php', 1614794032);
INSERT INTO `stats_views` VALUES(619, 234, '/index.php', 1614794593);
INSERT INTO `stats_views` VALUES(620, 234, '/index.php', 1614794690);
INSERT INTO `stats_views` VALUES(621, 235, '/index.php', 1614794961);
INSERT INTO `stats_views` VALUES(622, 234, '/index.php', 1614795099);
INSERT INTO `stats_views` VALUES(623, 235, '/index.php', 1614795120);
INSERT INTO `stats_views` VALUES(624, 236, '/index.php', 1614795215);
INSERT INTO `stats_views` VALUES(625, 236, '/index.php', 1614795359);
INSERT INTO `stats_views` VALUES(626, 234, '/index.php', 1614795448);
INSERT INTO `stats_views` VALUES(627, 236, '/index.php', 1614795506);
INSERT INTO `stats_views` VALUES(628, 234, '/index.php', 1614795553);
INSERT INTO `stats_views` VALUES(629, 235, '/index.php', 1614795562);
INSERT INTO `stats_views` VALUES(630, 234, '/index.php', 1614795640);
INSERT INTO `stats_views` VALUES(631, 234, '/index.php', 1614795715);
INSERT INTO `stats_views` VALUES(632, 234, '/index.php', 1614795833);
INSERT INTO `stats_views` VALUES(633, 237, '/index.php', 1614804137);
INSERT INTO `stats_views` VALUES(634, 238, '/index.php', 1614804314);
INSERT INTO `stats_views` VALUES(635, 239, '/index.php', 1614804416);
INSERT INTO `stats_views` VALUES(636, 238, '/signup.php', 1614804424);
INSERT INTO `stats_views` VALUES(637, 238, '/index.php', 1614804652);
INSERT INTO `stats_views` VALUES(638, 240, '/index.php', 1614804666);
INSERT INTO `stats_views` VALUES(639, 240, '/index.php', 1614804761);
INSERT INTO `stats_views` VALUES(640, 237, '/index.php', 1614805093);
INSERT INTO `stats_views` VALUES(641, 241, '/index.php', 1614805170);
INSERT INTO `stats_views` VALUES(642, 241, '/index.php', 1614805252);
INSERT INTO `stats_views` VALUES(643, 237, '/index.php', 1614805316);
INSERT INTO `stats_views` VALUES(644, 242, '/index.php', 1614805614);
INSERT INTO `stats_views` VALUES(645, 243, '/index.php', 1614805917);
INSERT INTO `stats_views` VALUES(646, 243, '/index.php', 1614805917);
INSERT INTO `stats_views` VALUES(647, 240, '/index.php', 1614805921);
INSERT INTO `stats_views` VALUES(648, 241, '/index.php', 1614806506);
INSERT INTO `stats_views` VALUES(649, 237, '/index.php', 1614806866);
INSERT INTO `stats_views` VALUES(650, 241, '/index.php', 1614806983);
INSERT INTO `stats_views` VALUES(651, 240, '/index.php', 1614807109);
INSERT INTO `stats_views` VALUES(652, 237, '/index.php', 1614807961);
INSERT INTO `stats_views` VALUES(653, 237, '/index.php', 1614809492);
INSERT INTO `stats_views` VALUES(654, 240, '/index.php', 1614809582);
INSERT INTO `stats_views` VALUES(655, 237, '/index.php', 1614809698);
INSERT INTO `stats_views` VALUES(656, 240, '/index.php', 1614809853);
INSERT INTO `stats_views` VALUES(657, 237, '/index.php', 1614809921);
INSERT INTO `stats_views` VALUES(658, 244, '/index.php', 1614813892);
INSERT INTO `stats_views` VALUES(659, 237, '/index.php', 1614814216);
INSERT INTO `stats_views` VALUES(660, 240, '/index.php', 1614814279);
INSERT INTO `stats_views` VALUES(661, 243, '/index.php', 1614814287);
INSERT INTO `stats_views` VALUES(662, 240, '/index.php', 1614814345);
INSERT INTO `stats_views` VALUES(663, 237, '/index.php', 1614814404);
INSERT INTO `stats_views` VALUES(664, 244, '/index.php', 1614814511);
INSERT INTO `stats_views` VALUES(665, 240, '/index.php', 1614814707);
INSERT INTO `stats_views` VALUES(666, 244, '/index.php', 1614814918);
INSERT INTO `stats_views` VALUES(667, 244, '/index.php', 1614814957);
INSERT INTO `stats_views` VALUES(668, 240, '/index.php', 1614815035);
INSERT INTO `stats_views` VALUES(669, 245, '/index.php', 1614815140);
INSERT INTO `stats_views` VALUES(670, 240, '/index.php', 1614815193);
INSERT INTO `stats_views` VALUES(671, 240, '/index.php', 1614815239);
INSERT INTO `stats_views` VALUES(672, 245, '/index.php', 1614815346);
INSERT INTO `stats_views` VALUES(673, 240, '/index.php', 1614815403);
INSERT INTO `stats_views` VALUES(674, 240, '/index.php', 1614815448);
INSERT INTO `stats_views` VALUES(675, 246, '/index.php', 1614815674);
INSERT INTO `stats_views` VALUES(676, 245, '/index.php', 1614815952);
INSERT INTO `stats_views` VALUES(677, 246, '/index.php', 1614816005);
INSERT INTO `stats_views` VALUES(678, 247, '/index.php', 1614823334);
INSERT INTO `stats_views` VALUES(679, 248, '/index.php', 1614845603);
INSERT INTO `stats_views` VALUES(680, 249, '/index.php', 1614855077);
INSERT INTO `stats_views` VALUES(681, 250, '/index.php', 1614858100);
INSERT INTO `stats_views` VALUES(682, 250, '/signup.php', 1614858145);
INSERT INTO `stats_views` VALUES(683, 249, '/index.php', 1614858585);
INSERT INTO `stats_views` VALUES(684, 251, '/index.php', 1614858687);
INSERT INTO `stats_views` VALUES(685, 249, '/index.php', 1614858863);
INSERT INTO `stats_views` VALUES(686, 249, '/index.php', 1614858954);
INSERT INTO `stats_views` VALUES(687, 249, '/index.php', 1614859169);
INSERT INTO `stats_views` VALUES(688, 249, '/index.php', 1614859350);
INSERT INTO `stats_views` VALUES(689, 249, '/index.php', 1614859366);
INSERT INTO `stats_views` VALUES(690, 249, '/index.php', 1614859546);
INSERT INTO `stats_views` VALUES(691, 249, '/index.php', 1614859671);
INSERT INTO `stats_views` VALUES(692, 249, '/index.php', 1614859787);
INSERT INTO `stats_views` VALUES(693, 249, '/index.php', 1614859897);
INSERT INTO `stats_views` VALUES(694, 249, '/index.php', 1614859965);
INSERT INTO `stats_views` VALUES(695, 249, '/index.php', 1614860083);
INSERT INTO `stats_views` VALUES(696, 249, '/index.php', 1614860167);
INSERT INTO `stats_views` VALUES(697, 249, '/index.php', 1614860244);
INSERT INTO `stats_views` VALUES(698, 249, '/index.php', 1614860303);
INSERT INTO `stats_views` VALUES(699, 249, '/index.php', 1614860580);
INSERT INTO `stats_views` VALUES(700, 249, '/index.php', 1614860949);
INSERT INTO `stats_views` VALUES(701, 249, '/index.php', 1614861068);
INSERT INTO `stats_views` VALUES(702, 249, '/index.php', 1614861110);
INSERT INTO `stats_views` VALUES(703, 249, '/index.php', 1614861191);
INSERT INTO `stats_views` VALUES(704, 249, '/index.php', 1614861289);
INSERT INTO `stats_views` VALUES(705, 249, '/index.php', 1614861382);
INSERT INTO `stats_views` VALUES(706, 249, '/index.php', 1614861516);
INSERT INTO `stats_views` VALUES(707, 249, '/index.php', 1614861632);
INSERT INTO `stats_views` VALUES(708, 249, '/index.php', 1614861673);
INSERT INTO `stats_views` VALUES(709, 249, '/index.php', 1614861729);
INSERT INTO `stats_views` VALUES(710, 252, '/index.php', 1614861792);
INSERT INTO `stats_views` VALUES(711, 252, '/index.php', 1614863214);
INSERT INTO `stats_views` VALUES(712, 253, '/index.php', 1614875928);
INSERT INTO `stats_views` VALUES(713, 254, '/index.php', 1614885184);
INSERT INTO `stats_views` VALUES(714, 254, '/login.php', 1614885767);
INSERT INTO `stats_views` VALUES(715, 255, '/index.php', 1614885772);
INSERT INTO `stats_views` VALUES(716, 256, '/login.php', 1614886356);
INSERT INTO `stats_views` VALUES(717, 257, '/index.php', 1614886367);
INSERT INTO `stats_views` VALUES(718, 257, '/login.php', 1614886372);
INSERT INTO `stats_views` VALUES(719, 257, '/index.php', 1614886378);
INSERT INTO `stats_views` VALUES(720, 254, '/signup.php', 1614886383);
INSERT INTO `stats_views` VALUES(721, 256, '/signup.php', 1614886446);
INSERT INTO `stats_views` VALUES(722, 254, '/signup.php', 1614886455);
INSERT INTO `stats_views` VALUES(723, 257, '/content.php', 1614886460);
INSERT INTO `stats_views` VALUES(724, 254, '/signup.php', 1614886466);
INSERT INTO `stats_views` VALUES(725, 256, '/index.php', 1614886493);
INSERT INTO `stats_views` VALUES(726, 257, '/index.php', 1614887389);
INSERT INTO `stats_views` VALUES(727, 258, '/index.php', 1614890856);
INSERT INTO `stats_views` VALUES(728, 259, '/index.php', 1614891590);
INSERT INTO `stats_views` VALUES(729, 260, '/index.php', 1614893418);
INSERT INTO `stats_views` VALUES(730, 261, '/index.php', 1614927410);
INSERT INTO `stats_views` VALUES(731, 262, '/index.php', 1614933176);
INSERT INTO `stats_views` VALUES(732, 262, '/signup.php', 1614933188);
INSERT INTO `stats_views` VALUES(733, 263, '/signup.php', 1614933311);
INSERT INTO `stats_views` VALUES(734, 263, '/login.php', 1614933313);
INSERT INTO `stats_views` VALUES(735, 264, '/login.php', 1614933351);
INSERT INTO `stats_views` VALUES(736, 263, '/login.php', 1614933551);
INSERT INTO `stats_views` VALUES(737, 263, '/signup.php', 1614933705);
INSERT INTO `stats_views` VALUES(738, 264, '/index.php', 1614933729);
INSERT INTO `stats_views` VALUES(739, 265, '/index.php', 1614939323);
INSERT INTO `stats_views` VALUES(740, 266, '/index.php', 1614939895);
INSERT INTO `stats_views` VALUES(741, 267, '/signup.php', 1614939903);
INSERT INTO `stats_views` VALUES(742, 268, '/index.php', 1614939910);
INSERT INTO `stats_views` VALUES(743, 269, '/index.php', 1614940038);
INSERT INTO `stats_views` VALUES(744, 265, '/index.php', 1614940073);
INSERT INTO `stats_views` VALUES(745, 269, '/login.php', 1614940102);
INSERT INTO `stats_views` VALUES(746, 269, '/index.php', 1614940153);
INSERT INTO `stats_views` VALUES(747, 269, '/index.php', 1614940156);
INSERT INTO `stats_views` VALUES(748, 269, '/signup.php', 1614940168);
INSERT INTO `stats_views` VALUES(749, 270, '/index.php', 1614940241);
INSERT INTO `stats_views` VALUES(750, 271, '/signup.php', 1614940273);
INSERT INTO `stats_views` VALUES(751, 269, '/signup.php', 1614940276);
INSERT INTO `stats_views` VALUES(752, 269, '/login.php', 1614940279);
INSERT INTO `stats_views` VALUES(753, 272, '/index.php', 1614940280);
INSERT INTO `stats_views` VALUES(754, 269, '/login.php', 1614940299);
INSERT INTO `stats_views` VALUES(755, 272, '/signup.php', 1614940303);
INSERT INTO `stats_views` VALUES(756, 273, '/signup.php', 1614940357);
INSERT INTO `stats_views` VALUES(757, 274, '/signup.php', 1614940439);
INSERT INTO `stats_views` VALUES(758, 274, '/login.php', 1614940441);
INSERT INTO `stats_views` VALUES(759, 275, '/login.php', 1614940491);
INSERT INTO `stats_views` VALUES(760, 275, '/signup.php', 1614940536);
INSERT INTO `stats_views` VALUES(761, 272, '/signup.php', 1614940548);
INSERT INTO `stats_views` VALUES(762, 272, '/login.php', 1614940550);
INSERT INTO `stats_views` VALUES(763, 272, '/login.php', 1614940590);
INSERT INTO `stats_views` VALUES(764, 272, '/login.php', 1614940623);
INSERT INTO `stats_views` VALUES(765, 269, '/index.php', 1614940684);
INSERT INTO `stats_views` VALUES(766, 269, '/login.php', 1614940705);
INSERT INTO `stats_views` VALUES(767, 269, '/index.php', 1614940730);
INSERT INTO `stats_views` VALUES(768, 269, '/index.php', 1614940732);
INSERT INTO `stats_views` VALUES(769, 275, '/index.php', 1614940740);
INSERT INTO `stats_views` VALUES(770, 269, '/signup.php', 1614940780);
INSERT INTO `stats_views` VALUES(771, 269, '/signup.php', 1614940981);
INSERT INTO `stats_views` VALUES(772, 269, '/signup.php', 1614940984);
INSERT INTO `stats_views` VALUES(773, 272, '/login.php', 1614941027);
INSERT INTO `stats_views` VALUES(774, 272, '/signup.php', 1614941036);
INSERT INTO `stats_views` VALUES(775, 269, '/signup.php', 1614941047);
INSERT INTO `stats_views` VALUES(776, 272, '/index.php', 1614941055);
INSERT INTO `stats_views` VALUES(777, 269, '/signup.php', 1614941145);
INSERT INTO `stats_views` VALUES(778, 269, '/signup.php', 1614941152);
INSERT INTO `stats_views` VALUES(779, 269, '/signup.php', 1614941201);
INSERT INTO `stats_views` VALUES(780, 269, '/signup.php', 1614941214);
INSERT INTO `stats_views` VALUES(781, 269, '/index.php', 1614941215);
INSERT INTO `stats_views` VALUES(782, 269, '/index.php', 1614941237);
INSERT INTO `stats_views` VALUES(783, 269, '/signup.php', 1614941291);
INSERT INTO `stats_views` VALUES(784, 269, '/signup.php', 1614941578);
INSERT INTO `stats_views` VALUES(785, 269, '/signup.php', 1614941628);
INSERT INTO `stats_views` VALUES(786, 269, '/index.php', 1614941641);
INSERT INTO `stats_views` VALUES(787, 269, '/index.php', 1614941641);
INSERT INTO `stats_views` VALUES(788, 269, '/signup.php', 1614941659);
INSERT INTO `stats_views` VALUES(789, 269, '/index.php', 1614941693);
INSERT INTO `stats_views` VALUES(790, 269, '/login.php', 1614941696);
INSERT INTO `stats_views` VALUES(791, 269, '/login.php', 1614941713);
INSERT INTO `stats_views` VALUES(792, 272, '/index.php', 1614941943);
INSERT INTO `stats_views` VALUES(793, 272, '/signup.php', 1614941982);
INSERT INTO `stats_views` VALUES(794, 272, '/index.php', 1614941991);
INSERT INTO `stats_views` VALUES(795, 272, '/login.php', 1614941996);
INSERT INTO `stats_views` VALUES(796, 272, '/login.php', 1614942017);
INSERT INTO `stats_views` VALUES(797, 276, '/index.php', 1614942056);
INSERT INTO `stats_views` VALUES(798, 276, '/signup.php', 1614942064);
INSERT INTO `stats_views` VALUES(799, 269, '/login.php', 1614942172);
INSERT INTO `stats_views` VALUES(800, 269, '/login.php', 1614942184);
INSERT INTO `stats_views` VALUES(801, 275, '/signup.php', 1614942235);
INSERT INTO `stats_views` VALUES(802, 275, '/login.php', 1614942238);
INSERT INTO `stats_views` VALUES(803, 269, '/index.php', 1614942342);
INSERT INTO `stats_views` VALUES(804, 269, '/signup.php', 1614942354);
INSERT INTO `stats_views` VALUES(805, 269, '/index.php', 1614942381);
INSERT INTO `stats_views` VALUES(806, 269, '/login.php', 1614942412);
INSERT INTO `stats_views` VALUES(807, 269, '/login.php', 1614942417);
INSERT INTO `stats_views` VALUES(808, 275, '/signup.php', 1614942561);
INSERT INTO `stats_views` VALUES(809, 272, '/index.php', 1614943232);
INSERT INTO `stats_views` VALUES(810, 272, '/login.php', 1614943244);
INSERT INTO `stats_views` VALUES(811, 272, '/login.php', 1614943263);
INSERT INTO `stats_views` VALUES(812, 272, '/index.php', 1614943878);
INSERT INTO `stats_views` VALUES(813, 277, '/index.php', 1614947325);
INSERT INTO `stats_views` VALUES(814, 278, '/login.php', 1614947976);
INSERT INTO `stats_views` VALUES(815, 279, '/index.php', 1614950020);
INSERT INTO `stats_views` VALUES(816, 279, '/index.php', 1614950275);
INSERT INTO `stats_views` VALUES(817, 280, '/index.php', 1614953920);
INSERT INTO `stats_views` VALUES(818, 280, '/signup.php', 1614954492);
INSERT INTO `stats_views` VALUES(819, 280, '/index.php', 1614954558);
INSERT INTO `stats_views` VALUES(820, 281, '/index.php', 1614961078);
INSERT INTO `stats_views` VALUES(821, 282, '/signup.php', 1614961087);
INSERT INTO `stats_views` VALUES(822, 281, '/index.php', 1614961105);
INSERT INTO `stats_views` VALUES(823, 282, '/index.php', 1614961109);
INSERT INTO `stats_views` VALUES(824, 283, '/index.php', 1614977198);
INSERT INTO `stats_views` VALUES(825, 284, '/index.php', 1614978947);
INSERT INTO `stats_views` VALUES(826, 285, '/signup.php', 1614978956);
INSERT INTO `stats_views` VALUES(827, 286, '/index.php', 1614979123);
INSERT INTO `stats_views` VALUES(828, 284, '/index.php', 1614979371);
INSERT INTO `stats_views` VALUES(829, 285, '/signup.php', 1614979379);
INSERT INTO `stats_views` VALUES(830, 284, '/index.php', 1614979387);
INSERT INTO `stats_views` VALUES(831, 287, '/index.php', 1614984434);
INSERT INTO `stats_views` VALUES(832, 287, '/index.php', 1614984434);
INSERT INTO `stats_views` VALUES(833, 288, '/index.php', 1614997064);
INSERT INTO `stats_views` VALUES(834, 289, '/index.php', 1615018668);
INSERT INTO `stats_views` VALUES(835, 289, '/signup.php', 1615018682);
INSERT INTO `stats_views` VALUES(836, 289, '/index.php', 1615018713);
INSERT INTO `stats_views` VALUES(837, 289, '/index.php', 1615018713);
INSERT INTO `stats_views` VALUES(838, 289, '/index.php', 1615019095);
INSERT INTO `stats_views` VALUES(839, 289, '/index.php', 1615020839);
INSERT INTO `stats_views` VALUES(840, 290, '/index.php', 1615033216);
INSERT INTO `stats_views` VALUES(841, 290, '/signup.php', 1615033224);
INSERT INTO `stats_views` VALUES(842, 291, '/index.php', 1615033248);
INSERT INTO `stats_views` VALUES(843, 290, '/index.php', 1615033342);
INSERT INTO `stats_views` VALUES(844, 292, '/index.php', 1615033424);
INSERT INTO `stats_views` VALUES(845, 290, '/signup.php', 1615033429);
INSERT INTO `stats_views` VALUES(846, 292, '/index.php', 1615033608);
INSERT INTO `stats_views` VALUES(847, 293, '/index.php', 1615046956);
INSERT INTO `stats_views` VALUES(848, 294, '/signup.php', 1615046964);
INSERT INTO `stats_views` VALUES(849, 295, '/signup.php', 1615047080);
INSERT INTO `stats_views` VALUES(850, 295, '/signup.php', 1615047109);
INSERT INTO `stats_views` VALUES(851, 293, '/signup.php', 1615047197);
INSERT INTO `stats_views` VALUES(852, 295, '/signup.php', 1615047253);
INSERT INTO `stats_views` VALUES(853, 295, '/signup.php', 1615047264);
INSERT INTO `stats_views` VALUES(854, 295, '/index.php', 1615047266);
INSERT INTO `stats_views` VALUES(855, 296, '/index.php', 1615047864);
INSERT INTO `stats_views` VALUES(856, 295, '/index.php', 1615047888);
INSERT INTO `stats_views` VALUES(857, 296, '/index.php', 1615048031);
INSERT INTO `stats_views` VALUES(858, 294, '/index.php', 1615048563);
INSERT INTO `stats_views` VALUES(859, 294, '/signup.php', 1615048567);
INSERT INTO `stats_views` VALUES(860, 295, '/signup.php', 1615048686);
INSERT INTO `stats_views` VALUES(861, 295, '/login.php', 1615048688);
INSERT INTO `stats_views` VALUES(862, 294, '/login.php', 1615048717);
INSERT INTO `stats_views` VALUES(863, 295, '/login.php', 1615049233);
INSERT INTO `stats_views` VALUES(864, 294, '/signup.php', 1615049560);
INSERT INTO `stats_views` VALUES(865, 294, '/index.php', 1615049563);
INSERT INTO `stats_views` VALUES(866, 294, '/signup.php', 1615049568);
INSERT INTO `stats_views` VALUES(867, 293, '/index.php', 1615049586);
INSERT INTO `stats_views` VALUES(868, 297, '/index.php', 1615055602);
INSERT INTO `stats_views` VALUES(869, 298, '/signup.php', 1615055621);
INSERT INTO `stats_views` VALUES(870, 297, '/index.php', 1615055637);
INSERT INTO `stats_views` VALUES(871, 298, '/index.php', 1615055943);
INSERT INTO `stats_views` VALUES(872, 299, '/signup.php', 1615055951);
INSERT INTO `stats_views` VALUES(873, 297, '/signup.php', 1615056130);
INSERT INTO `stats_views` VALUES(874, 297, '/login.php', 1615056132);
INSERT INTO `stats_views` VALUES(875, 297, '/login.php', 1615056166);
INSERT INTO `stats_views` VALUES(876, 297, '/login.php', 1615056466);
INSERT INTO `stats_views` VALUES(877, 299, '/signup.php', 1615056468);
INSERT INTO `stats_views` VALUES(878, 298, '/index.php', 1615056470);
INSERT INTO `stats_views` VALUES(879, 299, '/signup.php', 1615056479);
INSERT INTO `stats_views` VALUES(880, 299, '/signup.php', 1615056696);
INSERT INTO `stats_views` VALUES(881, 297, '/signup.php', 1615056728);
INSERT INTO `stats_views` VALUES(882, 297, '/index.php', 1615056753);
INSERT INTO `stats_views` VALUES(883, 298, '/index.php', 1615056766);
INSERT INTO `stats_views` VALUES(884, 297, '/signup.php', 1615056773);
INSERT INTO `stats_views` VALUES(885, 297, '/index.php', 1615056783);
INSERT INTO `stats_views` VALUES(886, 297, '/index.php', 1615056979);
INSERT INTO `stats_views` VALUES(887, 297, '/signup.php', 1615056998);
INSERT INTO `stats_views` VALUES(888, 298, '/signup.php', 1615057089);
INSERT INTO `stats_views` VALUES(889, 297, '/signup.php', 1615057131);
INSERT INTO `stats_views` VALUES(890, 299, '/index.php', 1615057133);
INSERT INTO `stats_views` VALUES(891, 298, '/signup.php', 1615057137);
INSERT INTO `stats_views` VALUES(892, 297, '/signup.php', 1615057249);
INSERT INTO `stats_views` VALUES(893, 297, '/login.php', 1615057251);
INSERT INTO `stats_views` VALUES(894, 300, '/login.php', 1615057294);
INSERT INTO `stats_views` VALUES(895, 299, '/login.php', 1615057473);
INSERT INTO `stats_views` VALUES(896, 297, '/signup.php', 1615057476);
INSERT INTO `stats_views` VALUES(897, 300, '/index.php', 1615057480);
INSERT INTO `stats_views` VALUES(898, 300, '/index.php', 1615057580);
INSERT INTO `stats_views` VALUES(899, 299, '/signup.php', 1615057588);
INSERT INTO `stats_views` VALUES(900, 300, '/signup.php', 1615057819);
INSERT INTO `stats_views` VALUES(901, 300, '/login.php', 1615057821);
INSERT INTO `stats_views` VALUES(902, 297, '/login.php', 1615057842);
INSERT INTO `stats_views` VALUES(903, 297, '/login.php', 1615057858);
INSERT INTO `stats_views` VALUES(904, 297, '/signup.php', 1615057860);
INSERT INTO `stats_views` VALUES(905, 300, '/index.php', 1615058002);
INSERT INTO `stats_views` VALUES(906, 299, '/signup.php', 1615058057);
INSERT INTO `stats_views` VALUES(907, 297, '/signup.php', 1615058271);
INSERT INTO `stats_views` VALUES(908, 297, '/login.php', 1615058273);
INSERT INTO `stats_views` VALUES(909, 299, '/login.php', 1615058290);
INSERT INTO `stats_views` VALUES(910, 300, '/login.php', 1615058295);
INSERT INTO `stats_views` VALUES(911, 299, '/signup.php', 1615058298);
INSERT INTO `stats_views` VALUES(912, 300, '/index.php', 1615058300);
INSERT INTO `stats_views` VALUES(913, 301, '/index.php', 1615062869);
INSERT INTO `stats_views` VALUES(914, 302, '/signup.php', 1615062875);
INSERT INTO `stats_views` VALUES(915, 301, '/signup.php', 1615063079);
INSERT INTO `stats_views` VALUES(916, 301, '/signup.php', 1615063089);
INSERT INTO `stats_views` VALUES(917, 301, '/signup.php', 1615063126);
INSERT INTO `stats_views` VALUES(918, 303, '/signup.php', 1615063139);
INSERT INTO `stats_views` VALUES(919, 302, '/signup.php', 1615063201);
INSERT INTO `stats_views` VALUES(920, 302, '/login.php', 1615063203);
INSERT INTO `stats_views` VALUES(921, 301, '/login.php', 1615063230);
INSERT INTO `stats_views` VALUES(922, 301, '/login.php', 1615063334);
INSERT INTO `stats_views` VALUES(923, 304, '/signup.php', 1615063341);
INSERT INTO `stats_views` VALUES(924, 302, '/index.php', 1615063343);
INSERT INTO `stats_views` VALUES(925, 302, '/index.php', 1615063504);
INSERT INTO `stats_views` VALUES(926, 302, '/signup.php', 1615063512);
INSERT INTO `stats_views` VALUES(927, 304, '/signup.php', 1615063745);
INSERT INTO `stats_views` VALUES(928, 304, '/login.php', 1615063747);
INSERT INTO `stats_views` VALUES(929, 301, '/login.php', 1615063804);
INSERT INTO `stats_views` VALUES(930, 305, '/login.php', 1615063834);
INSERT INTO `stats_views` VALUES(931, 305, '/signup.php', 1615063851);
INSERT INTO `stats_views` VALUES(932, 301, '/index.php', 1615063856);
INSERT INTO `stats_views` VALUES(933, 306, '/index.php', 1615064513);
INSERT INTO `stats_views` VALUES(934, 307, '/signup.php', 1615064527);
INSERT INTO `stats_views` VALUES(935, 306, '/signup.php', 1615064771);
INSERT INTO `stats_views` VALUES(936, 308, '/signup.php', 1615064777);
INSERT INTO `stats_views` VALUES(937, 308, '/signup.php', 1615064801);
INSERT INTO `stats_views` VALUES(938, 308, '/login.php', 1615064804);
INSERT INTO `stats_views` VALUES(939, 308, '/login.php', 1615064827);
INSERT INTO `stats_views` VALUES(940, 308, '/login.php', 1615064842);
INSERT INTO `stats_views` VALUES(941, 309, '/signup.php', 1615064847);
INSERT INTO `stats_views` VALUES(942, 309, '/index.php', 1615064849);
INSERT INTO `stats_views` VALUES(943, 310, '/index.php', 1615065099);
INSERT INTO `stats_views` VALUES(944, 310, '/signup.php', 1615065108);
INSERT INTO `stats_views` VALUES(945, 308, '/signup.php', 1615065317);
INSERT INTO `stats_views` VALUES(946, 308, '/login.php', 1615065320);
INSERT INTO `stats_views` VALUES(947, 308, '/login.php', 1615065362);
INSERT INTO `stats_views` VALUES(948, 306, '/login.php', 1615065380);
INSERT INTO `stats_views` VALUES(949, 306, '/signup.php', 1615065389);
INSERT INTO `stats_views` VALUES(950, 306, '/index.php', 1615065395);
INSERT INTO `stats_views` VALUES(951, 306, '/index.php', 1615065663);
INSERT INTO `stats_views` VALUES(952, 306, '/signup.php', 1615065671);
INSERT INTO `stats_views` VALUES(953, 306, '/signup.php', 1615065900);
INSERT INTO `stats_views` VALUES(954, 306, '/login.php', 1615065902);
INSERT INTO `stats_views` VALUES(955, 306, '/login.php', 1615065948);
INSERT INTO `stats_views` VALUES(956, 311, '/login.php', 1615065958);
INSERT INTO `stats_views` VALUES(957, 311, '/signup.php', 1615065972);
INSERT INTO `stats_views` VALUES(958, 309, '/index.php', 1615065982);
INSERT INTO `stats_views` VALUES(959, 311, '/index.php', 1615066105);
INSERT INTO `stats_views` VALUES(960, 306, '/signup.php', 1615066114);
INSERT INTO `stats_views` VALUES(961, 306, '/signup.php', 1615066256);
INSERT INTO `stats_views` VALUES(962, 306, '/login.php', 1615066258);
INSERT INTO `stats_views` VALUES(963, 311, '/login.php', 1615066281);
INSERT INTO `stats_views` VALUES(964, 309, '/login.php', 1615066312);
INSERT INTO `stats_views` VALUES(965, 312, '/signup.php', 1615066321);
INSERT INTO `stats_views` VALUES(966, 306, '/index.php', 1615066432);
INSERT INTO `stats_views` VALUES(967, 306, '/signup.php', 1615066441);
INSERT INTO `stats_views` VALUES(968, 313, '/signup.php', 1615066578);
INSERT INTO `stats_views` VALUES(969, 313, '/login.php', 1615066581);
INSERT INTO `stats_views` VALUES(970, 313, '/login.php', 1615066620);
INSERT INTO `stats_views` VALUES(971, 311, '/login.php', 1615066699);
INSERT INTO `stats_views` VALUES(972, 314, '/signup.php', 1615066719);
INSERT INTO `stats_views` VALUES(973, 311, '/index.php', 1615066727);
INSERT INTO `stats_views` VALUES(974, 306, '/index.php', 1615066971);
INSERT INTO `stats_views` VALUES(975, 311, '/signup.php', 1615066979);
INSERT INTO `stats_views` VALUES(976, 311, '/signup.php', 1615067153);
INSERT INTO `stats_views` VALUES(977, 311, '/login.php', 1615067155);
INSERT INTO `stats_views` VALUES(978, 306, '/login.php', 1615067176);
INSERT INTO `stats_views` VALUES(979, 311, '/login.php', 1615067230);
INSERT INTO `stats_views` VALUES(980, 306, '/signup.php', 1615067232);
INSERT INTO `stats_views` VALUES(981, 306, '/index.php', 1615067233);
INSERT INTO `stats_views` VALUES(982, 315, '/index.php', 1615068089);
INSERT INTO `stats_views` VALUES(983, 316, '/index.php', 1615068119);
INSERT INTO `stats_views` VALUES(984, 317, '/index.php', 1615091028);
INSERT INTO `stats_views` VALUES(985, 318, '/index.php', 1615104684);
INSERT INTO `stats_views` VALUES(986, 318, '/signup.php', 1615104689);
INSERT INTO `stats_views` VALUES(987, 318, '/signup.php', 1615104863);
INSERT INTO `stats_views` VALUES(988, 318, '/signup.php', 1615104902);
INSERT INTO `stats_views` VALUES(989, 318, '/signup.php', 1615104981);
INSERT INTO `stats_views` VALUES(990, 318, '/signup.php', 1615105055);
INSERT INTO `stats_views` VALUES(991, 318, '/signup.php', 1615105084);
INSERT INTO `stats_views` VALUES(992, 319, '/index.php', 1615124794);
INSERT INTO `stats_views` VALUES(993, 320, '/signup.php', 1615124799);
INSERT INTO `stats_views` VALUES(994, 319, '/signup.php', 1615124854);
INSERT INTO `stats_views` VALUES(995, 321, '/signup.php', 1615124858);
INSERT INTO `stats_views` VALUES(996, 321, '/index.php', 1615124865);
INSERT INTO `stats_views` VALUES(997, 322, '/index.php', 1615192130);
INSERT INTO `stats_views` VALUES(998, 323, '/index.php', 1615200027);
INSERT INTO `stats_views` VALUES(999, 323, '/signup.php', 1615200037);
INSERT INTO `stats_views` VALUES(1000, 323, '/signup.php', 1615200168);
INSERT INTO `stats_views` VALUES(1001, 323, '/signup.php', 1615200356);
INSERT INTO `stats_views` VALUES(1002, 323, '/signup.php', 1615200526);
INSERT INTO `stats_views` VALUES(1003, 324, '/index.php', 1615200581);
INSERT INTO `stats_views` VALUES(1004, 324, '/signup.php', 1615200596);
INSERT INTO `stats_views` VALUES(1005, 323, '/index.php', 1615201283);
INSERT INTO `stats_views` VALUES(1006, 325, '/index.php', 1615201364);
INSERT INTO `stats_views` VALUES(1007, 324, '/index.php', 1615201370);
INSERT INTO `stats_views` VALUES(1008, 325, '/index.php', 1615201639);
INSERT INTO `stats_views` VALUES(1009, 323, '/index.php', 1615201648);
INSERT INTO `stats_views` VALUES(1010, 326, '/index.php', 1615204831);
INSERT INTO `stats_views` VALUES(1011, 326, '/index.php', 1615204853);
INSERT INTO `stats_views` VALUES(1012, 326, '/signup.php', 1615204864);
INSERT INTO `stats_views` VALUES(1013, 327, '/index.php', 1615205608);
INSERT INTO `stats_views` VALUES(1014, 328, '/login.php', 1615206079);
INSERT INTO `stats_views` VALUES(1015, 329, '/index.php', 1615206134);
INSERT INTO `stats_views` VALUES(1016, 329, '/signup.php', 1615206142);
INSERT INTO `stats_views` VALUES(1017, 330, '/signup.php', 1615206323);
INSERT INTO `stats_views` VALUES(1018, 331, '/index.php', 1615206399);
INSERT INTO `stats_views` VALUES(1019, 330, '/signup.php', 1615206434);
INSERT INTO `stats_views` VALUES(1020, 330, '/login.php', 1615206437);
INSERT INTO `stats_views` VALUES(1021, 332, '/login.php', 1615206467);
INSERT INTO `stats_views` VALUES(1022, 333, '/signup.php', 1615206712);
INSERT INTO `stats_views` VALUES(1023, 333, '/signup.php', 1615207242);
INSERT INTO `stats_views` VALUES(1024, 333, '/login.php', 1615207244);
INSERT INTO `stats_views` VALUES(1025, 333, '/login.php', 1615207262);
INSERT INTO `stats_views` VALUES(1026, 334, '/index.php', 1615207727);
INSERT INTO `stats_views` VALUES(1027, 333, '/login.php', 1615207834);
INSERT INTO `stats_views` VALUES(1028, 333, '/signup.php', 1615207836);
INSERT INTO `stats_views` VALUES(1029, 333, '/index.php', 1615207836);
INSERT INTO `stats_views` VALUES(1030, 333, '/index.php', 1615207866);
INSERT INTO `stats_views` VALUES(1031, 333, '/index.php', 1615207918);
INSERT INTO `stats_views` VALUES(1032, 333, '/signup.php', 1615207945);
INSERT INTO `stats_views` VALUES(1033, 333, '/index.php', 1615207954);
INSERT INTO `stats_views` VALUES(1034, 333, '/login.php', 1615207958);
INSERT INTO `stats_views` VALUES(1035, 333, '/login.php', 1615207977);
INSERT INTO `stats_views` VALUES(1036, 333, '/signup.php', 1615208075);
INSERT INTO `stats_views` VALUES(1037, 333, '/index.php', 1615208075);
INSERT INTO `stats_views` VALUES(1038, 333, '/index.php', 1615208076);
INSERT INTO `stats_views` VALUES(1039, 334, '/index.php', 1615208441);
INSERT INTO `stats_views` VALUES(1040, 335, '/signup.php', 1615208450);
INSERT INTO `stats_views` VALUES(1041, 336, '/index.php', 1615208586);
INSERT INTO `stats_views` VALUES(1042, 333, '/index.php', 1615208588);
INSERT INTO `stats_views` VALUES(1043, 333, '/signup.php', 1615208616);
INSERT INTO `stats_views` VALUES(1044, 333, '/index.php', 1615208642);
INSERT INTO `stats_views` VALUES(1045, 333, '/signup.php', 1615208647);
INSERT INTO `stats_views` VALUES(1046, 333, '/index.php', 1615208670);
INSERT INTO `stats_views` VALUES(1047, 333, '/signup.php', 1615208671);
INSERT INTO `stats_views` VALUES(1048, 333, '/index.php', 1615208679);
INSERT INTO `stats_views` VALUES(1049, 333, '/signup.php', 1615208684);
INSERT INTO `stats_views` VALUES(1050, 333, '/index.php', 1615208709);
INSERT INTO `stats_views` VALUES(1051, 333, '/login.php', 1615208716);
INSERT INTO `stats_views` VALUES(1052, 333, '/login.php', 1615208745);
INSERT INTO `stats_views` VALUES(1053, 335, '/signup.php', 1615208771);
INSERT INTO `stats_views` VALUES(1054, 335, '/signup.php', 1615208775);
INSERT INTO `stats_views` VALUES(1055, 331, '/index.php', 1615208827);
INSERT INTO `stats_views` VALUES(1056, 337, '/index.php', 1615208838);
INSERT INTO `stats_views` VALUES(1057, 331, '/signup.php', 1615208846);
INSERT INTO `stats_views` VALUES(1058, 335, '/signup.php', 1615208846);
INSERT INTO `stats_views` VALUES(1059, 335, '/signup.php', 1615209048);
INSERT INTO `stats_views` VALUES(1060, 337, '/signup.php', 1615209058);
INSERT INTO `stats_views` VALUES(1061, 337, '/signup.php', 1615209120);
INSERT INTO `stats_views` VALUES(1062, 337, '/login.php', 1615209123);
INSERT INTO `stats_views` VALUES(1063, 334, '/login.php', 1615209174);
INSERT INTO `stats_views` VALUES(1064, 331, '/index.php', 1615209215);
INSERT INTO `stats_views` VALUES(1065, 331, '/signup.php', 1615209223);
INSERT INTO `stats_views` VALUES(1066, 337, '/login.php', 1615209240);
INSERT INTO `stats_views` VALUES(1067, 337, '/signup.php', 1615209242);
INSERT INTO `stats_views` VALUES(1068, 334, '/index.php', 1615209245);
INSERT INTO `stats_views` VALUES(1069, 331, '/index.php', 1615209294);
INSERT INTO `stats_views` VALUES(1070, 331, '/login.php', 1615209310);
INSERT INTO `stats_views` VALUES(1071, 331, '/index.php', 1615210050);
INSERT INTO `stats_views` VALUES(1072, 331, '/signup.php', 1615210088);
INSERT INTO `stats_views` VALUES(1073, 338, '/index.php', 1615210534);
INSERT INTO `stats_views` VALUES(1074, 334, '/index.php', 1615210575);
INSERT INTO `stats_views` VALUES(1075, 335, '/index.php', 1615210728);
INSERT INTO `stats_views` VALUES(1076, 331, '/index.php', 1615210776);
INSERT INTO `stats_views` VALUES(1077, 331, '/signup.php', 1615210784);
INSERT INTO `stats_views` VALUES(1078, 331, '/index.php', 1615210792);
INSERT INTO `stats_views` VALUES(1079, 339, '/index.php', 1615211644);
INSERT INTO `stats_views` VALUES(1080, 339, '/login.php', 1615211652);
INSERT INTO `stats_views` VALUES(1081, 340, '/index.php', 1615211663);
INSERT INTO `stats_views` VALUES(1082, 339, '/index.php', 1615211670);
INSERT INTO `stats_views` VALUES(1083, 340, '/signup.php', 1615211682);
INSERT INTO `stats_views` VALUES(1084, 339, '/signup.php', 1615211696);
INSERT INTO `stats_views` VALUES(1085, 339, '/signup.php', 1615211879);
INSERT INTO `stats_views` VALUES(1086, 339, '/login.php', 1615211882);
INSERT INTO `stats_views` VALUES(1087, 339, '/login.php', 1615211902);
INSERT INTO `stats_views` VALUES(1088, 340, '/signup.php', 1615212025);
INSERT INTO `stats_views` VALUES(1089, 340, '/login.php', 1615212027);
INSERT INTO `stats_views` VALUES(1090, 340, '/signup.php', 1615212027);
INSERT INTO `stats_views` VALUES(1091, 340, '/signup.php', 1615212040);
INSERT INTO `stats_views` VALUES(1092, 340, '/signup.php', 1615212085);
INSERT INTO `stats_views` VALUES(1093, 341, '/signup.php', 1615212106);
INSERT INTO `stats_views` VALUES(1094, 339, '/index.php', 1615212193);
INSERT INTO `stats_views` VALUES(1095, 339, '/login.php', 1615212206);
INSERT INTO `stats_views` VALUES(1096, 339, '/login.php', 1615212210);
INSERT INTO `stats_views` VALUES(1097, 340, '/signup.php', 1615212244);
INSERT INTO `stats_views` VALUES(1098, 340, '/signup.php', 1615212282);
INSERT INTO `stats_views` VALUES(1099, 342, '/signup.php', 1615212452);
INSERT INTO `stats_views` VALUES(1100, 341, '/signup.php', 1615212464);
INSERT INTO `stats_views` VALUES(1101, 340, '/index.php', 1615212566);
INSERT INTO `stats_views` VALUES(1102, 343, '/index.php', 1615213581);
INSERT INTO `stats_views` VALUES(1103, 344, '/login.php', 1615213654);
INSERT INTO `stats_views` VALUES(1104, 343, '/login.php', 1615213684);
INSERT INTO `stats_views` VALUES(1105, 344, '/login.php', 1615213769);
INSERT INTO `stats_views` VALUES(1106, 341, '/index.php', 1615213772);
INSERT INTO `stats_views` VALUES(1107, 344, '/login.php', 1615213787);
INSERT INTO `stats_views` VALUES(1108, 343, '/login.php', 1615213824);
INSERT INTO `stats_views` VALUES(1109, 345, '/index.php', 1615213827);
INSERT INTO `stats_views` VALUES(1110, 344, '/login.php', 1615213846);
INSERT INTO `stats_views` VALUES(1111, 344, '/index.php', 1615213846);
INSERT INTO `stats_views` VALUES(1112, 343, '/index.php', 1615213931);
INSERT INTO `stats_views` VALUES(1113, 344, '/login.php', 1615213942);
INSERT INTO `stats_views` VALUES(1114, 344, '/login.php', 1615213943);
INSERT INTO `stats_views` VALUES(1115, 344, '/login.php', 1615213943);
INSERT INTO `stats_views` VALUES(1116, 341, '/login.php', 1615213975);
INSERT INTO `stats_views` VALUES(1117, 344, '/login.php', 1615213986);
INSERT INTO `stats_views` VALUES(1118, 346, '/index.php', 1615214088);
INSERT INTO `stats_views` VALUES(1119, 343, '/index.php', 1615214097);
INSERT INTO `stats_views` VALUES(1120, 341, '/index.php', 1615214109);
INSERT INTO `stats_views` VALUES(1121, 341, '/signup.php', 1615214123);
INSERT INTO `stats_views` VALUES(1122, 343, '/signup.php', 1615214430);
INSERT INTO `stats_views` VALUES(1123, 343, '/login.php', 1615214432);
INSERT INTO `stats_views` VALUES(1124, 343, '/login.php', 1615214486);
INSERT INTO `stats_views` VALUES(1125, 347, '/index.php', 1615215724);
INSERT INTO `stats_views` VALUES(1126, 348, '/index.php', 1615218036);
INSERT INTO `stats_views` VALUES(1127, 348, '/index.php', 1615218080);
INSERT INTO `stats_views` VALUES(1128, 348, '/signup.php', 1615218130);
INSERT INTO `stats_views` VALUES(1129, 348, '/signup.php', 1615218414);
INSERT INTO `stats_views` VALUES(1130, 348, '/signup.php', 1615218508);
INSERT INTO `stats_views` VALUES(1131, 348, '/login.php', 1615218510);
INSERT INTO `stats_views` VALUES(1132, 348, '/login.php', 1615218519);
INSERT INTO `stats_views` VALUES(1133, 348, '/index.php', 1615218605);
INSERT INTO `stats_views` VALUES(1134, 348, '/signup.php', 1615218609);
INSERT INTO `stats_views` VALUES(1135, 348, '/signup.php', 1615218754);
INSERT INTO `stats_views` VALUES(1136, 348, '/signup.php', 1615218754);
INSERT INTO `stats_views` VALUES(1137, 335, '/index.php', 1615218832);
INSERT INTO `stats_views` VALUES(1138, 348, '/signup.php', 1615218837);
INSERT INTO `stats_views` VALUES(1139, 348, '/signup.php', 1615218868);
INSERT INTO `stats_views` VALUES(1140, 348, '/signup.php', 1615219053);
INSERT INTO `stats_views` VALUES(1141, 348, '/signup.php', 1615219054);
INSERT INTO `stats_views` VALUES(1142, 348, '/signup.php', 1615219241);
INSERT INTO `stats_views` VALUES(1143, 348, '/signup.php', 1615219276);
INSERT INTO `stats_views` VALUES(1144, 348, '/login.php', 1615219279);
INSERT INTO `stats_views` VALUES(1145, 348, '/login.php', 1615219286);
INSERT INTO `stats_views` VALUES(1146, 349, '/index.php', 1615220243);
INSERT INTO `stats_views` VALUES(1147, 350, '/index.php', 1615224861);
INSERT INTO `stats_views` VALUES(1148, 351, '/index.php', 1615224998);
INSERT INTO `stats_views` VALUES(1149, 351, '/signup.php', 1615225003);
INSERT INTO `stats_views` VALUES(1150, 352, '/index.php', 1615244470);
INSERT INTO `stats_views` VALUES(1151, 353, '/index.php', 1615249231);
INSERT INTO `stats_views` VALUES(1152, 354, '/index.php', 1615281634);
INSERT INTO `stats_views` VALUES(1153, 355, '/index.php', 1615282089);
INSERT INTO `stats_views` VALUES(1154, 356, '/login.php', 1615282142);
INSERT INTO `stats_views` VALUES(1155, 356, '/index.php', 1615282166);
INSERT INTO `stats_views` VALUES(1156, 355, '/signup.php', 1615282200);
INSERT INTO `stats_views` VALUES(1157, 356, '/index.php', 1615282249);
INSERT INTO `stats_views` VALUES(1158, 357, '/index.php', 1615282397);
INSERT INTO `stats_views` VALUES(1159, 356, '/index.php', 1615282415);
INSERT INTO `stats_views` VALUES(1160, 356, '/signup.php', 1615282426);
INSERT INTO `stats_views` VALUES(1161, 358, '/signup.php', 1615282673);
INSERT INTO `stats_views` VALUES(1162, 356, '/signup.php', 1615282727);
INSERT INTO `stats_views` VALUES(1163, 356, '/signup.php', 1615282753);
INSERT INTO `stats_views` VALUES(1164, 356, '/signup.php', 1615282815);
INSERT INTO `stats_views` VALUES(1165, 356, '/login.php', 1615282817);
INSERT INTO `stats_views` VALUES(1166, 355, '/login.php', 1615282873);
INSERT INTO `stats_views` VALUES(1167, 356, '/login.php', 1615283132);
INSERT INTO `stats_views` VALUES(1168, 355, '/signup.php', 1615283135);
INSERT INTO `stats_views` VALUES(1169, 355, '/index.php', 1615283137);
INSERT INTO `stats_views` VALUES(1170, 356, '/index.php', 1615283230);
INSERT INTO `stats_views` VALUES(1171, 356, '/login.php', 1615283328);
INSERT INTO `stats_views` VALUES(1172, 356, '/login.php', 1615283338);
INSERT INTO `stats_views` VALUES(1173, 355, '/login.php', 1615283352);
INSERT INTO `stats_views` VALUES(1174, 355, '/login.php', 1615283391);
INSERT INTO `stats_views` VALUES(1175, 356, '/login.php', 1615283417);
INSERT INTO `stats_views` VALUES(1176, 355, '/index.php', 1615283420);
INSERT INTO `stats_views` VALUES(1177, 358, '/signup.php', 1615283428);
INSERT INTO `stats_views` VALUES(1178, 356, '/index.php', 1615283439);
INSERT INTO `stats_views` VALUES(1179, 355, '/signup.php', 1615283451);
INSERT INTO `stats_views` VALUES(1180, 358, '/index.php', 1615283455);
INSERT INTO `stats_views` VALUES(1181, 355, '/index.php', 1615283546);
INSERT INTO `stats_views` VALUES(1182, 356, '/login.php', 1615283555);
INSERT INTO `stats_views` VALUES(1183, 358, '/login.php', 1615283592);
INSERT INTO `stats_views` VALUES(1184, 356, '/login.php', 1615283710);
INSERT INTO `stats_views` VALUES(1185, 356, '/index.php', 1615283715);
INSERT INTO `stats_views` VALUES(1186, 358, '/signup.php', 1615283734);
INSERT INTO `stats_views` VALUES(1187, 359, '/index.php', 1615283865);
INSERT INTO `stats_views` VALUES(1188, 360, '/signup.php', 1615283932);
INSERT INTO `stats_views` VALUES(1189, 361, '/index.php', 1615283956);
INSERT INTO `stats_views` VALUES(1190, 361, '/signup.php', 1615284001);
INSERT INTO `stats_views` VALUES(1191, 357, '/index.php', 1615284095);
INSERT INTO `stats_views` VALUES(1192, 362, '/signup.php', 1615284165);
INSERT INTO `stats_views` VALUES(1193, 361, '/signup.php', 1615284166);
INSERT INTO `stats_views` VALUES(1194, 362, '/login.php', 1615284167);
INSERT INTO `stats_views` VALUES(1195, 356, '/index.php', 1615284175);
INSERT INTO `stats_views` VALUES(1196, 360, '/login.php', 1615284205);
INSERT INTO `stats_views` VALUES(1197, 355, '/index.php', 1615284205);
INSERT INTO `stats_views` VALUES(1198, 361, '/signup.php', 1615284215);
INSERT INTO `stats_views` VALUES(1199, 361, '/login.php', 1615284218);
INSERT INTO `stats_views` VALUES(1200, 361, '/login.php', 1615284251);
INSERT INTO `stats_views` VALUES(1201, 361, '/login.php', 1615284329);
INSERT INTO `stats_views` VALUES(1202, 363, '/login.php', 1615284359);
INSERT INTO `stats_views` VALUES(1203, 361, '/index.php', 1615284373);
INSERT INTO `stats_views` VALUES(1204, 364, '/login.php', 1615284377);
INSERT INTO `stats_views` VALUES(1205, 355, '/index.php', 1615284484);
INSERT INTO `stats_views` VALUES(1206, 358, '/login.php', 1615284492);
INSERT INTO `stats_views` VALUES(1207, 356, '/login.php', 1615284498);
INSERT INTO `stats_views` VALUES(1208, 358, '/index.php', 1615284669);
INSERT INTO `stats_views` VALUES(1209, 355, '/index.php', 1615284674);
INSERT INTO `stats_views` VALUES(1210, 355, '/login.php', 1615284674);
INSERT INTO `stats_views` VALUES(1211, 360, '/login.php', 1615284676);
INSERT INTO `stats_views` VALUES(1212, 358, '/index.php', 1615284693);
INSERT INTO `stats_views` VALUES(1213, 365, '/login.php', 1615284703);
INSERT INTO `stats_views` VALUES(1214, 358, '/index.php', 1615284703);
INSERT INTO `stats_views` VALUES(1215, 356, '/signup.php', 1615284718);
INSERT INTO `stats_views` VALUES(1216, 366, '/index.php', 1615284878);
INSERT INTO `stats_views` VALUES(1217, 361, '/index.php', 1615284911);
INSERT INTO `stats_views` VALUES(1218, 361, '/signup.php', 1615284932);
INSERT INTO `stats_views` VALUES(1219, 357, '/index.php', 1615285053);
INSERT INTO `stats_views` VALUES(1220, 360, '/index.php', 1615285085);
INSERT INTO `stats_views` VALUES(1221, 360, '/signup.php', 1615285097);
INSERT INTO `stats_views` VALUES(1222, 367, '/index.php', 1615285133);
INSERT INTO `stats_views` VALUES(1223, 358, '/signup.php', 1615285163);
INSERT INTO `stats_views` VALUES(1224, 358, '/login.php', 1615285165);
INSERT INTO `stats_views` VALUES(1225, 355, '/login.php', 1615285224);
INSERT INTO `stats_views` VALUES(1226, 355, '/login.php', 1615285499);
INSERT INTO `stats_views` VALUES(1227, 358, '/signup.php', 1615285550);
INSERT INTO `stats_views` VALUES(1228, 358, '/signup.php', 1615285626);
INSERT INTO `stats_views` VALUES(1229, 355, '/signup.php', 1615285682);
INSERT INTO `stats_views` VALUES(1230, 355, '/signup.php', 1615285744);
INSERT INTO `stats_views` VALUES(1231, 358, '/signup.php', 1615285757);
INSERT INTO `stats_views` VALUES(1232, 355, '/index.php', 1615285760);
INSERT INTO `stats_views` VALUES(1233, 358, '/index.php', 1615285792);
INSERT INTO `stats_views` VALUES(1234, 355, '/signup.php', 1615285800);
INSERT INTO `stats_views` VALUES(1235, 368, '/signup.php', 1615286186);
INSERT INTO `stats_views` VALUES(1236, 369, '/index.php', 1615286208);
INSERT INTO `stats_views` VALUES(1237, 369, '/index.php', 1615286242);
INSERT INTO `stats_views` VALUES(1238, 369, '/login.php', 1615286252);
INSERT INTO `stats_views` VALUES(1239, 369, '/index.php', 1615286255);
INSERT INTO `stats_views` VALUES(1240, 355, '/signup.php', 1615286278);
INSERT INTO `stats_views` VALUES(1241, 368, '/signup.php', 1615286342);
INSERT INTO `stats_views` VALUES(1242, 368, '/login.php', 1615286344);
INSERT INTO `stats_views` VALUES(1243, 368, '/login.php', 1615286357);
INSERT INTO `stats_views` VALUES(1244, 370, '/index.php', 1615286487);
INSERT INTO `stats_views` VALUES(1245, 368, '/login.php', 1615286640);
INSERT INTO `stats_views` VALUES(1246, 355, '/signup.php', 1615286670);
INSERT INTO `stats_views` VALUES(1247, 358, '/index.php', 1615286723);
INSERT INTO `stats_views` VALUES(1248, 368, '/index.php', 1615286732);
INSERT INTO `stats_views` VALUES(1249, 368, '/signup.php', 1615286742);
INSERT INTO `stats_views` VALUES(1250, 355, '/signup.php', 1615287246);
INSERT INTO `stats_views` VALUES(1251, 355, '/login.php', 1615287248);
INSERT INTO `stats_views` VALUES(1252, 358, '/login.php', 1615287440);
INSERT INTO `stats_views` VALUES(1253, 371, '/index.php', 1615287519);
INSERT INTO `stats_views` VALUES(1254, 371, '/index.php', 1615287571);
INSERT INTO `stats_views` VALUES(1255, 358, '/login.php', 1615287600);
INSERT INTO `stats_views` VALUES(1256, 371, '/index.php', 1615287603);
INSERT INTO `stats_views` VALUES(1257, 368, '/login.php', 1615287634);
INSERT INTO `stats_views` VALUES(1258, 371, '/index.php', 1615287639);
INSERT INTO `stats_views` VALUES(1259, 371, '/login.php', 1615287641);
INSERT INTO `stats_views` VALUES(1260, 371, '/index.php', 1615287645);
INSERT INTO `stats_views` VALUES(1261, 368, '/login.php', 1615287842);
INSERT INTO `stats_views` VALUES(1262, 368, '/signup.php', 1615287842);
INSERT INTO `stats_views` VALUES(1263, 368, '/index.php', 1615287843);
INSERT INTO `stats_views` VALUES(1264, 372, '/index.php', 1615287916);
INSERT INTO `stats_views` VALUES(1265, 372, '/login.php', 1615287929);
INSERT INTO `stats_views` VALUES(1266, 372, '/index.php', 1615287932);
INSERT INTO `stats_views` VALUES(1267, 373, '/index.php', 1615288142);
INSERT INTO `stats_views` VALUES(1268, 355, '/index.php', 1615289325);
INSERT INTO `stats_views` VALUES(1269, 355, '/index.php', 1615289329);
INSERT INTO `stats_views` VALUES(1270, 358, '/signup.php', 1615289348);
INSERT INTO `stats_views` VALUES(1271, 368, '/index.php', 1615289353);
INSERT INTO `stats_views` VALUES(1272, 358, '/index.php', 1615289357);
INSERT INTO `stats_views` VALUES(1273, 358, '/signup.php', 1615289362);
INSERT INTO `stats_views` VALUES(1274, 355, '/index.php', 1615289367);
INSERT INTO `stats_views` VALUES(1275, 366, '/index.php', 1615290566);
INSERT INTO `stats_views` VALUES(1276, 374, '/index.php', 1615290579);
INSERT INTO `stats_views` VALUES(1277, 375, '/index.php', 1615290597);
INSERT INTO `stats_views` VALUES(1278, 374, '/signup.php', 1615290605);
INSERT INTO `stats_views` VALUES(1279, 375, '/signup.php', 1615290744);
INSERT INTO `stats_views` VALUES(1280, 375, '/signup.php', 1615290746);
INSERT INTO `stats_views` VALUES(1281, 374, '/index.php', 1615290983);
INSERT INTO `stats_views` VALUES(1282, 374, '/signup.php', 1615290984);
INSERT INTO `stats_views` VALUES(1283, 376, '/login.php', 1615290990);
INSERT INTO `stats_views` VALUES(1284, 374, '/login.php', 1615291020);
INSERT INTO `stats_views` VALUES(1285, 374, '/login.php', 1615291059);
INSERT INTO `stats_views` VALUES(1286, 376, '/login.php', 1615291064);
INSERT INTO `stats_views` VALUES(1287, 374, '/login.php', 1615291077);
INSERT INTO `stats_views` VALUES(1288, 374, '/index.php', 1615291081);
INSERT INTO `stats_views` VALUES(1289, 376, '/index.php', 1615291207);
INSERT INTO `stats_views` VALUES(1290, 374, '/login.php', 1615291217);
INSERT INTO `stats_views` VALUES(1291, 375, '/login.php', 1615291238);
INSERT INTO `stats_views` VALUES(1292, 376, '/index.php', 1615291260);
INSERT INTO `stats_views` VALUES(1293, 375, '/signup.php', 1615291264);
INSERT INTO `stats_views` VALUES(1294, 374, '/signup.php', 1615291390);
INSERT INTO `stats_views` VALUES(1295, 376, '/signup.php', 1615291412);
INSERT INTO `stats_views` VALUES(1296, 374, '/signup.php', 1615291452);
INSERT INTO `stats_views` VALUES(1297, 375, '/signup.php', 1615291463);
INSERT INTO `stats_views` VALUES(1298, 376, '/signup.php', 1615291483);
INSERT INTO `stats_views` VALUES(1299, 377, '/index.php', 1615291529);
INSERT INTO `stats_views` VALUES(1300, 375, '/signup.php', 1615291532);
INSERT INTO `stats_views` VALUES(1301, 376, '/signup.php', 1615291612);
INSERT INTO `stats_views` VALUES(1302, 376, '/login.php', 1615291615);
INSERT INTO `stats_views` VALUES(1303, 375, '/login.php', 1615291656);
INSERT INTO `stats_views` VALUES(1304, 376, '/login.php', 1615291672);
INSERT INTO `stats_views` VALUES(1305, 377, '/signup.php', 1615291686);
INSERT INTO `stats_views` VALUES(1306, 376, '/login.php', 1615291686);
INSERT INTO `stats_views` VALUES(1307, 377, '/index.php', 1615291797);
INSERT INTO `stats_views` VALUES(1308, 378, '/index.php', 1615291811);
INSERT INTO `stats_views` VALUES(1309, 379, '/index.php', 1615291852);
INSERT INTO `stats_views` VALUES(1310, 380, '/index.php', 1615291866);
INSERT INTO `stats_views` VALUES(1311, 380, '/login.php', 1615291871);
INSERT INTO `stats_views` VALUES(1312, 379, '/login.php', 1615291913);
INSERT INTO `stats_views` VALUES(1313, 380, '/index.php', 1615291924);
INSERT INTO `stats_views` VALUES(1314, 381, '/signup.php', 1615291933);
INSERT INTO `stats_views` VALUES(1315, 377, '/index.php', 1615291961);
INSERT INTO `stats_views` VALUES(1316, 377, '/signup.php', 1615291979);
INSERT INTO `stats_views` VALUES(1317, 382, '/index.php', 1615292083);
INSERT INTO `stats_views` VALUES(1318, 379, '/signup.php', 1615292149);
INSERT INTO `stats_views` VALUES(1319, 379, '/login.php', 1615292151);
INSERT INTO `stats_views` VALUES(1320, 380, '/login.php', 1615292205);
INSERT INTO `stats_views` VALUES(1321, 380, '/index.php', 1615292206);
INSERT INTO `stats_views` VALUES(1322, 380, '/login.php', 1615292215);
INSERT INTO `stats_views` VALUES(1323, 380, '/login.php', 1615292218);
INSERT INTO `stats_views` VALUES(1324, 380, '/index.php', 1615292218);
INSERT INTO `stats_views` VALUES(1325, 380, '/login.php', 1615292226);
INSERT INTO `stats_views` VALUES(1326, 380, '/login.php', 1615292236);
INSERT INTO `stats_views` VALUES(1327, 380, '/index.php', 1615292236);
INSERT INTO `stats_views` VALUES(1328, 379, '/login.php', 1615292238);
INSERT INTO `stats_views` VALUES(1329, 380, '/login.php', 1615292244);
INSERT INTO `stats_views` VALUES(1330, 379, '/login.php', 1615292252);
INSERT INTO `stats_views` VALUES(1331, 381, '/login.php', 1615292261);
INSERT INTO `stats_views` VALUES(1332, 381, '/index.php', 1615292262);
INSERT INTO `stats_views` VALUES(1333, 380, '/login.php', 1615292283);
INSERT INTO `stats_views` VALUES(1334, 377, '/signup.php', 1615292309);
INSERT INTO `stats_views` VALUES(1335, 377, '/login.php', 1615292311);
INSERT INTO `stats_views` VALUES(1336, 377, '/login.php', 1615292336);
INSERT INTO `stats_views` VALUES(1337, 381, '/login.php', 1615292341);
INSERT INTO `stats_views` VALUES(1338, 381, '/login.php', 1615292366);
INSERT INTO `stats_views` VALUES(1339, 381, '/index.php', 1615292367);
INSERT INTO `stats_views` VALUES(1340, 383, '/login.php', 1615292367);
INSERT INTO `stats_views` VALUES(1341, 381, '/login.php', 1615292388);
INSERT INTO `stats_views` VALUES(1342, 381, '/login.php', 1615292411);
INSERT INTO `stats_views` VALUES(1343, 380, '/login.php', 1615292413);
INSERT INTO `stats_views` VALUES(1344, 383, '/login.php', 1615292414);
INSERT INTO `stats_views` VALUES(1345, 383, '/index.php', 1615292414);
INSERT INTO `stats_views` VALUES(1346, 380, '/login.php', 1615292428);
INSERT INTO `stats_views` VALUES(1347, 383, '/signup.php', 1615292435);
INSERT INTO `stats_views` VALUES(1348, 381, '/index.php', 1615292452);
INSERT INTO `stats_views` VALUES(1349, 380, '/login.php', 1615292461);
INSERT INTO `stats_views` VALUES(1350, 380, '/index.php', 1615292464);
INSERT INTO `stats_views` VALUES(1351, 383, '/login.php', 1615292465);
INSERT INTO `stats_views` VALUES(1352, 383, '/index.php', 1615292466);
INSERT INTO `stats_views` VALUES(1353, 380, '/signup.php', 1615292466);
INSERT INTO `stats_views` VALUES(1354, 383, '/login.php', 1615292467);
INSERT INTO `stats_views` VALUES(1355, 383, '/signup.php', 1615292467);
INSERT INTO `stats_views` VALUES(1356, 383, '/index.php', 1615292467);
INSERT INTO `stats_views` VALUES(1357, 383, '/signup.php', 1615292467);
INSERT INTO `stats_views` VALUES(1358, 381, '/index.php', 1615292620);
INSERT INTO `stats_views` VALUES(1359, 383, '/login.php', 1615292625);
INSERT INTO `stats_views` VALUES(1360, 381, '/login.php', 1615292626);
INSERT INTO `stats_views` VALUES(1361, 381, '/index.php', 1615292628);
INSERT INTO `stats_views` VALUES(1362, 381, '/index.php', 1615292634);
INSERT INTO `stats_views` VALUES(1363, 383, '/index.php', 1615292649);
INSERT INTO `stats_views` VALUES(1364, 380, '/signup.php', 1615292654);
INSERT INTO `stats_views` VALUES(1365, 380, '/signup.php', 1615292817);
INSERT INTO `stats_views` VALUES(1366, 377, '/login.php', 1615292850);
INSERT INTO `stats_views` VALUES(1367, 377, '/signup.php', 1615292854);
INSERT INTO `stats_views` VALUES(1368, 377, '/index.php', 1615292854);
INSERT INTO `stats_views` VALUES(1369, 377, '/login.php', 1615292870);
INSERT INTO `stats_views` VALUES(1370, 377, '/login.php', 1615292875);
INSERT INTO `stats_views` VALUES(1371, 380, '/signup.php', 1615292878);
INSERT INTO `stats_views` VALUES(1372, 380, '/index.php', 1615292915);
INSERT INTO `stats_views` VALUES(1373, 380, '/signup.php', 1615292921);
INSERT INTO `stats_views` VALUES(1374, 381, '/signup.php', 1615292958);
INSERT INTO `stats_views` VALUES(1375, 383, '/index.php', 1615292987);
INSERT INTO `stats_views` VALUES(1376, 380, '/signup.php', 1615293010);
INSERT INTO `stats_views` VALUES(1377, 380, '/index.php', 1615293010);
INSERT INTO `stats_views` VALUES(1378, 381, '/login.php', 1615293021);
INSERT INTO `stats_views` VALUES(1379, 383, '/index.php', 1615293035);
INSERT INTO `stats_views` VALUES(1380, 380, '/login.php', 1615293035);
INSERT INTO `stats_views` VALUES(1381, 380, '/signup.php', 1615293041);
INSERT INTO `stats_views` VALUES(1382, 383, '/signup.php', 1615293262);
INSERT INTO `stats_views` VALUES(1383, 383, '/login.php', 1615293265);
INSERT INTO `stats_views` VALUES(1384, 381, '/signup.php', 1615293265);
INSERT INTO `stats_views` VALUES(1385, 381, '/login.php', 1615293304);
INSERT INTO `stats_views` VALUES(1386, 381, '/index.php', 1615293305);
INSERT INTO `stats_views` VALUES(1387, 383, '/signup.php', 1615293305);
INSERT INTO `stats_views` VALUES(1388, 383, '/login.php', 1615293350);
INSERT INTO `stats_views` VALUES(1389, 381, '/login.php', 1615293367);
INSERT INTO `stats_views` VALUES(1390, 381, '/index.php', 1615293368);
INSERT INTO `stats_views` VALUES(1391, 381, '/signup.php', 1615293397);
INSERT INTO `stats_views` VALUES(1392, 380, '/login.php', 1615293398);
INSERT INTO `stats_views` VALUES(1393, 380, '/index.php', 1615293402);
INSERT INTO `stats_views` VALUES(1394, 383, '/signup.php', 1615293403);
INSERT INTO `stats_views` VALUES(1395, 377, '/index.php', 1615293462);
INSERT INTO `stats_views` VALUES(1396, 372, '/login.php', 1615293478);
INSERT INTO `stats_views` VALUES(1397, 372, '/login.php', 1615293486);
INSERT INTO `stats_views` VALUES(1398, 371, '/index.php', 1615293505);
INSERT INTO `stats_views` VALUES(1399, 371, '/index.php', 1615293505);
INSERT INTO `stats_views` VALUES(1400, 371, '/signup.php', 1615293515);
INSERT INTO `stats_views` VALUES(1401, 381, '/index.php', 1615293652);
INSERT INTO `stats_views` VALUES(1402, 381, '/index.php', 1615293652);
INSERT INTO `stats_views` VALUES(1403, 384, '/index.php', 1615293663);
INSERT INTO `stats_views` VALUES(1404, 381, '/index.php', 1615293700);
INSERT INTO `stats_views` VALUES(1405, 371, '/index.php', 1615293714);
INSERT INTO `stats_views` VALUES(1406, 381, '/index.php', 1615293716);
INSERT INTO `stats_views` VALUES(1407, 381, '/signup.php', 1615293724);
INSERT INTO `stats_views` VALUES(1408, 371, '/signup.php', 1615293730);
INSERT INTO `stats_views` VALUES(1409, 371, '/signup.php', 1615293742);
INSERT INTO `stats_views` VALUES(1410, 371, '/signup.php', 1615293744);
INSERT INTO `stats_views` VALUES(1411, 380, '/signup.php', 1615293932);
INSERT INTO `stats_views` VALUES(1412, 380, '/login.php', 1615293934);
INSERT INTO `stats_views` VALUES(1413, 385, '/login.php', 1615293969);
INSERT INTO `stats_views` VALUES(1414, 381, '/signup.php', 1615293969);
INSERT INTO `stats_views` VALUES(1415, 381, '/login.php', 1615293995);
INSERT INTO `stats_views` VALUES(1416, 381, '/index.php', 1615293996);
INSERT INTO `stats_views` VALUES(1417, 371, '/index.php', 1615294016);
INSERT INTO `stats_views` VALUES(1418, 381, '/login.php', 1615294054);
INSERT INTO `stats_views` VALUES(1419, 386, '/signup.php', 1615294055);
INSERT INTO `stats_views` VALUES(1420, 386, '/login.php', 1615294103);
INSERT INTO `stats_views` VALUES(1421, 381, '/login.php', 1615294127);
INSERT INTO `stats_views` VALUES(1422, 380, '/signup.php', 1615294128);
INSERT INTO `stats_views` VALUES(1423, 371, '/index.php', 1615294140);
INSERT INTO `stats_views` VALUES(1424, 371, '/signup.php', 1615294159);
INSERT INTO `stats_views` VALUES(1425, 371, '/signup.php', 1615294218);
INSERT INTO `stats_views` VALUES(1426, 371, '/login.php', 1615294220);
INSERT INTO `stats_views` VALUES(1427, 371, '/login.php', 1615294231);
INSERT INTO `stats_views` VALUES(1428, 384, '/index.php', 1615294905);
INSERT INTO `stats_views` VALUES(1429, 387, '/index.php', 1615294971);
INSERT INTO `stats_views` VALUES(1430, 388, '/index.php', 1615296178);
INSERT INTO `stats_views` VALUES(1431, 388, '/signup.php', 1615296187);
INSERT INTO `stats_views` VALUES(1432, 389, '/index.php', 1615297543);
INSERT INTO `stats_views` VALUES(1433, 389, '/signup.php', 1615297552);
INSERT INTO `stats_views` VALUES(1434, 390, '/index.php', 1615297641);
INSERT INTO `stats_views` VALUES(1435, 390, '/login.php', 1615297647);
INSERT INTO `stats_views` VALUES(1436, 391, '/login.php', 1615297660);
INSERT INTO `stats_views` VALUES(1437, 389, '/signup.php', 1615297841);
INSERT INTO `stats_views` VALUES(1438, 389, '/login.php', 1615297843);
INSERT INTO `stats_views` VALUES(1439, 392, '/login.php', 1615297895);
INSERT INTO `stats_views` VALUES(1440, 393, '/login.php', 1615297984);
INSERT INTO `stats_views` VALUES(1441, 389, '/signup.php', 1615297987);
INSERT INTO `stats_views` VALUES(1442, 393, '/index.php', 1615298022);
INSERT INTO `stats_views` VALUES(1443, 389, '/signup.php', 1615298026);
INSERT INTO `stats_views` VALUES(1444, 392, '/signup.php', 1615298225);
INSERT INTO `stats_views` VALUES(1445, 392, '/login.php', 1615298227);
INSERT INTO `stats_views` VALUES(1446, 389, '/login.php', 1615298257);
INSERT INTO `stats_views` VALUES(1447, 392, '/login.php', 1615298273);
INSERT INTO `stats_views` VALUES(1448, 389, '/signup.php', 1615298277);
INSERT INTO `stats_views` VALUES(1449, 389, '/index.php', 1615298281);
INSERT INTO `stats_views` VALUES(1450, 389, '/login.php', 1615298285);
INSERT INTO `stats_views` VALUES(1451, 389, '/login.php', 1615298306);
INSERT INTO `stats_views` VALUES(1452, 393, '/index.php', 1615298796);
INSERT INTO `stats_views` VALUES(1453, 389, '/login.php', 1615298801);
INSERT INTO `stats_views` VALUES(1454, 393, '/login.php', 1615298821);
INSERT INTO `stats_views` VALUES(1455, 393, '/login.php', 1615298892);
INSERT INTO `stats_views` VALUES(1456, 393, '/index.php', 1615298957);
INSERT INTO `stats_views` VALUES(1457, 394, '/index.php', 1615299820);
INSERT INTO `stats_views` VALUES(1458, 394, '/signup.php', 1615299846);
INSERT INTO `stats_views` VALUES(1459, 395, '/index.php', 1615299957);
INSERT INTO `stats_views` VALUES(1460, 396, '/index.php', 1615299958);
INSERT INTO `stats_views` VALUES(1461, 396, '/signup.php', 1615299995);
INSERT INTO `stats_views` VALUES(1462, 394, '/signup.php', 1615300078);
INSERT INTO `stats_views` VALUES(1463, 394, '/signup.php', 1615300080);
INSERT INTO `stats_views` VALUES(1464, 394, '/signup.php', 1615300098);
INSERT INTO `stats_views` VALUES(1465, 394, '/signup.php', 1615300182);
INSERT INTO `stats_views` VALUES(1466, 394, '/index.php', 1615300206);
INSERT INTO `stats_views` VALUES(1467, 394, '/login.php', 1615300218);
INSERT INTO `stats_views` VALUES(1468, 394, '/login.php', 1615300254);
INSERT INTO `stats_views` VALUES(1469, 397, '/index.php', 1615300265);
INSERT INTO `stats_views` VALUES(1470, 397, '/login.php', 1615300341);
INSERT INTO `stats_views` VALUES(1471, 397, '/login.php', 1615300360);
INSERT INTO `stats_views` VALUES(1472, 397, '/login.php', 1615300372);
INSERT INTO `stats_views` VALUES(1473, 396, '/signup.php', 1615300392);
INSERT INTO `stats_views` VALUES(1474, 396, '/login.php', 1615300394);
INSERT INTO `stats_views` VALUES(1475, 396, '/login.php', 1615300416);
INSERT INTO `stats_views` VALUES(1476, 397, '/index.php', 1615300539);
INSERT INTO `stats_views` VALUES(1477, 394, '/index.php', 1615300699);
INSERT INTO `stats_views` VALUES(1478, 394, '/signup.php', 1615300715);
INSERT INTO `stats_views` VALUES(1479, 395, '/index.php', 1615300827);
INSERT INTO `stats_views` VALUES(1480, 396, '/index.php', 1615300828);
INSERT INTO `stats_views` VALUES(1481, 396, '/login.php', 1615300842);
INSERT INTO `stats_views` VALUES(1482, 396, '/index.php', 1615300852);
INSERT INTO `stats_views` VALUES(1483, 396, '/index.php', 1615300861);
INSERT INTO `stats_views` VALUES(1484, 396, '/login.php', 1615300865);
INSERT INTO `stats_views` VALUES(1485, 398, '/index.php', 1615300902);
INSERT INTO `stats_views` VALUES(1486, 396, '/login.php', 1615300935);
INSERT INTO `stats_views` VALUES(1487, 398, '/login.php', 1615300975);
INSERT INTO `stats_views` VALUES(1488, 394, '/signup.php', 1615300997);
INSERT INTO `stats_views` VALUES(1489, 396, '/login.php', 1615301000);
INSERT INTO `stats_views` VALUES(1490, 396, '/index.php', 1615301001);
INSERT INTO `stats_views` VALUES(1491, 396, '/index.php', 1615301001);
INSERT INTO `stats_views` VALUES(1492, 396, '/index.php', 1615301002);
INSERT INTO `stats_views` VALUES(1493, 396, '/index.php', 1615301002);
INSERT INTO `stats_views` VALUES(1494, 396, '/index.php', 1615301002);
INSERT INTO `stats_views` VALUES(1495, 396, '/index.php', 1615301003);
INSERT INTO `stats_views` VALUES(1496, 396, '/index.php', 1615301003);
INSERT INTO `stats_views` VALUES(1497, 396, '/index.php', 1615301003);
INSERT INTO `stats_views` VALUES(1498, 396, '/index.php', 1615301004);
INSERT INTO `stats_views` VALUES(1499, 396, '/index.php', 1615301004);
INSERT INTO `stats_views` VALUES(1500, 394, '/signup.php', 1615301022);
INSERT INTO `stats_views` VALUES(1501, 398, '/login.php', 1615301085);
INSERT INTO `stats_views` VALUES(1502, 394, '/signup.php', 1615301125);
INSERT INTO `stats_views` VALUES(1503, 394, '/signup.php', 1615301143);
INSERT INTO `stats_views` VALUES(1504, 399, '/index.php', 1615301220);
INSERT INTO `stats_views` VALUES(1505, 399, '/signup.php', 1615301259);
INSERT INTO `stats_views` VALUES(1506, 394, '/signup.php', 1615301286);
INSERT INTO `stats_views` VALUES(1507, 394, '/signup.php', 1615301290);
INSERT INTO `stats_views` VALUES(1508, 394, '/signup.php', 1615301304);
INSERT INTO `stats_views` VALUES(1509, 394, '/signup.php', 1615301365);
INSERT INTO `stats_views` VALUES(1510, 394, '/signup.php', 1615301389);
INSERT INTO `stats_views` VALUES(1511, 394, '/index.php', 1615301392);
INSERT INTO `stats_views` VALUES(1512, 394, '/login.php', 1615301399);
INSERT INTO `stats_views` VALUES(1513, 399, '/signup.php', 1615301418);
INSERT INTO `stats_views` VALUES(1514, 399, '/login.php', 1615301420);
INSERT INTO `stats_views` VALUES(1515, 394, '/login.php', 1615301432);
INSERT INTO `stats_views` VALUES(1516, 399, '/login.php', 1615301532);
INSERT INTO `stats_views` VALUES(1517, 399, '/login.php', 1615301560);
INSERT INTO `stats_views` VALUES(1518, 400, '/index.php', 1615301581);
INSERT INTO `stats_views` VALUES(1519, 396, '/index.php', 1615301582);
INSERT INTO `stats_views` VALUES(1520, 396, '/signup.php', 1615301610);
INSERT INTO `stats_views` VALUES(1521, 396, '/index.php', 1615301645);
INSERT INTO `stats_views` VALUES(1522, 396, '/login.php', 1615301651);
INSERT INTO `stats_views` VALUES(1523, 396, '/login.php', 1615301659);
INSERT INTO `stats_views` VALUES(1524, 396, '/login.php', 1615301686);
INSERT INTO `stats_views` VALUES(1525, 396, '/index.php', 1615301687);
INSERT INTO `stats_views` VALUES(1526, 396, '/signup.php', 1615301691);
INSERT INTO `stats_views` VALUES(1527, 396, '/index.php', 1615301691);
INSERT INTO `stats_views` VALUES(1528, 396, '/index.php', 1615301703);
INSERT INTO `stats_views` VALUES(1529, 396, '/signup.php', 1615301711);
INSERT INTO `stats_views` VALUES(1530, 396, '/signup.php', 1615301961);
INSERT INTO `stats_views` VALUES(1531, 396, '/signup.php', 1615301982);
INSERT INTO `stats_views` VALUES(1532, 396, '/index.php', 1615301993);
INSERT INTO `stats_views` VALUES(1533, 396, '/signup.php', 1615301999);
INSERT INTO `stats_views` VALUES(1534, 396, '/signup.php', 1615302003);
INSERT INTO `stats_views` VALUES(1535, 396, '/signup.php', 1615302005);
INSERT INTO `stats_views` VALUES(1536, 394, '/index.php', 1615302011);
INSERT INTO `stats_views` VALUES(1537, 394, '/login.php', 1615302011);
INSERT INTO `stats_views` VALUES(1538, 396, '/index.php', 1615302013);
INSERT INTO `stats_views` VALUES(1539, 396, '/signup.php', 1615302013);
INSERT INTO `stats_views` VALUES(1540, 396, '/index.php', 1615302013);
INSERT INTO `stats_views` VALUES(1541, 394, '/login.php', 1615302047);
INSERT INTO `stats_views` VALUES(1542, 396, '/index.php', 1615302052);
INSERT INTO `stats_views` VALUES(1543, 394, '/index.php', 1615302059);
INSERT INTO `stats_views` VALUES(1544, 396, '/signup.php', 1615302060);
INSERT INTO `stats_views` VALUES(1545, 394, '/signup.php', 1615302071);
INSERT INTO `stats_views` VALUES(1546, 394, '/signup.php', 1615302222);
INSERT INTO `stats_views` VALUES(1547, 396, '/signup.php', 1615302228);
INSERT INTO `stats_views` VALUES(1548, 396, '/index.php', 1615302242);
INSERT INTO `stats_views` VALUES(1549, 396, '/login.php', 1615302245);
INSERT INTO `stats_views` VALUES(1550, 396, '/index.php', 1615302248);
INSERT INTO `stats_views` VALUES(1551, 396, '/login.php', 1615302253);
INSERT INTO `stats_views` VALUES(1552, 394, '/signup.php', 1615302257);
INSERT INTO `stats_views` VALUES(1553, 394, '/index.php', 1615302269);
INSERT INTO `stats_views` VALUES(1554, 394, '/login.php', 1615302320);
INSERT INTO `stats_views` VALUES(1555, 396, '/login.php', 1615302354);
INSERT INTO `stats_views` VALUES(1556, 394, '/login.php', 1615302364);
INSERT INTO `stats_views` VALUES(1557, 396, '/index.php', 1615302370);
INSERT INTO `stats_views` VALUES(1558, 396, '/signup.php', 1615302374);
INSERT INTO `stats_views` VALUES(1559, 396, '/signup.php', 1615302378);
INSERT INTO `stats_views` VALUES(1560, 396, '/signup.php', 1615302380);
INSERT INTO `stats_views` VALUES(1561, 400, '/index.php', 1615302392);
INSERT INTO `stats_views` VALUES(1562, 396, '/index.php', 1615302393);
INSERT INTO `stats_views` VALUES(1563, 396, '/login.php', 1615302397);
INSERT INTO `stats_views` VALUES(1564, 396, '/index.php', 1615302401);
INSERT INTO `stats_views` VALUES(1565, 396, '/signup.php', 1615302406);
INSERT INTO `stats_views` VALUES(1566, 396, '/index.php', 1615302471);
INSERT INTO `stats_views` VALUES(1567, 396, '/login.php', 1615302495);
INSERT INTO `stats_views` VALUES(1568, 394, '/login.php', 1615302531);
INSERT INTO `stats_views` VALUES(1569, 394, '/index.php', 1615302531);
INSERT INTO `stats_views` VALUES(1570, 396, '/login.php', 1615302563);
INSERT INTO `stats_views` VALUES(1571, 394, '/index.php', 1615302813);
INSERT INTO `stats_views` VALUES(1572, 396, '/index.php', 1615302814);
INSERT INTO `stats_views` VALUES(1573, 396, '/signup.php', 1615302819);
INSERT INTO `stats_views` VALUES(1574, 394, '/signup.php', 1615302823);
INSERT INTO `stats_views` VALUES(1575, 394, '/signup.php', 1615303018);
INSERT INTO `stats_views` VALUES(1576, 394, '/signup.php', 1615303078);
INSERT INTO `stats_views` VALUES(1577, 394, '/signup.php', 1615303157);
INSERT INTO `stats_views` VALUES(1578, 394, '/index.php', 1615303161);
INSERT INTO `stats_views` VALUES(1579, 394, '/login.php', 1615303168);
INSERT INTO `stats_views` VALUES(1580, 394, '/login.php', 1615303198);
INSERT INTO `stats_views` VALUES(1581, 394, '/login.php', 1615303210);
INSERT INTO `stats_views` VALUES(1582, 394, '/index.php', 1615303211);
INSERT INTO `stats_views` VALUES(1583, 394, '/login.php', 1615303294);
INSERT INTO `stats_views` VALUES(1584, 394, '/login.php', 1615303314);
INSERT INTO `stats_views` VALUES(1585, 394, '/index.php', 1615303388);
INSERT INTO `stats_views` VALUES(1586, 401, '/index.php', 1615303448);
INSERT INTO `stats_views` VALUES(1587, 396, '/index.php', 1615303450);
INSERT INTO `stats_views` VALUES(1588, 396, '/signup.php', 1615303464);
INSERT INTO `stats_views` VALUES(1589, 396, '/index.php', 1615303717);
INSERT INTO `stats_views` VALUES(1590, 394, '/index.php', 1615303772);
INSERT INTO `stats_views` VALUES(1591, 394, '/login.php', 1615303782);
INSERT INTO `stats_views` VALUES(1592, 394, '/login.php', 1615303811);
INSERT INTO `stats_views` VALUES(1593, 401, '/index.php', 1615304086);
INSERT INTO `stats_views` VALUES(1594, 396, '/index.php', 1615304088);
INSERT INTO `stats_views` VALUES(1595, 396, '/signup.php', 1615304092);
INSERT INTO `stats_views` VALUES(1596, 394, '/login.php', 1615304139);
INSERT INTO `stats_views` VALUES(1597, 394, '/index.php', 1615304140);
INSERT INTO `stats_views` VALUES(1598, 396, '/signup.php', 1615304340);
INSERT INTO `stats_views` VALUES(1599, 396, '/index.php', 1615304367);
INSERT INTO `stats_views` VALUES(1600, 396, '/signup.php', 1615304398);
INSERT INTO `stats_views` VALUES(1601, 396, '/index.php', 1615304418);
INSERT INTO `stats_views` VALUES(1602, 396, '/login.php', 1615304422);
INSERT INTO `stats_views` VALUES(1603, 396, '/login.php', 1615304448);
INSERT INTO `stats_views` VALUES(1604, 396, '/index.php', 1615304459);
INSERT INTO `stats_views` VALUES(1605, 396, '/signup.php', 1615304464);
INSERT INTO `stats_views` VALUES(1606, 396, '/signup.php', 1615304794);
INSERT INTO `stats_views` VALUES(1607, 396, '/signup.php', 1615304815);
INSERT INTO `stats_views` VALUES(1608, 396, '/signup.php', 1615304836);
INSERT INTO `stats_views` VALUES(1609, 396, '/signup.php', 1615304844);
INSERT INTO `stats_views` VALUES(1610, 396, '/signup.php', 1615304891);
INSERT INTO `stats_views` VALUES(1611, 401, '/index.php', 1615304901);
INSERT INTO `stats_views` VALUES(1612, 396, '/index.php', 1615304902);
INSERT INTO `stats_views` VALUES(1613, 396, '/signup.php', 1615304912);
INSERT INTO `stats_views` VALUES(1614, 396, '/signup.php', 1615305103);
INSERT INTO `stats_views` VALUES(1615, 396, '/signup.php', 1615305126);
INSERT INTO `stats_views` VALUES(1616, 396, '/index.php', 1615305128);
INSERT INTO `stats_views` VALUES(1617, 396, '/login.php', 1615305132);
INSERT INTO `stats_views` VALUES(1618, 396, '/login.php', 1615305136);
INSERT INTO `stats_views` VALUES(1619, 394, '/index.php', 1615305148);
INSERT INTO `stats_views` VALUES(1620, 394, '/login.php', 1615305186);
INSERT INTO `stats_views` VALUES(1621, 394, '/index.php', 1615305191);
INSERT INTO `stats_views` VALUES(1622, 396, '/index.php', 1615305197);
INSERT INTO `stats_views` VALUES(1623, 396, '/signup.php', 1615305205);
INSERT INTO `stats_views` VALUES(1624, 394, '/login.php', 1615305234);
INSERT INTO `stats_views` VALUES(1625, 402, '/index.php', 1615305241);
INSERT INTO `stats_views` VALUES(1626, 394, '/index.php', 1615305245);
INSERT INTO `stats_views` VALUES(1627, 402, '/signup.php', 1615305256);
INSERT INTO `stats_views` VALUES(1628, 394, '/login.php', 1615305284);
INSERT INTO `stats_views` VALUES(1629, 394, '/index.php', 1615305298);
INSERT INTO `stats_views` VALUES(1630, 394, '/index.php', 1615305329);
INSERT INTO `stats_views` VALUES(1631, 394, '/signup.php', 1615305353);
INSERT INTO `stats_views` VALUES(1632, 402, '/signup.php', 1615305551);
INSERT INTO `stats_views` VALUES(1633, 394, '/signup.php', 1615305584);
INSERT INTO `stats_views` VALUES(1634, 394, '/login.php', 1615305591);
INSERT INTO `stats_views` VALUES(1635, 394, '/login.php', 1615305632);
INSERT INTO `stats_views` VALUES(1636, 394, '/login.php', 1615305638);
INSERT INTO `stats_views` VALUES(1637, 394, '/login.php', 1615305681);
INSERT INTO `stats_views` VALUES(1638, 388, '/index.php', 1615306889);
INSERT INTO `stats_views` VALUES(1639, 403, '/index.php', 1615308054);
INSERT INTO `stats_views` VALUES(1640, 404, '/index.php', 1615308433);
INSERT INTO `stats_views` VALUES(1641, 405, '/index.php', 1615308596);
INSERT INTO `stats_views` VALUES(1642, 406, '/index.php', 1615309380);
INSERT INTO `stats_views` VALUES(1643, 407, '/signup.php', 1615309758);
INSERT INTO `stats_views` VALUES(1644, 408, '/signup.php', 1615309920);
INSERT INTO `stats_views` VALUES(1645, 408, '/signup.php', 1615310013);
INSERT INTO `stats_views` VALUES(1646, 407, '/signup.php', 1615310261);
INSERT INTO `stats_views` VALUES(1647, 407, '/signup.php', 1615310586);
INSERT INTO `stats_views` VALUES(1648, 407, '/login.php', 1615310588);
INSERT INTO `stats_views` VALUES(1649, 407, '/login.php', 1615310632);
INSERT INTO `stats_views` VALUES(1650, 408, '/login.php', 1615310668);
INSERT INTO `stats_views` VALUES(1651, 409, '/login.php', 1615310786);
INSERT INTO `stats_views` VALUES(1652, 410, '/index.php', 1615311712);
INSERT INTO `stats_views` VALUES(1653, 410, '/index.php', 1615312259);
INSERT INTO `stats_views` VALUES(1654, 410, '/index.php', 1615312366);
INSERT INTO `stats_views` VALUES(1655, 410, '/index.php', 1615313319);
INSERT INTO `stats_views` VALUES(1656, 411, '/index.php', 1615313549);
INSERT INTO `stats_views` VALUES(1657, 412, '/index.php', 1615313584);
INSERT INTO `stats_views` VALUES(1658, 410, '/index.php', 1615313784);
INSERT INTO `stats_views` VALUES(1659, 410, '/index.php', 1615314675);
INSERT INTO `stats_views` VALUES(1660, 412, '/index.php', 1615316438);
INSERT INTO `stats_views` VALUES(1661, 413, '/index.php', 1615320816);
INSERT INTO `stats_views` VALUES(1662, 413, '/signup.php', 1615320823);
INSERT INTO `stats_views` VALUES(1663, 413, '/signup.php', 1615320834);
INSERT INTO `stats_views` VALUES(1664, 413, '/signup.php', 1615320844);
INSERT INTO `stats_views` VALUES(1665, 413, '/signup.php', 1615320848);
INSERT INTO `stats_views` VALUES(1666, 413, '/signup.php', 1615320851);
INSERT INTO `stats_views` VALUES(1667, 413, '/signup.php', 1615320854);
INSERT INTO `stats_views` VALUES(1668, 413, '/signup.php', 1615320858);
INSERT INTO `stats_views` VALUES(1669, 413, '/signup.php', 1615320885);
INSERT INTO `stats_views` VALUES(1670, 413, '/index.php', 1615320888);
INSERT INTO `stats_views` VALUES(1671, 414, '/index.php', 1615323032);
INSERT INTO `stats_views` VALUES(1672, 414, '/index.php', 1615323032);
INSERT INTO `stats_views` VALUES(1673, 414, '/signup.php', 1615323037);
INSERT INTO `stats_views` VALUES(1674, 414, '/signup.php', 1615323042);
INSERT INTO `stats_views` VALUES(1675, 414, '/signup.php', 1615323110);
INSERT INTO `stats_views` VALUES(1676, 414, '/signup.php', 1615323117);
INSERT INTO `stats_views` VALUES(1677, 414, '/signup.php', 1615323288);
INSERT INTO `stats_views` VALUES(1678, 414, '/signup.php', 1615323296);
INSERT INTO `stats_views` VALUES(1679, 414, '/signup.php', 1615323513);
INSERT INTO `stats_views` VALUES(1680, 414, '/signup.php', 1615323517);
INSERT INTO `stats_views` VALUES(1681, 414, '/signup.php', 1615323564);
INSERT INTO `stats_views` VALUES(1682, 414, '/signup.php', 1615323572);
INSERT INTO `stats_views` VALUES(1683, 414, '/index.php', 1615324056);
INSERT INTO `stats_views` VALUES(1684, 414, '/login.php', 1615324060);
INSERT INTO `stats_views` VALUES(1685, 414, '/forgot_password.php', 1615324065);
INSERT INTO `stats_views` VALUES(1686, 414, '/forgot_password.php', 1615324072);
INSERT INTO `stats_views` VALUES(1687, 414, '/forgot_password.php', 1615324074);
INSERT INTO `stats_views` VALUES(1688, 414, '/forgot_password.php', 1615324258);
INSERT INTO `stats_views` VALUES(1689, 414, '/forgot_password.php', 1615324260);
INSERT INTO `stats_views` VALUES(1690, 414, '/forgot_password.php', 1615324539);
INSERT INTO `stats_views` VALUES(1691, 414, '/forgot_password.php', 1615324540);
INSERT INTO `stats_views` VALUES(1692, 414, '/index.php', 1615324586);
INSERT INTO `stats_views` VALUES(1693, 414, '/signup.php', 1615324593);
INSERT INTO `stats_views` VALUES(1694, 414, '/signup.php', 1615324638);
INSERT INTO `stats_views` VALUES(1695, 414, '/signup.php', 1615324646);
INSERT INTO `stats_views` VALUES(1696, 414, '/login.php', 1615324647);
INSERT INTO `stats_views` VALUES(1697, 414, '/login.php', 1615324662);
INSERT INTO `stats_views` VALUES(1698, 414, '/index.php', 1615325456);
INSERT INTO `stats_views` VALUES(1699, 414, '/login.php', 1615325467);
INSERT INTO `stats_views` VALUES(1700, 414, '/forgot_password.php', 1615325471);
INSERT INTO `stats_views` VALUES(1701, 414, '/forgot_password.php', 1615325478);
INSERT INTO `stats_views` VALUES(1702, 414, '/forgot_password.php', 1615325479);
INSERT INTO `stats_views` VALUES(1703, 414, '/forgot_password.php', 1615325785);
INSERT INTO `stats_views` VALUES(1704, 414, '/forgot_password.php', 1615325785);
INSERT INTO `stats_views` VALUES(1705, 414, '/index.php', 1615326020);
INSERT INTO `stats_views` VALUES(1706, 414, '/signup.php', 1615326029);
INSERT INTO `stats_views` VALUES(1707, 414, '/index.php', 1615326055);


DROP TABLE IF EXISTS stats_visitors;
CREATE TABLE `stats_visitors` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `ipref` int(11) NOT NULL DEFAULT 0,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `thetime` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`visitor_id`),
  KEY `ipaddress_idx` (`ipaddress`),
  KEY `country_idx` (`country`),
  KEY `city_idx` (`city`),
  KEY `thetime` (`thetime`)
) ENGINE=MyISAM AUTO_INCREMENT=415 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `stats_visitors` VALUES(1, '52.114.75.71', 1, 1, 'Undefined', 1607507974);
INSERT INTO `stats_visitors` VALUES(2, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607508853);
INSERT INTO `stats_visitors` VALUES(3, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607508863);
INSERT INTO `stats_visitors` VALUES(4, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509012);
INSERT INTO `stats_visitors` VALUES(5, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607509040);
INSERT INTO `stats_visitors` VALUES(6, '2401:3c00:18f:4c1a:f', 2, 1, 'Undefined', 1607509041);
INSERT INTO `stats_visitors` VALUES(7, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509066);
INSERT INTO `stats_visitors` VALUES(8, '203.82.75.133', 1, 1, 'Undefined', 1607509071);
INSERT INTO `stats_visitors` VALUES(9, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509085);
INSERT INTO `stats_visitors` VALUES(10, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509086);
INSERT INTO `stats_visitors` VALUES(11, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509113);
INSERT INTO `stats_visitors` VALUES(12, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509123);
INSERT INTO `stats_visitors` VALUES(13, '2401:3c00:18f:4c1a:f', 3, 1, 'Undefined', 1607509124);
INSERT INTO `stats_visitors` VALUES(14, '2401:3c00:18f:4c1a:f', 1, 1, 'Undefined', 1607509128);
INSERT INTO `stats_visitors` VALUES(15, '61.129.8.179', 1, 1, 'Undefined', 1607509369);
INSERT INTO `stats_visitors` VALUES(16, '61.151.178.236', 1, 1, 'Undefined', 1607509385);
INSERT INTO `stats_visitors` VALUES(17, '101.89.239.230', 1, 1, 'Undefined', 1607509574);
INSERT INTO `stats_visitors` VALUES(18, '61.129.7.235', 1, 1, 'Undefined', 1607509657);
INSERT INTO `stats_visitors` VALUES(19, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607532652);
INSERT INTO `stats_visitors` VALUES(20, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533287);
INSERT INTO `stats_visitors` VALUES(21, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533337);
INSERT INTO `stats_visitors` VALUES(22, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533452);
INSERT INTO `stats_visitors` VALUES(23, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533456);
INSERT INTO `stats_visitors` VALUES(24, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533490);
INSERT INTO `stats_visitors` VALUES(25, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533506);
INSERT INTO `stats_visitors` VALUES(26, '2a00:bc00:8800:b665:', 1, 1, 'Undefined', 1607533518);
INSERT INTO `stats_visitors` VALUES(27, '2a00:bc00:8800:b665:', 2, 1, 'Undefined', 1607533566);
INSERT INTO `stats_visitors` VALUES(28, '2a00:bc00:8800:b665:', 4, 1, 'Undefined', 1607533569);
INSERT INTO `stats_visitors` VALUES(29, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533581);
INSERT INTO `stats_visitors` VALUES(30, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533852);
INSERT INTO `stats_visitors` VALUES(31, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533867);
INSERT INTO `stats_visitors` VALUES(32, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533901);
INSERT INTO `stats_visitors` VALUES(33, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533963);
INSERT INTO `stats_visitors` VALUES(34, '2a00:bc00:8800:b665:', 5, 1, 'Undefined', 1607533984);
INSERT INTO `stats_visitors` VALUES(35, '2a00:bc00:8800:b665:', 6, 1, 'Undefined', 1607533991);
INSERT INTO `stats_visitors` VALUES(36, '2a00:bc00:8800:b665:', 6, 1, 'Undefined', 1607534009);
INSERT INTO `stats_visitors` VALUES(37, '2a00:bc00:8800:b665:', 2, 1, 'Undefined', 1607534011);
INSERT INTO `stats_visitors` VALUES(38, '2a00:bc00:8800:b665:', 7, 1, 'Undefined', 1607534014);
INSERT INTO `stats_visitors` VALUES(39, '2a00:bc00:8800:b665:', 7, 1, 'Undefined', 1607534691);
INSERT INTO `stats_visitors` VALUES(40, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607534920);
INSERT INTO `stats_visitors` VALUES(41, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607534942);
INSERT INTO `stats_visitors` VALUES(42, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535105);
INSERT INTO `stats_visitors` VALUES(43, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535107);
INSERT INTO `stats_visitors` VALUES(44, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535209);
INSERT INTO `stats_visitors` VALUES(45, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535213);
INSERT INTO `stats_visitors` VALUES(46, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535233);
INSERT INTO `stats_visitors` VALUES(47, '2a00:bc00:8800:b665:', 8, 1, 'Undefined', 1607535257);
INSERT INTO `stats_visitors` VALUES(48, '41.217.25.170', 1, 1, 'Undefined', 1613129223);
INSERT INTO `stats_visitors` VALUES(49, '41.217.25.170', 9, 1, 'Undefined', 1613140970);
INSERT INTO `stats_visitors` VALUES(50, '54.221.27.173', 1, 1, 'Undefined', 1613142587);
INSERT INTO `stats_visitors` VALUES(51, '105.112.116.187', 10, 1, 'Undefined', 1613170193);
INSERT INTO `stats_visitors` VALUES(52, '105.112.123.76', 1, 1, 'Undefined', 1613216111);
INSERT INTO `stats_visitors` VALUES(53, '195.154.61.206', 1, 1, 'Undefined', 1613222606);
INSERT INTO `stats_visitors` VALUES(54, '212.83.146.233', 1, 1, 'Undefined', 1613223793);
INSERT INTO `stats_visitors` VALUES(55, '62.4.14.198', 1, 1, 'Undefined', 1613224589);
INSERT INTO `stats_visitors` VALUES(56, '62.210.10.77', 1, 1, 'Undefined', 1613226948);
INSERT INTO `stats_visitors` VALUES(57, '197.210.71.201', 11, 1, 'Undefined', 1613239437);
INSERT INTO `stats_visitors` VALUES(58, '54.187.13.199', 1, 1, 'Undefined', 1613248792);
INSERT INTO `stats_visitors` VALUES(59, '181.214.163.155', 1, 1, 'Undefined', 1613258652);
INSERT INTO `stats_visitors` VALUES(60, '173.212.199.138', 12, 1, 'Undefined', 1613259764);
INSERT INTO `stats_visitors` VALUES(61, '66.249.66.135', 1, 1, 'Undefined', 1613264504);
INSERT INTO `stats_visitors` VALUES(62, '181.214.111.251', 1, 1, 'Undefined', 1613286283);
INSERT INTO `stats_visitors` VALUES(63, '208.80.194.41', 1, 1, 'Undefined', 1613292005);
INSERT INTO `stats_visitors` VALUES(64, '105.112.96.96', 1, 1, 'Undefined', 1613296267);
INSERT INTO `stats_visitors` VALUES(65, '38.145.87.95', 1, 1, 'Undefined', 1613317633);
INSERT INTO `stats_visitors` VALUES(66, '105.112.115.77', 10, 1, 'Undefined', 1613322116);
INSERT INTO `stats_visitors` VALUES(67, '105.112.115.17', 1, 1, 'Undefined', 1613332934);
INSERT INTO `stats_visitors` VALUES(68, '173.212.199.138', 12, 1, 'Undefined', 1613348382);
INSERT INTO `stats_visitors` VALUES(69, '38.122.112.147', 1, 1, 'Undefined', 1613352580);
INSERT INTO `stats_visitors` VALUES(70, '35.226.153.193', 1, 1, 'Undefined', 1613358450);
INSERT INTO `stats_visitors` VALUES(71, '41.217.7.203', 1, 1, 'Undefined', 1613379896);
INSERT INTO `stats_visitors` VALUES(72, '154.120.71.217', 1, 1, 'Undefined', 1613386020);
INSERT INTO `stats_visitors` VALUES(73, '38.18.52.210', 1, 1, 'Undefined', 1613404944);
INSERT INTO `stats_visitors` VALUES(74, '38.131.138.187', 1, 1, 'Undefined', 1613418282);
INSERT INTO `stats_visitors` VALUES(75, '105.112.114.153', 13, 1, 'Undefined', 1613431113);
INSERT INTO `stats_visitors` VALUES(76, '173.212.199.138', 12, 1, 'Undefined', 1613432596);
INSERT INTO `stats_visitors` VALUES(77, '77.88.5.207', 1, 1, 'Undefined', 1613434148);
INSERT INTO `stats_visitors` VALUES(78, '64.137.9.69', 1, 1, 'Undefined', 1613441306);
INSERT INTO `stats_visitors` VALUES(79, '66.249.66.131', 1, 1, 'Undefined', 1613456729);
INSERT INTO `stats_visitors` VALUES(80, '181.214.189.151', 1, 1, 'Undefined', 1613464493);
INSERT INTO `stats_visitors` VALUES(81, '66.249.66.133', 1, 1, 'Undefined', 1613468237);
INSERT INTO `stats_visitors` VALUES(82, '41.217.32.134', 1, 1, 'Undefined', 1613478953);
INSERT INTO `stats_visitors` VALUES(83, '181.215.81.145', 1, 1, 'Undefined', 1613484902);
INSERT INTO `stats_visitors` VALUES(84, '41.217.32.99', 1, 1, 'Undefined', 1613487432);
INSERT INTO `stats_visitors` VALUES(85, '181.214.125.139', 1, 1, 'Undefined', 1613495728);
INSERT INTO `stats_visitors` VALUES(86, '173.212.199.138', 12, 1, 'Undefined', 1613518750);
INSERT INTO `stats_visitors` VALUES(87, '51.222.43.144', 1, 1, 'Undefined', 1613546961);
INSERT INTO `stats_visitors` VALUES(88, '51.77.246.206', 1, 1, 'Undefined', 1613547292);
INSERT INTO `stats_visitors` VALUES(89, '168.151.116.213', 1, 1, 'Undefined', 1613559429);
INSERT INTO `stats_visitors` VALUES(90, '197.210.70.128', 14, 1, 'Undefined', 1613564584);
INSERT INTO `stats_visitors` VALUES(91, '197.210.71.175', 1, 1, 'Undefined', 1613566365);
INSERT INTO `stats_visitors` VALUES(92, '197.210.70.56', 1, 1, 'Undefined', 1613566409);
INSERT INTO `stats_visitors` VALUES(93, '197.210.70.247', 1, 1, 'Undefined', 1613566895);
INSERT INTO `stats_visitors` VALUES(94, '197.210.71.29', 15, 1, 'Undefined', 1613569763);
INSERT INTO `stats_visitors` VALUES(95, '181.214.249.98', 1, 1, 'Undefined', 1613587139);
INSERT INTO `stats_visitors` VALUES(96, '3.129.194.84', 1, 1, 'Undefined', 1613598505);
INSERT INTO `stats_visitors` VALUES(97, '34.218.235.197', 1, 1, 'Undefined', 1613613693);
INSERT INTO `stats_visitors` VALUES(98, '173.252.127.120', 1, 1, 'Undefined', 1613625983);
INSERT INTO `stats_visitors` VALUES(99, '34.217.118.175', 1, 1, 'Undefined', 1613638121);
INSERT INTO `stats_visitors` VALUES(100, '105.112.114.231', 1, 1, 'Undefined', 1613645329);
INSERT INTO `stats_visitors` VALUES(101, '66.249.66.131', 1, 1, 'Undefined', 1613659602);
INSERT INTO `stats_visitors` VALUES(102, '66.249.66.135', 1, 1, 'Undefined', 1613678510);
INSERT INTO `stats_visitors` VALUES(103, '35.159.39.207', 1, 1, 'Undefined', 1613681381);
INSERT INTO `stats_visitors` VALUES(104, '34.96.130.154', 1, 1, 'Undefined', 1613713653);
INSERT INTO `stats_visitors` VALUES(105, '66.249.66.131', 1, 1, 'Undefined', 1613723552);
INSERT INTO `stats_visitors` VALUES(106, '192.71.30.89', 16, 1, 'Undefined', 1613733177);
INSERT INTO `stats_visitors` VALUES(107, '154.120.120.41', 1, 1, 'Undefined', 1613736058);
INSERT INTO `stats_visitors` VALUES(108, '66.249.66.133', 1, 1, 'Undefined', 1613812736);
INSERT INTO `stats_visitors` VALUES(109, '34.96.130.85', 1, 1, 'Undefined', 1613830778);
INSERT INTO `stats_visitors` VALUES(110, '34.86.35.122', 1, 1, 'Undefined', 1613838036);
INSERT INTO `stats_visitors` VALUES(111, '34.96.130.157', 1, 1, 'Undefined', 1613873126);
INSERT INTO `stats_visitors` VALUES(112, '105.112.123.225', 1, 1, 'Undefined', 1613905540);
INSERT INTO `stats_visitors` VALUES(113, '208.80.194.42', 1, 1, 'Undefined', 1613907537);
INSERT INTO `stats_visitors` VALUES(114, '105.112.116.200', 1, 1, 'Undefined', 1613911931);
INSERT INTO `stats_visitors` VALUES(115, '105.112.113.11', 9, 1, 'Undefined', 1613920827);
INSERT INTO `stats_visitors` VALUES(116, '66.249.66.135', 1, 1, 'Undefined', 1613931299);
INSERT INTO `stats_visitors` VALUES(117, '3.128.205.93', 1, 1, 'Undefined', 1614032761);
INSERT INTO `stats_visitors` VALUES(118, '34.86.35.122', 1, 1, 'Undefined', 1614041164);
INSERT INTO `stats_visitors` VALUES(119, '197.210.70.251', 1, 1, 'Undefined', 1614076210);
INSERT INTO `stats_visitors` VALUES(120, '197.210.71.178', 17, 1, 'Undefined', 1614076420);
INSERT INTO `stats_visitors` VALUES(121, '197.210.70.130', 17, 1, 'Undefined', 1614076428);
INSERT INTO `stats_visitors` VALUES(122, '34.86.35.9', 1, 1, 'Undefined', 1614103354);
INSERT INTO `stats_visitors` VALUES(123, '34.86.35.9', 1, 1, 'Undefined', 1614151986);
INSERT INTO `stats_visitors` VALUES(124, '34.86.35.122', 1, 1, 'Undefined', 1614155981);
INSERT INTO `stats_visitors` VALUES(125, '34.214.48.224', 1, 1, 'Undefined', 1614265487);
INSERT INTO `stats_visitors` VALUES(126, '44.242.139.132', 1, 1, 'Undefined', 1614289659);
INSERT INTO `stats_visitors` VALUES(127, '34.86.35.227', 1, 1, 'Undefined', 1614320362);
INSERT INTO `stats_visitors` VALUES(128, '54.255.168.232', 1, 1, 'Undefined', 1614340279);
INSERT INTO `stats_visitors` VALUES(129, '66.249.72.246', 1, 1, 'Undefined', 1614343955);
INSERT INTO `stats_visitors` VALUES(130, '54.201.223.162', 18, 1, 'Undefined', 1614351392);
INSERT INTO `stats_visitors` VALUES(131, '54.187.237.250', 1, 1, 'Undefined', 1614352755);
INSERT INTO `stats_visitors` VALUES(132, '34.77.162.29', 1, 1, 'Undefined', 1614363798);
INSERT INTO `stats_visitors` VALUES(133, '66.249.72.242', 1, 1, 'Undefined', 1614367817);
INSERT INTO `stats_visitors` VALUES(134, '34.77.162.22', 1, 1, 'Undefined', 1614381242);
INSERT INTO `stats_visitors` VALUES(135, '197.210.85.23', 1, 1, 'Undefined', 1614408606);
INSERT INTO `stats_visitors` VALUES(136, '34.77.162.10', 1, 1, 'Undefined', 1614412061);
INSERT INTO `stats_visitors` VALUES(137, '105.112.228.233', 1, 1, 'Undefined', 1614425493);
INSERT INTO `stats_visitors` VALUES(138, '197.210.76.43', 1, 1, 'Undefined', 1614425755);
INSERT INTO `stats_visitors` VALUES(139, '105.112.113.191', 1, 1, 'Undefined', 1614426003);
INSERT INTO `stats_visitors` VALUES(140, '171.13.14.55', 1, 1, 'Undefined', 1614428198);
INSERT INTO `stats_visitors` VALUES(141, '171.13.14.83', 1, 1, 'Undefined', 1614428219);
INSERT INTO `stats_visitors` VALUES(142, '54.202.60.226', 1, 1, 'Undefined', 1614439041);
INSERT INTO `stats_visitors` VALUES(143, '105.112.230.191', 1, 1, 'Undefined', 1614441141);
INSERT INTO `stats_visitors` VALUES(144, '197.210.70.65', 1, 1, 'Undefined', 1614446807);
INSERT INTO `stats_visitors` VALUES(145, '105.112.114.93', 1, 1, 'Undefined', 1614446812);
INSERT INTO `stats_visitors` VALUES(146, '105.112.114.93', 1, 1, 'Undefined', 1614458252);
INSERT INTO `stats_visitors` VALUES(147, '40.77.167.15', 1, 1, 'Undefined', 1614459179);
INSERT INTO `stats_visitors` VALUES(148, '105.112.114.202', 1, 1, 'Undefined', 1614495581);
INSERT INTO `stats_visitors` VALUES(149, '197.210.71.182', 1, 1, 'Undefined', 1614504125);
INSERT INTO `stats_visitors` VALUES(150, '197.210.70.173', 1, 1, 'Undefined', 1614504460);
INSERT INTO `stats_visitors` VALUES(151, '197.210.70.98', 1, 1, 'Undefined', 1614505964);
INSERT INTO `stats_visitors` VALUES(152, '18.224.59.112', 1, 1, 'Undefined', 1614510456);
INSERT INTO `stats_visitors` VALUES(153, '105.112.114.202', 1, 1, 'Undefined', 1614514757);
INSERT INTO `stats_visitors` VALUES(154, '197.210.29.102', 1, 1, 'Undefined', 1614515244);
INSERT INTO `stats_visitors` VALUES(155, '197.210.85.76', 1, 1, 'Undefined', 1614515328);
INSERT INTO `stats_visitors` VALUES(156, '197.210.85.17', 1, 1, 'Undefined', 1614515641);
INSERT INTO `stats_visitors` VALUES(157, '197.210.77.40', 1, 1, 'Undefined', 1614516518);
INSERT INTO `stats_visitors` VALUES(158, '197.210.53.227', 1, 1, 'Undefined', 1614516821);
INSERT INTO `stats_visitors` VALUES(159, '197.210.76.130', 1, 1, 'Undefined', 1614519790);
INSERT INTO `stats_visitors` VALUES(160, '208.80.194.42', 1, 1, 'Undefined', 1614523336);
INSERT INTO `stats_visitors` VALUES(161, '105.112.116.77', 1, 1, 'Undefined', 1614524385);
INSERT INTO `stats_visitors` VALUES(162, '54.186.55.177', 1, 1, 'Undefined', 1614525160);
INSERT INTO `stats_visitors` VALUES(163, '34.223.52.116', 1, 1, 'Undefined', 1614525163);
INSERT INTO `stats_visitors` VALUES(164, '192.36.71.133', 16, 1, 'Undefined', 1614531561);
INSERT INTO `stats_visitors` VALUES(165, '197.210.71.155', 1, 1, 'Undefined', 1614535898);
INSERT INTO `stats_visitors` VALUES(166, '197.210.71.24', 1, 1, 'Undefined', 1614536406);
INSERT INTO `stats_visitors` VALUES(167, '197.210.70.48', 1, 1, 'Undefined', 1614536440);
INSERT INTO `stats_visitors` VALUES(168, '105.112.116.77', 1, 1, 'Undefined', 1614540553);
INSERT INTO `stats_visitors` VALUES(169, '157.90.117.10', 18, 1, 'Undefined', 1614546695);
INSERT INTO `stats_visitors` VALUES(170, '173.212.199.138', 12, 1, 'Undefined', 1614550567);
INSERT INTO `stats_visitors` VALUES(171, '197.210.71.55', 1, 1, 'Undefined', 1614550985);
INSERT INTO `stats_visitors` VALUES(172, '197.210.70.53', 1, 1, 'Undefined', 1614551122);
INSERT INTO `stats_visitors` VALUES(173, '197.210.71.142', 1, 1, 'Undefined', 1614551763);
INSERT INTO `stats_visitors` VALUES(174, '197.210.71.86', 1, 1, 'Undefined', 1614558825);
INSERT INTO `stats_visitors` VALUES(175, '105.112.116.77', 1, 1, 'Undefined', 1614577605);
INSERT INTO `stats_visitors` VALUES(176, '105.112.114.99', 1, 1, 'Undefined', 1614580679);
INSERT INTO `stats_visitors` VALUES(177, '171.13.14.46', 1, 1, 'Undefined', 1614587011);
INSERT INTO `stats_visitors` VALUES(178, '171.13.14.14', 1, 1, 'Undefined', 1614587016);
INSERT INTO `stats_visitors` VALUES(179, '105.112.117.27', 1, 1, 'Undefined', 1614591553);
INSERT INTO `stats_visitors` VALUES(180, '197.210.70.251', 1, 1, 'Undefined', 1614593404);
INSERT INTO `stats_visitors` VALUES(181, '197.210.71.52', 1, 1, 'Undefined', 1614593658);
INSERT INTO `stats_visitors` VALUES(182, '197.210.71.101', 1, 1, 'Undefined', 1614593907);
INSERT INTO `stats_visitors` VALUES(183, '197.210.71.195', 1, 1, 'Undefined', 1614594513);
INSERT INTO `stats_visitors` VALUES(184, '197.210.52.74', 19, 1, 'Undefined', 1614597548);
INSERT INTO `stats_visitors` VALUES(185, '173.252.87.117', 1, 1, 'Undefined', 1614598291);
INSERT INTO `stats_visitors` VALUES(186, '197.210.52.102', 20, 1, 'Undefined', 1614599996);
INSERT INTO `stats_visitors` VALUES(187, '197.210.52.175', 20, 1, 'Undefined', 1614603928);
INSERT INTO `stats_visitors` VALUES(188, '41.217.26.185', 1, 1, 'Undefined', 1614603958);
INSERT INTO `stats_visitors` VALUES(189, '105.112.113.114', 1, 1, 'Undefined', 1614606939);
INSERT INTO `stats_visitors` VALUES(190, '197.149.127.196', 21, 1, 'Undefined', 1614606940);
INSERT INTO `stats_visitors` VALUES(191, '197.210.70.100', 22, 1, 'Undefined', 1614607054);
INSERT INTO `stats_visitors` VALUES(192, '197.210.76.203', 1, 1, 'Undefined', 1614609933);
INSERT INTO `stats_visitors` VALUES(193, '197.210.53.116', 1, 1, 'Undefined', 1614611391);
INSERT INTO `stats_visitors` VALUES(194, '34.208.13.220', 1, 1, 'Undefined', 1614611829);
INSERT INTO `stats_visitors` VALUES(195, '197.210.52.227', 1, 1, 'Undefined', 1614613891);
INSERT INTO `stats_visitors` VALUES(196, '197.210.77.162', 1, 1, 'Undefined', 1614613906);
INSERT INTO `stats_visitors` VALUES(197, '197.210.52.164', 17, 1, 'Undefined', 1614613975);
INSERT INTO `stats_visitors` VALUES(198, '197.210.77.164', 1, 1, 'Undefined', 1614615606);
INSERT INTO `stats_visitors` VALUES(199, '197.210.52.16', 17, 1, 'Undefined', 1614615741);
INSERT INTO `stats_visitors` VALUES(200, '197.210.77.192', 1, 1, 'Undefined', 1614615857);
INSERT INTO `stats_visitors` VALUES(201, '197.210.76.168', 20, 1, 'Undefined', 1614624525);
INSERT INTO `stats_visitors` VALUES(202, '105.112.229.167', 1, 1, 'Undefined', 1614625201);
INSERT INTO `stats_visitors` VALUES(203, '197.210.76.46', 1, 1, 'Undefined', 1614627004);
INSERT INTO `stats_visitors` VALUES(204, '197.210.76.198', 1, 1, 'Undefined', 1614627016);
INSERT INTO `stats_visitors` VALUES(205, '197.210.53.59', 23, 1, 'Undefined', 1614630681);
INSERT INTO `stats_visitors` VALUES(206, '197.210.53.31', 23, 1, 'Undefined', 1614630711);
INSERT INTO `stats_visitors` VALUES(207, '197.210.76.113', 23, 1, 'Undefined', 1614630860);
INSERT INTO `stats_visitors` VALUES(208, '105.112.117.16', 1, 1, 'Undefined', 1614632615);
INSERT INTO `stats_visitors` VALUES(209, '66.249.72.242', 1, 1, 'Undefined', 1614637663);
INSERT INTO `stats_visitors` VALUES(210, '160.119.125.174', 1, 1, 'Undefined', 1614640180);
INSERT INTO `stats_visitors` VALUES(211, '197.149.127.197', 21, 1, 'Undefined', 1614640182);
INSERT INTO `stats_visitors` VALUES(212, '160.119.125.174', 1, 1, 'Undefined', 1614666990);
INSERT INTO `stats_visitors` VALUES(213, '105.112.229.119', 17, 1, 'Undefined', 1614669400);
INSERT INTO `stats_visitors` VALUES(214, '197.210.53.51', 23, 1, 'Undefined', 1614672338);
INSERT INTO `stats_visitors` VALUES(215, '105.112.229.119', 24, 1, 'Undefined', 1614680231);
INSERT INTO `stats_visitors` VALUES(216, '197.210.70.64', 23, 1, 'Undefined', 1614680358);
INSERT INTO `stats_visitors` VALUES(217, '197.210.71.25', 25, 1, 'Undefined', 1614680563);
INSERT INTO `stats_visitors` VALUES(218, '82.211.57.247', 18, 1, 'Undefined', 1614697267);
INSERT INTO `stats_visitors` VALUES(219, '197.210.77.216', 1, 1, 'Undefined', 1614710079);
INSERT INTO `stats_visitors` VALUES(220, '105.112.123.28', 1, 1, 'Undefined', 1614710692);
INSERT INTO `stats_visitors` VALUES(221, '66.249.72.224', 1, 1, 'Undefined', 1614714376);
INSERT INTO `stats_visitors` VALUES(222, '197.210.77.69', 24, 1, 'Undefined', 1614740348);
INSERT INTO `stats_visitors` VALUES(223, '197.210.76.240', 24, 1, 'Undefined', 1614740728);
INSERT INTO `stats_visitors` VALUES(224, '105.112.112.217', 1, 1, 'Undefined', 1614755080);
INSERT INTO `stats_visitors` VALUES(225, '197.210.53.141', 26, 1, 'Undefined', 1614760296);
INSERT INTO `stats_visitors` VALUES(226, '197.210.52.22', 27, 1, 'Undefined', 1614760302);
INSERT INTO `stats_visitors` VALUES(227, '197.210.52.204', 23, 1, 'Undefined', 1614764163);
INSERT INTO `stats_visitors` VALUES(228, '197.210.53.160', 23, 1, 'Undefined', 1614764788);
INSERT INTO `stats_visitors` VALUES(229, '105.112.112.5', 1, 1, 'Undefined', 1614766424);
INSERT INTO `stats_visitors` VALUES(230, '197.210.76.180', 23, 1, 'Undefined', 1614772440);
INSERT INTO `stats_visitors` VALUES(231, '197.210.77.245', 17, 1, 'Undefined', 1614772474);
INSERT INTO `stats_visitors` VALUES(232, '197.210.52.218', 23, 1, 'Undefined', 1614773262);
INSERT INTO `stats_visitors` VALUES(233, '34.77.162.28', 1, 1, 'Undefined', 1614778797);
INSERT INTO `stats_visitors` VALUES(234, '197.210.70.2', 24, 1, 'Undefined', 1614793460);
INSERT INTO `stats_visitors` VALUES(235, '197.210.71.32', 24, 1, 'Undefined', 1614793954);
INSERT INTO `stats_visitors` VALUES(236, '197.210.71.166', 24, 1, 'Undefined', 1614795215);
INSERT INTO `stats_visitors` VALUES(237, '197.210.71.54', 24, 1, 'Undefined', 1614804137);
INSERT INTO `stats_visitors` VALUES(238, '197.210.70.55', 23, 1, 'Undefined', 1614804314);
INSERT INTO `stats_visitors` VALUES(239, '197.210.71.96', 23, 1, 'Undefined', 1614804416);
INSERT INTO `stats_visitors` VALUES(240, '197.210.71.141', 24, 1, 'Undefined', 1614804666);
INSERT INTO `stats_visitors` VALUES(241, '197.210.70.58', 24, 1, 'Undefined', 1614805170);
INSERT INTO `stats_visitors` VALUES(242, '197.210.58.29', 24, 1, 'Undefined', 1614805614);
INSERT INTO `stats_visitors` VALUES(243, '105.112.230.156', 1, 1, 'Undefined', 1614805917);
INSERT INTO `stats_visitors` VALUES(244, '197.210.70.41', 24, 1, 'Undefined', 1614813892);
INSERT INTO `stats_visitors` VALUES(245, '197.210.71.54', 24, 1, 'Undefined', 1614815140);
INSERT INTO `stats_visitors` VALUES(246, '197.210.71.141', 24, 1, 'Undefined', 1614815674);
INSERT INTO `stats_visitors` VALUES(247, '105.112.230.156', 1, 1, 'Undefined', 1614823334);
INSERT INTO `stats_visitors` VALUES(248, '138.246.253.24', 1, 1, 'Undefined', 1614845603);
INSERT INTO `stats_visitors` VALUES(249, '105.112.114.68', 16, 1, 'Undefined', 1614855077);
INSERT INTO `stats_visitors` VALUES(250, '197.210.70.56', 23, 1, 'Undefined', 1614858100);
INSERT INTO `stats_visitors` VALUES(251, '197.210.71.152', 23, 1, 'Undefined', 1614858687);
INSERT INTO `stats_visitors` VALUES(252, '105.112.230.156', 24, 1, 'Undefined', 1614861792);
INSERT INTO `stats_visitors` VALUES(253, '138.246.253.24', 1, 1, 'Undefined', 1614875928);
INSERT INTO `stats_visitors` VALUES(254, '197.210.76.155', 23, 1, 'Undefined', 1614885184);
INSERT INTO `stats_visitors` VALUES(255, '197.210.52.192', 23, 1, 'Undefined', 1614885772);
INSERT INTO `stats_visitors` VALUES(256, '197.210.52.100', 17, 1, 'Undefined', 1614886356);
INSERT INTO `stats_visitors` VALUES(257, '197.210.52.224', 23, 1, 'Undefined', 1614886367);
INSERT INTO `stats_visitors` VALUES(258, '34.77.162.8', 1, 1, 'Undefined', 1614890856);
INSERT INTO `stats_visitors` VALUES(259, '34.77.162.11', 1, 1, 'Undefined', 1614891590);
INSERT INTO `stats_visitors` VALUES(260, '34.77.162.3', 1, 1, 'Undefined', 1614893418);
INSERT INTO `stats_visitors` VALUES(261, '105.112.124.96', 1, 1, 'Undefined', 1614927410);
INSERT INTO `stats_visitors` VALUES(262, '197.210.71.51', 23, 1, 'Undefined', 1614933176);
INSERT INTO `stats_visitors` VALUES(263, '197.210.70.52', 25, 1, 'Undefined', 1614933311);
INSERT INTO `stats_visitors` VALUES(264, '197.210.71.103', 20, 1, 'Undefined', 1614933351);
INSERT INTO `stats_visitors` VALUES(265, '197.210.70.183', 1, 1, 'Undefined', 1614939323);
INSERT INTO `stats_visitors` VALUES(266, '197.210.71.168', 1, 1, 'Undefined', 1614939895);
INSERT INTO `stats_visitors` VALUES(267, '197.210.71.2', 28, 1, 'Undefined', 1614939903);
INSERT INTO `stats_visitors` VALUES(268, '197.210.70.75', 1, 1, 'Undefined', 1614939910);
INSERT INTO `stats_visitors` VALUES(269, '197.211.53.149', 1, 1, 'Undefined', 1614940038);
INSERT INTO `stats_visitors` VALUES(270, '197.210.71.163', 1, 1, 'Undefined', 1614940241);
INSERT INTO `stats_visitors` VALUES(271, '197.210.71.98', 28, 1, 'Undefined', 1614940273);
INSERT INTO `stats_visitors` VALUES(272, '129.205.124.245', 1, 1, 'Undefined', 1614940280);
INSERT INTO `stats_visitors` VALUES(273, '197.210.71.254', 13, 1, 'Undefined', 1614940357);
INSERT INTO `stats_visitors` VALUES(274, '197.210.71.64', 13, 1, 'Undefined', 1614940439);
INSERT INTO `stats_visitors` VALUES(275, '197.210.71.154', 29, 1, 'Undefined', 1614940491);
INSERT INTO `stats_visitors` VALUES(276, '197.210.70.72', 1, 1, 'Undefined', 1614942056);
INSERT INTO `stats_visitors` VALUES(277, '197.210.71.145', 1, 1, 'Undefined', 1614947325);
INSERT INTO `stats_visitors` VALUES(278, '66.249.66.133', 1, 1, 'Undefined', 1614947976);
INSERT INTO `stats_visitors` VALUES(279, '154.120.69.159', 23, 1, 'Undefined', 1614950020);
INSERT INTO `stats_visitors` VALUES(280, '154.120.123.52', 23, 1, 'Undefined', 1614953920);
INSERT INTO `stats_visitors` VALUES(281, '197.210.70.104', 30, 1, 'Undefined', 1614961078);
INSERT INTO `stats_visitors` VALUES(282, '197.210.71.213', 31, 1, 'Undefined', 1614961087);
INSERT INTO `stats_visitors` VALUES(283, '197.210.77.60', 1, 1, 'Undefined', 1614977198);
INSERT INTO `stats_visitors` VALUES(284, '197.210.76.81', 32, 1, 'Undefined', 1614978947);
INSERT INTO `stats_visitors` VALUES(285, '197.210.77.214', 31, 1, 'Undefined', 1614978956);
INSERT INTO `stats_visitors` VALUES(286, '197.210.76.14', 32, 1, 'Undefined', 1614979123);
INSERT INTO `stats_visitors` VALUES(287, '139.155.54.119', 1, 1, 'Undefined', 1614984434);
INSERT INTO `stats_visitors` VALUES(288, '66.249.66.133', 1, 1, 'Undefined', 1614997064);
INSERT INTO `stats_visitors` VALUES(289, '105.112.228.136', 1, 1, 'Undefined', 1615018668);
INSERT INTO `stats_visitors` VALUES(290, '197.210.77.158', 23, 1, 'Undefined', 1615033216);
INSERT INTO `stats_visitors` VALUES(291, '197.210.53.51', 23, 1, 'Undefined', 1615033248);
INSERT INTO `stats_visitors` VALUES(292, '197.210.52.55', 23, 1, 'Undefined', 1615033424);
INSERT INTO `stats_visitors` VALUES(293, '197.210.71.139', 23, 1, 'Undefined', 1615046956);
INSERT INTO `stats_visitors` VALUES(294, '197.210.70.56', 17, 1, 'Undefined', 1615046964);
INSERT INTO `stats_visitors` VALUES(295, '197.210.71.14', 25, 1, 'Undefined', 1615047080);
INSERT INTO `stats_visitors` VALUES(296, '105.112.112.3', 1, 1, 'Undefined', 1615047864);
INSERT INTO `stats_visitors` VALUES(297, '197.210.71.153', 23, 1, 'Undefined', 1615055602);
INSERT INTO `stats_visitors` VALUES(298, '197.210.70.254', 17, 1, 'Undefined', 1615055621);
INSERT INTO `stats_visitors` VALUES(299, '197.210.71.68', 17, 1, 'Undefined', 1615055951);
INSERT INTO `stats_visitors` VALUES(300, '197.210.70.1', 20, 1, 'Undefined', 1615057294);
INSERT INTO `stats_visitors` VALUES(301, '197.210.71.165', 1, 1, 'Undefined', 1615062869);
INSERT INTO `stats_visitors` VALUES(302, '197.210.71.52', 17, 1, 'Undefined', 1615062875);
INSERT INTO `stats_visitors` VALUES(303, '197.210.70.33', 17, 1, 'Undefined', 1615063139);
INSERT INTO `stats_visitors` VALUES(304, '197.210.70.64', 17, 1, 'Undefined', 1615063341);
INSERT INTO `stats_visitors` VALUES(305, '197.210.71.25', 25, 1, 'Undefined', 1615063834);
INSERT INTO `stats_visitors` VALUES(306, '197.210.77.40', 1, 1, 'Undefined', 1615064513);
INSERT INTO `stats_visitors` VALUES(307, '197.210.77.231', 17, 1, 'Undefined', 1615064527);
INSERT INTO `stats_visitors` VALUES(308, '197.210.53.172', 17, 1, 'Undefined', 1615064777);
INSERT INTO `stats_visitors` VALUES(309, '197.210.52.17', 17, 1, 'Undefined', 1615064847);
INSERT INTO `stats_visitors` VALUES(310, '197.210.53.227', 1, 1, 'Undefined', 1615065099);
INSERT INTO `stats_visitors` VALUES(311, '197.210.76.242', 25, 1, 'Undefined', 1615065958);
INSERT INTO `stats_visitors` VALUES(312, '197.210.52.211', 17, 1, 'Undefined', 1615066321);
INSERT INTO `stats_visitors` VALUES(313, '197.210.77.92', 25, 1, 'Undefined', 1615066578);
INSERT INTO `stats_visitors` VALUES(314, '197.210.76.140', 17, 1, 'Undefined', 1615066719);
INSERT INTO `stats_visitors` VALUES(315, '3.133.90.182', 1, 1, 'Undefined', 1615068089);
INSERT INTO `stats_visitors` VALUES(316, '197.210.76.222', 23, 1, 'Undefined', 1615068119);
INSERT INTO `stats_visitors` VALUES(317, '34.77.162.3', 1, 1, 'Undefined', 1615091028);
INSERT INTO `stats_visitors` VALUES(318, '105.112.116.49', 33, 1, 'Undefined', 1615104684);
INSERT INTO `stats_visitors` VALUES(319, '197.210.70.61', 23, 1, 'Undefined', 1615124794);
INSERT INTO `stats_visitors` VALUES(320, '197.210.71.164', 17, 1, 'Undefined', 1615124799);
INSERT INTO `stats_visitors` VALUES(321, '197.210.71.63', 25, 1, 'Undefined', 1615124858);
INSERT INTO `stats_visitors` VALUES(322, '197.210.77.92', 23, 1, 'Undefined', 1615192130);
INSERT INTO `stats_visitors` VALUES(323, '105.112.115.236', 1, 1, 'Undefined', 1615200027);
INSERT INTO `stats_visitors` VALUES(324, '197.210.70.139', 23, 1, 'Undefined', 1615200581);
INSERT INTO `stats_visitors` VALUES(325, '197.210.70.174', 23, 1, 'Undefined', 1615201364);
INSERT INTO `stats_visitors` VALUES(326, '41.190.14.107', 23, 1, 'Undefined', 1615204831);
INSERT INTO `stats_visitors` VALUES(327, '197.210.84.200', 23, 1, 'Undefined', 1615205608);
INSERT INTO `stats_visitors` VALUES(328, '197.210.84.222', 17, 1, 'Undefined', 1615206079);
INSERT INTO `stats_visitors` VALUES(329, '197.210.85.197', 23, 1, 'Undefined', 1615206134);
INSERT INTO `stats_visitors` VALUES(330, '197.210.84.166', 25, 1, 'Undefined', 1615206323);
INSERT INTO `stats_visitors` VALUES(331, '197.211.53.149', 9, 1, 'Undefined', 1615206399);
INSERT INTO `stats_visitors` VALUES(332, '197.210.85.180', 20, 1, 'Undefined', 1615206467);
INSERT INTO `stats_visitors` VALUES(333, '41.190.14.124', 17, 1, 'Undefined', 1615206712);
INSERT INTO `stats_visitors` VALUES(334, '197.210.77.88', 23, 1, 'Undefined', 1615207727);
INSERT INTO `stats_visitors` VALUES(335, '197.210.53.212', 17, 1, 'Undefined', 1615208450);
INSERT INTO `stats_visitors` VALUES(336, '168.235.197.254', 28, 1, 'Undefined', 1615208586);
INSERT INTO `stats_visitors` VALUES(337, '197.210.77.77', 23, 1, 'Undefined', 1615208838);
INSERT INTO `stats_visitors` VALUES(338, '197.210.76.17', 1, 1, 'Undefined', 1615210534);
INSERT INTO `stats_visitors` VALUES(339, '105.112.114.95', 23, 1, 'Undefined', 1615211644);
INSERT INTO `stats_visitors` VALUES(340, '197.210.77.59', 23, 1, 'Undefined', 1615211663);
INSERT INTO `stats_visitors` VALUES(341, '197.210.76.133', 17, 1, 'Undefined', 1615212106);
INSERT INTO `stats_visitors` VALUES(342, '197.210.77.130', 25, 1, 'Undefined', 1615212452);
INSERT INTO `stats_visitors` VALUES(343, '197.210.76.107', 23, 1, 'Undefined', 1615213581);
INSERT INTO `stats_visitors` VALUES(344, '197.210.77.250', 17, 1, 'Undefined', 1615213654);
INSERT INTO `stats_visitors` VALUES(345, '129.205.124.245', 1, 1, 'Undefined', 1615213827);
INSERT INTO `stats_visitors` VALUES(346, '197.210.77.159', 1, 1, 'Undefined', 1615214088);
INSERT INTO `stats_visitors` VALUES(347, '40.88.21.235', 17, 1, 'Undefined', 1615215724);
INSERT INTO `stats_visitors` VALUES(348, '105.112.115.236', 1, 1, 'Undefined', 1615218036);
INSERT INTO `stats_visitors` VALUES(349, '197.210.52.160', 1, 1, 'Undefined', 1615220243);
INSERT INTO `stats_visitors` VALUES(350, '105.112.230.137', 34, 1, 'Undefined', 1615224861);
INSERT INTO `stats_visitors` VALUES(351, '105.112.112.160', 1, 1, 'Undefined', 1615224998);
INSERT INTO `stats_visitors` VALUES(352, '160.119.125.174', 1, 1, 'Undefined', 1615244470);
INSERT INTO `stats_visitors` VALUES(353, '134.175.228.189', 35, 1, 'Undefined', 1615249231);
INSERT INTO `stats_visitors` VALUES(354, '197.210.52.109', 23, 1, 'Undefined', 1615281634);
INSERT INTO `stats_visitors` VALUES(355, '197.210.71.109', 23, 1, 'Undefined', 1615282089);
INSERT INTO `stats_visitors` VALUES(356, '197.210.71.25', 17, 1, 'Undefined', 1615282142);
INSERT INTO `stats_visitors` VALUES(357, '197.210.76.22', 1, 1, 'Undefined', 1615282397);
INSERT INTO `stats_visitors` VALUES(358, '197.210.70.62', 25, 1, 'Undefined', 1615282673);
INSERT INTO `stats_visitors` VALUES(359, '102.89.3.228', 1, 1, 'Undefined', 1615283865);
INSERT INTO `stats_visitors` VALUES(360, '102.89.2.208', 17, 1, 'Undefined', 1615283932);
INSERT INTO `stats_visitors` VALUES(361, '169.159.107.76', 1, 1, 'Undefined', 1615283956);
INSERT INTO `stats_visitors` VALUES(362, '102.89.2.50', 25, 1, 'Undefined', 1615284165);
INSERT INTO `stats_visitors` VALUES(363, '102.89.2.51', 25, 1, 'Undefined', 1615284359);
INSERT INTO `stats_visitors` VALUES(364, '102.89.2.191', 20, 1, 'Undefined', 1615284377);
INSERT INTO `stats_visitors` VALUES(365, '102.89.3.230', 20, 1, 'Undefined', 1615284703);
INSERT INTO `stats_visitors` VALUES(366, '197.210.52.224', 1, 1, 'Undefined', 1615284878);
INSERT INTO `stats_visitors` VALUES(367, '102.89.2.98', 1, 1, 'Undefined', 1615285133);
INSERT INTO `stats_visitors` VALUES(368, '197.210.71.40', 25, 1, 'Undefined', 1615286186);
INSERT INTO `stats_visitors` VALUES(369, '105.112.229.173', 1, 1, 'Undefined', 1615286208);
INSERT INTO `stats_visitors` VALUES(370, '102.89.2.75', 1, 1, 'Undefined', 1615286487);
INSERT INTO `stats_visitors` VALUES(371, '105.112.117.89', 1, 1, 'Undefined', 1615287519);
INSERT INTO `stats_visitors` VALUES(372, '105.112.124.252', 1, 1, 'Undefined', 1615287916);
INSERT INTO `stats_visitors` VALUES(373, '129.205.113.51', 1, 1, 'Undefined', 1615288142);
INSERT INTO `stats_visitors` VALUES(374, '197.210.70.197', 1, 1, 'Undefined', 1615290579);
INSERT INTO `stats_visitors` VALUES(375, '197.210.70.148', 1, 1, 'Undefined', 1615290597);
INSERT INTO `stats_visitors` VALUES(376, '197.210.71.214', 17, 1, 'Undefined', 1615290990);
INSERT INTO `stats_visitors` VALUES(377, '105.112.112.11', 1, 1, 'Undefined', 1615291529);
INSERT INTO `stats_visitors` VALUES(378, '197.210.70.111', 1, 1, 'Undefined', 1615291811);
INSERT INTO `stats_visitors` VALUES(379, '197.210.52.192', 1, 1, 'Undefined', 1615291852);
INSERT INTO `stats_visitors` VALUES(380, '197.210.77.236', 1, 1, 'Undefined', 1615291866);
INSERT INTO `stats_visitors` VALUES(381, '197.210.76.131', 31, 1, 'Undefined', 1615291933);
INSERT INTO `stats_visitors` VALUES(382, '197.210.52.180', 1, 1, 'Undefined', 1615292083);
INSERT INTO `stats_visitors` VALUES(383, '197.210.77.73', 1, 1, 'Undefined', 1615292367);
INSERT INTO `stats_visitors` VALUES(384, '197.210.76.241', 1, 1, 'Undefined', 1615293663);
INSERT INTO `stats_visitors` VALUES(385, '197.210.77.95', 20, 1, 'Undefined', 1615293969);
INSERT INTO `stats_visitors` VALUES(386, '197.210.77.162', 1, 1, 'Undefined', 1615294055);
INSERT INTO `stats_visitors` VALUES(387, '197.210.77.49', 1, 1, 'Undefined', 1615294971);
INSERT INTO `stats_visitors` VALUES(388, '169.159.83.97', 1, 1, 'Undefined', 1615296178);
INSERT INTO `stats_visitors` VALUES(389, '197.210.52.17', 1, 1, 'Undefined', 1615297543);
INSERT INTO `stats_visitors` VALUES(390, '197.210.53.96', 16, 1, 'Undefined', 1615297641);
INSERT INTO `stats_visitors` VALUES(391, '197.210.52.112', 20, 1, 'Undefined', 1615297660);
INSERT INTO `stats_visitors` VALUES(392, '197.210.52.27', 20, 1, 'Undefined', 1615297895);
INSERT INTO `stats_visitors` VALUES(393, '197.210.76.184', 25, 1, 'Undefined', 1615297984);
INSERT INTO `stats_visitors` VALUES(394, '197.210.44.21', 1, 1, 'Undefined', 1615299820);
INSERT INTO `stats_visitors` VALUES(395, '168.235.197.138', 28, 1, 'Undefined', 1615299957);
INSERT INTO `stats_visitors` VALUES(396, '41.190.14.22', 1, 1, 'Undefined', 1615299958);
INSERT INTO `stats_visitors` VALUES(397, '197.210.8.235', 1, 1, 'Undefined', 1615300265);
INSERT INTO `stats_visitors` VALUES(398, '129.205.124.243', 1, 1, 'Undefined', 1615300902);
INSERT INTO `stats_visitors` VALUES(399, '129.205.113.59', 1, 1, 'Undefined', 1615301220);
INSERT INTO `stats_visitors` VALUES(400, '168.235.197.157', 28, 1, 'Undefined', 1615301581);
INSERT INTO `stats_visitors` VALUES(401, '168.235.197.254', 28, 1, 'Undefined', 1615303448);
INSERT INTO `stats_visitors` VALUES(402, '197.211.53.149', 1, 1, 'Undefined', 1615305241);
INSERT INTO `stats_visitors` VALUES(403, '197.210.71.12', 36, 1, 'Undefined', 1615308054);
INSERT INTO `stats_visitors` VALUES(404, '197.210.70.192', 1, 1, 'Undefined', 1615308433);
INSERT INTO `stats_visitors` VALUES(405, '197.210.77.73', 23, 1, 'Undefined', 1615308596);
INSERT INTO `stats_visitors` VALUES(406, '197.210.54.64', 1, 1, 'Undefined', 1615309380);
INSERT INTO `stats_visitors` VALUES(407, '197.210.55.243', 17, 1, 'Undefined', 1615309758);
INSERT INTO `stats_visitors` VALUES(408, '197.210.55.220', 25, 1, 'Undefined', 1615309920);
INSERT INTO `stats_visitors` VALUES(409, '197.210.227.56', 20, 1, 'Undefined', 1615310786);
INSERT INTO `stats_visitors` VALUES(410, '105.112.79.103', 16, 1, 'Undefined', 1615311712);
INSERT INTO `stats_visitors` VALUES(411, '41.190.12.66', 37, 1, 'Undefined', 1615313549);
INSERT INTO `stats_visitors` VALUES(412, '105.112.113.79', 16, 1, 'Undefined', 1615313584);
INSERT INTO `stats_visitors` VALUES(413, '105.112.115.107', 37, 1, 'Undefined', 1615320816);
INSERT INTO `stats_visitors` VALUES(414, '105.112.115.120', 1, 1, 'Undefined', 1615323032);


DROP TABLE IF EXISTS testimonials;
CREATE TABLE `testimonials` (
  `testimonial_id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(5) NOT NULL DEFAULT 0,
  `author` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `location` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `photo` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`testimonial_id`),
  KEY `number_idx` (`number`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `testimonials` VALUES(1, 0, '1 am', '', 'messagemessagemessage', '_9ieghudm2e.jpg', 1);
INSERT INTO `testimonials` VALUES(2, 0, 'фыв', '', 'ыфп', '_gd1sq6kel3.jpg', 0);


DROP TABLE IF EXISTS text_ads;
CREATE TABLE `text_ads` (
  `text_ad_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(25) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description1` varchar(35) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `description2` varchar(35) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `url` varchar(250) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `show_url` tinyint(1) NOT NULL DEFAULT 0,
  `displayed` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`text_ad_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `displayed_idx` (`displayed`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS ticket_messages;
CREATE TABLE `ticket_messages` (
  `ticket_message_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL DEFAULT 0,
  `message_from` int(11) NOT NULL DEFAULT 0,
  `message_to` int(11) NOT NULL DEFAULT 0,
  `message` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `date_post` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ticket_message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS tickets;
CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(150) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `date_create` int(11) NOT NULL DEFAULT 0,
  `last_update` int(11) NOT NULL DEFAULT 0,
  `last_replier` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ticket_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS types;
CREATE TABLE `types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index` int(11) NOT NULL DEFAULT 0,
  `title` varchar(120) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `host_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `enr_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `admin_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `width` int(3) NOT NULL DEFAULT 0,
  `depth` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`type_id`),
  KEY `order_index_idx` (`order_index`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `types` VALUES(1, 1, 'MEMBER', '0.00', '10000.00', '0.00', '0.00', 3, 1);
INSERT INTO `types` VALUES(2, 2, 'LIFE SAVER', '0.00', '10000.00', '0.00', '0.00', 3, 1);
INSERT INTO `types` VALUES(3, 3, 'LEADER FOR CHRIST', '0.00', '30000.00', '0.00', '0.00', 3, 1);
INSERT INTO `types` VALUES(4, 4, 'ACTIVE LEADER', '0.00', '100000.00', '0.00', '0.00', 3, 1);
INSERT INTO `types` VALUES(5, 5, 'MENTOR', '0.00', '400000.00', '0.00', '0.00', 3, 1);
INSERT INTO `types` VALUES(6, 6, 'AMBASSADOR FOR CHRIST', '20000.00', '0.00', '0.00', '0.00', 0, 0);


DROP TABLE IF EXISTS user_admins;
CREATE TABLE `user_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `passwd` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `email` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `first_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `last_access` int(11) NOT NULL DEFAULT 0,
  `access` varchar(2048) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `username_idx` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ COLLATE=utf8_unicode_ci;

INSERT INTO `user_admins` VALUES(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'support@istandwithjesus.org', '', '', 0, 'a:42:{i:0;s:5:\"login\";i:1;s:6:\"admins\";i:2;s:4:\"stat\";i:3;s:7:\"members\";i:4;s:4:\"tree\";i:5;s:12:\"admindetails\";i:6;s:8:\"settings\";i:7;s:8:\"matrixes\";i:8;s:6:\"levels\";i:9;s:13:\"levels_forced\";i:10;s:7:\"payment\";i:11;s:4:\"cash\";i:12;s:8:\"cash_out\";i:13;s:10:\"processors\";i:14;s:5:\"pages\";i:15;s:7:\"m_pages\";i:16;s:4:\"news\";i:17;s:3:\"faq\";i:18;s:5:\"lands\";i:19;s:7:\"aptools\";i:20;s:6:\"ptools\";i:21;s:4:\"tads\";i:22;s:7:\"tickets\";i:23;s:11:\"pub_tickets\";i:24;s:10:\"categories\";i:25;s:8:\"products\";i:26;s:9:\"templates\";i:27;s:15:\"autorespondersf\";i:28;s:14:\"autoresponders\";i:29;s:11:\"atempplates\";i:30;s:7:\"mailing\";i:31;s:6:\"backup\";i:32;s:4:\"fees\";i:33;s:11:\"memb_matrix\";i:34;s:8:\"m_levels\";i:35;s:13:\"forced_matrix\";i:36;s:12:\"replica_site\";i:37;s:7:\"shopfee\";i:38;s:6:\"manual\";i:39;s:17:\"template_elements\";i:40;s:14:\"upload_members\";i:41;s:6:\"slider\";}', 1);


